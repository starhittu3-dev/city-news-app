package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.NewsDataSeed
import com.example.data.NewsRepository
import com.example.viewmodel.NewsViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    val appNameHindi = context.getString(R.string.app_name_hindi)
    val tagline = context.getString(R.string.tagline)
    assertEquals("City Khabar", appName)
    assertEquals("सिटी ख़बर", appNameHindi)
    assertEquals("आपके शहर की हर खबर", tagline)
    assertNotNull(context.resources.getDrawable(R.drawable.ic_city_khabar_logo, null))
  }

  @Test
  fun `verify indian cities database covers diverse regions`() {
    val cities = NewsDataSeed.CITIES
    assertTrue(cities.size >= 20)
    assertNotNull(cities.find { it.nameHindi.contains("मुंबई") })
    assertNotNull(cities.find { it.nameEnglish.contains("Bengaluru") })
    assertNotNull(cities.find { it.nameHindi.contains("जयपुर") })
    assertNotNull(cities.find { it.nameHindi.contains("लखनऊ") })
  }

  @Test
  fun `verify city selection synchronizes across state and studios`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = NewsRepository(context)
    val viewModel = NewsViewModel(ApplicationProvider.getApplicationContext())

    val mumbai = NewsDataSeed.CITIES.find { it.id == "mumbai" } ?: NewsDataSeed.CITIES[1]
    viewModel.selectCity(mumbai)

    assertEquals("मुंबई", viewModel.selectedCity.value.nameHindi)
    assertEquals("मुंबई", viewModel.reelCustomization.value.cityHindi)
    assertEquals("मुंबई", viewModel.postCustomization.value.cityHindi)
  }

  @Test
  fun `verify select news to create reel flow initializes studio data`() {
    val viewModel = NewsViewModel(ApplicationProvider.getApplicationContext())
    val sampleNews = NewsDataSeed.generateSampleNews().first()

    viewModel.startCreatingReelFromArticle(sampleNews)

    assertEquals(sampleNews.title, viewModel.reelCustomization.value.headline)
    assertEquals(sampleNews.cityHindi, viewModel.reelCustomization.value.cityHindi)
    assertEquals(sampleNews.reporterName, viewModel.reelCustomization.value.reporterName)
    assertEquals(com.example.viewmodel.AppNavTab.CREATE, viewModel.currentTab.value)
    assertEquals(com.example.viewmodel.CreationStudioMode.REEL_9_16, viewModel.creationStudioMode.value)
  }

  @Test
  fun `verify reels list contains valid reel items with proper metadata`() {
    val viewModel = NewsViewModel(ApplicationProvider.getApplicationContext())
    val reels = viewModel.reelsList.value

    assertTrue(reels.isNotEmpty())
    reels.forEach { reel ->
      assertTrue(reel.title.isNotEmpty())
      assertTrue(reel.cityHindi.isNotEmpty())
      assertTrue(reel.reporterName.isNotEmpty())
      assertTrue(reel.thumbnailResId != 0)
      assertTrue(reel.durationSeconds > 0)
    }
  }

  @Test
  fun `verify news filtering and search work accurately`() {
    val viewModel = NewsViewModel(ApplicationProvider.getApplicationContext())
    viewModel.setSearchQuery("मौसम")
    val filtered = viewModel.getFilteredNews()
    assertNotNull(filtered)
    viewModel.setSearchQuery("")
  }

  @Test
  fun `verify dynamic real-time news generation supplies fresh timestamps`() {
    val service = com.example.data.network.LiveNewsService()
    val items = service.generateDynamicLiveNews("जयपुर", 1)
    assertTrue(items.isNotEmpty())
    assertEquals("जयपुर", items[0].cityHindi)
    assertTrue(items[0].timeAgo.isNotEmpty())
    assertTrue(items[0].publishDate.isNotEmpty())
  }

  @Test
  fun `verify trending news feature returns ranked popular items and supports city filtering`() {
    val viewModel = NewsViewModel(ApplicationProvider.getApplicationContext())
    val trending = viewModel.getTrendingNews()
    assertTrue(trending.isNotEmpty())
    // Verify items are ranked
    assertTrue(trending.size >= 1)
    trending.forEach { item ->
      assertTrue(item.title.isNotEmpty())
      assertTrue(item.cityHindi.isNotEmpty())
      assertTrue(item.viewsCount.isNotEmpty())
    }

    // Verify city-filtered trending news
    val jaipurTrending = viewModel.getTrendingNews(selectedCity = "जयपुर")
    assertTrue(jaipurTrending.isNotEmpty())

    // Verify navigation tab switching
    viewModel.setTab(com.example.viewmodel.AppNavTab.TRENDING)
    assertEquals(com.example.viewmodel.AppNavTab.TRENDING, viewModel.currentTab.value)
  }

  @Test
  fun `verify search history operations save delete and clear correctly`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = NewsRepository(context)
    
    // Save queries
    repo.saveSearchQuery("मौसम अपडेट")
    repo.saveSearchQuery("दिल्ली मेट्रो")
    repo.saveSearchQuery("क्रिकेट स्कोर")

    var history = repo.getSearchHistory().first()
    assertTrue(history.contains("क्रिकेट स्कोर"))
    assertTrue(history.contains("दिल्ली मेट्रो"))
    assertTrue(history.contains("मौसम अपडेट"))

    // Delete single query
    repo.deleteSearchQuery("दिल्ली मेट्रो")
    history = repo.getSearchHistory().first()
    assertTrue(!history.contains("दिल्ली मेट्रो"))
    assertTrue(history.contains("क्रिकेट स्कोर"))

    // Clear all history
    repo.clearSearchHistory()
    history = repo.getSearchHistory().first()
    assertTrue(history.isEmpty())
  }

  @Test
  fun `verify voice search helper error localization into hindi`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val error1 = com.example.util.VoiceSearchHelper.getHindiErrorMessage(android.speech.SpeechRecognizer.ERROR_NO_MATCH)
    assertTrue(error1.contains("कोई आवाज़ या शब्द नहीं पहचाना गया"))

    val error2 = com.example.util.VoiceSearchHelper.getHindiErrorMessage(android.speech.SpeechRecognizer.ERROR_NETWORK)
    assertTrue(error2.contains("इंटरनेट कनेक्शन"))

    val error3 = com.example.util.VoiceSearchHelper.getHindiErrorMessage(android.speech.SpeechRecognizer.ERROR_AUDIO)
    assertTrue(error3.contains("ऑडियो रिकॉर्डिंग"))
  }
}
