package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateTimeUtil {

    private val HINDI_MONTHS = arrayOf(
        "जनवरी", "फरवरी", "मार्च", "अप्रैल", "मई", "जून",
        "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"
    )

    /**
     * Formats a given timestamp or current date into a full Hindi publication date string,
     * e.g., "22 अगस्त 2026, 11:35 AM"
     */
    fun formatPublicationDate(date: Date = Date()): String {
        val calendar = Calendar.getInstance()
        calendar.time = date

        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val monthIndex = calendar.get(Calendar.MONTH)
        val year = calendar.get(Calendar.YEAR)
        val monthNameHindi = if (monthIndex in HINDI_MONTHS.indices) HINDI_MONTHS[monthIndex] else "अगस्त"

        val timeFormat = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
        val timeString = timeFormat.format(date)

        return "$day $monthNameHindi $year, $timeString"
    }

    /**
     * Formats publication date with a relative offset (e.g. 10 minutes ago, 1 hour ago)
     */
    fun formatWithOffset(minutesAgo: Int): Pair<String, String> {
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.MINUTE, -minutesAgo)
        val publishDate = formatPublicationDate(calendar.time)

        val timeAgo = when {
            minutesAgo <= 1 -> "अभी-अभी (ताज़ा अपडेट)"
            minutesAgo < 60 -> "$minutesAgo मिनट पहले"
            minutesAgo < 120 -> "1 घंटा पहले"
            minutesAgo < 1440 -> "${minutesAgo / 60} घंटे पहले"
            else -> "${minutesAgo / 1440} दिन पहले"
        }

        return Pair(publishDate, timeAgo)
    }

    /**
     * Returns current date in short Hindi format (e.g., "22 अगस्त 2026")
     */
    fun getTodayHindiDate(): String {
        val calendar = Calendar.getInstance()
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val monthIndex = calendar.get(Calendar.MONTH)
        val year = calendar.get(Calendar.YEAR)
        val monthNameHindi = if (monthIndex in HINDI_MONTHS.indices) HINDI_MONTHS[monthIndex] else "अगस्त"
        return "$day $monthNameHindi $year"
    }
}
