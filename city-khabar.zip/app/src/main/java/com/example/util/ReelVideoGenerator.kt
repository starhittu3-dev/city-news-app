package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Log
import com.example.model.NewsItem
import com.example.model.ReelColorTheme
import com.example.model.ReelCustomization
import com.example.model.ReelItem
import com.example.model.ReelTemplateType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object ReelVideoGenerator {

    private const val TAG = "ReelVideoGenerator"
    private const val VIDEO_WIDTH = 720
    private const val VIDEO_HEIGHT = 1280
    private const val FRAME_RATE = 25
    private const val BIT_RATE = 2_500_000 // 2.5 Mbps
    private const val I_FRAME_INTERVAL = 1 // 1 sec
    private const val DURATION_SECONDS = 5 // 5 seconds per reel

    /**
     * Generates or retrieves the cached playable MP4 video for a given ReelItem.
     */
    suspend fun getOrGenerateReelVideo(context: Context, reel: ReelItem): File = withContext(Dispatchers.IO) {
        val reelsDir = File(context.filesDir, "reels_cache").apply { mkdirs() }
        val outputFile = File(reelsDir, "reel_${reel.id.replace("[^a-zA-Z0-9_]".toRegex(), "_")}.mp4")

        if (outputFile.exists() && outputFile.length() > 1024) {
            return@withContext outputFile
        }

        val customization = ReelCustomization(
            selectedArticleId = reel.id,
            headline = reel.title,
            summary = reel.description,
            cityHindi = reel.cityHindi,
            categoryHindi = reel.category,
            reporterName = reel.reporter,
            imageResId = reel.imageResId,
            templateType = ReelTemplateType.BREAKING_FLASH,
            colorTheme = ReelColorTheme.ORANGE_FIRE
        )

        encodeReelToMp4(context, customization, outputFile)
        outputFile
    }

    /**
     * Generates a playable MP4 video file from user customization (Create Reel studio).
     */
    suspend fun generateCustomReelVideo(
        context: Context,
        customization: ReelCustomization,
        onProgress: (Float) -> Unit = {}
    ): File = withContext(Dispatchers.IO) {
        val reelsDir = File(context.filesDir, "reels_created").apply { mkdirs() }
        val fileName = "custom_reel_${System.currentTimeMillis()}.mp4"
        val outputFile = File(reelsDir, fileName)

        encodeReelToMp4(context, customization, outputFile, onProgress)
        outputFile
    }

    /**
     * Encodes 9:16 vertical video frames into a standard H.264 / AVC MP4 file.
     */
    private fun encodeReelToMp4(
        context: Context,
        reel: ReelCustomization,
        outputFile: File,
        onProgress: (Float) -> Unit = {}
    ) {
        val totalFrames = FRAME_RATE * DURATION_SECONDS
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var surface: android.view.Surface? = null
        var muxerStarted = false

        try {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, VIDEO_WIDTH, VIDEO_HEIGHT).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, BIT_RATE)
                setInteger(MediaFormat.KEY_FRAME_RATE, FRAME_RATE)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, I_FRAME_INTERVAL)
            }

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = encoder.createInputSurface()
            encoder.start()

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var videoTrackIndex = -1
            val bufferInfo = MediaCodec.BufferInfo()

            // Pre-load background image bitmap
            val origBitmap: Bitmap? = if (reel.imageResId != 0) {
                try {
                    BitmapFactory.decodeResource(context.resources, reel.imageResId)
                } catch (e: Exception) {
                    null
                }
            } else null

            val frameTimeUs = 1_000_000L / FRAME_RATE

            for (frameIndex in 0 until totalFrames) {
                val progress = frameIndex.toFloat() / totalFrames
                onProgress(progress)

                // Render frame onto the encoder's input surface
                val canvas: Canvas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    surface.lockHardwareCanvas()
                } else {
                    @Suppress("DEPRECATION")
                    surface.lockCanvas(null)
                }

                try {
                    drawVideoFrame(
                        canvas = canvas,
                        width = VIDEO_WIDTH,
                        height = VIDEO_HEIGHT,
                        reel = reel,
                        bgBitmap = origBitmap,
                        frameIndex = frameIndex,
                        totalFrames = totalFrames
                    )
                } finally {
                    surface.unlockCanvasAndPost(canvas)
                }

                // Drain encoder outputs to muxer
                var outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000)
                while (outputBufferIndex >= 0) {
                    val encodedData = encoder.getOutputBuffer(outputBufferIndex)
                    if (encodedData != null) {
                        if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                            bufferInfo.size = 0
                        }

                        if (bufferInfo.size != 0) {
                            if (!muxerStarted) {
                                val newFormat = encoder.outputFormat
                                videoTrackIndex = muxer.addTrack(newFormat)
                                muxer.start()
                                muxerStarted = true
                            }

                            bufferInfo.presentationTimeUs = frameIndex * frameTimeUs
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                        }
                    }
                    encoder.releaseOutputBuffer(outputBufferIndex, false)
                    outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, 0)
                }
            }

            // Signal End of Stream
            encoder.signalEndOfInputStream()

            // Drain remaining frames
            var done = false
            var tries = 0
            while (!done && tries < 30) {
                tries++
                val outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, 20_000)
                if (outputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    done = true
                } else if (outputBufferIndex >= 0) {
                    val encodedData = encoder.getOutputBuffer(outputBufferIndex)
                    if (encodedData != null && bufferInfo.size != 0 && muxerStarted) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                    }
                    encoder.releaseOutputBuffer(outputBufferIndex, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        done = true
                    }
                }
            }

            onProgress(1.0f)
            Log.d(TAG, "Reel video successfully encoded to: ${outputFile.absolutePath} (${outputFile.length()} bytes)")
        } catch (e: Exception) {
            Log.e(TAG, "Hardware video encoding error: ${e.message}", e)
            try {
                if (outputFile.exists()) {
                    outputFile.delete()
                }
            } catch (_: Exception) {}
        } finally {
            try {
                surface?.release()
            } catch (_: Exception) {}
            try {
                encoder?.stop()
            } catch (_: Exception) {}
            try {
                encoder?.release()
            } catch (_: Exception) {}
            try {
                if (muxerStarted) {
                    muxer?.stop()
                }
            } catch (_: Exception) {}
            try {
                muxer?.release()
            } catch (_: Exception) {}
        }
    }

    /**
     * Fallback generator to ensure a valid video or clean handling if hardware encoder is unavailable.
     */
    private fun generateFallbackValidMp4(context: Context, reel: ReelCustomization, outputFile: File) {
        try {
            if (outputFile.exists()) {
                outputFile.delete()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Fallback cleanup error: ${e.message}")
        }
    }

    /**
     * Draws an animated 9:16 frame for the reel video.
     * Features:
     * - Subtle Ken Burns pan/zoom on hero photograph
     * - Pulsing live broadcast breaking badge
     * - Animated lower-thirds headline banner and ticker
     * - Reporter byline and dynamic city identifier
     */
    private fun drawVideoFrame(
        canvas: Canvas,
        width: Int,
        height: Int,
        reel: ReelCustomization,
        bgBitmap: Bitmap?,
        frameIndex: Int,
        totalFrames: Int
    ) {
        val progress = frameIndex.toFloat() / totalFrames.coerceAtLeast(1)

        // 1. Primary Colors
        val primaryColor = when (reel.colorTheme) {
            ReelColorTheme.ORANGE_FIRE -> AndroidColor.parseColor("#E64A19")
            ReelColorTheme.CRIMSON_DARK -> AndroidColor.parseColor("#D32F2F")
            ReelColorTheme.SAFFRON_ROYAL -> AndroidColor.parseColor("#FF6F00")
            ReelColorTheme.MIDNIGHT_CYBER -> AndroidColor.parseColor("#00E5FF")
            ReelColorTheme.EMERALD_GREEN -> AndroidColor.parseColor("#00C853")
        }

        // Dark Canvas Background
        val bgPaint = Paint().apply {
            color = AndroidColor.parseColor("#0A0E17")
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // 2. Animated Hero Image with smooth Ken Burns zoom
        if (bgBitmap != null) {
            val scale = 1.0f + (progress * 0.08f) // 1.0 -> 1.08
            val panY = (progress * 20f)

            val scaledWidth = (width * scale).toInt()
            val scaledHeight = (height * scale).toInt()
            val offsetX = (scaledWidth - width) / 2f
            val offsetY = (scaledHeight - height) / 2f - panY

            val destRect = RectF(-offsetX, -offsetY, width + offsetX, height + offsetY)
            val srcRect = Rect(0, 0, bgBitmap.width, bgBitmap.height)
            val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(bgBitmap, srcRect, destRect, imgPaint)
        }

        // 3. Cinematic Gradients
        val gradientPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                intArrayOf(
                    AndroidColor.parseColor("#D9000000"),
                    AndroidColor.parseColor("#33000000"),
                    AndroidColor.parseColor("#CC000000"),
                    AndroidColor.parseColor("#FA0B0E14")
                ),
                floatArrayOf(0f, 0.3f, 0.6f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), gradientPaint)

        // 4. Top Header Branding
        val headerPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), 0f,
                primaryColor,
                AndroidColor.parseColor("#B71C1C"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), 130f, headerPaint)

        val logoPaint = TextPaint().apply {
            color = AndroidColor.WHITE
            textSize = 42f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("सिटी ख़बर | CITY KHABAR", 40f, 85f, logoPaint)

        // Pulsing Live Indicator
        val pulseAlpha = (180 + (75 * Math.sin(frameIndex * 0.3)).toInt()).coerceIn(0, 255)
        val liveBadgePaint = Paint().apply {
            color = AndroidColor.argb(pulseAlpha, 255, 23, 68)
            isAntiAlias = true
        }
        val liveBadgeRect = RectF(width - 210f, 35f, width - 40f, 95f)
        canvas.drawRoundRect(liveBadgeRect, 16f, 16f, liveBadgePaint)

        val liveTextPaint = TextPaint().apply {
            color = AndroidColor.WHITE
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("🔴 लाइव रील", width - 195f, 76f, liveTextPaint)

        // 5. Lower-Third Content Card
        val cardY = height - 580f
        val cardRect = RectF(30f, cardY, width - 30f, height - 100f)
        val cardBgPaint = Paint().apply {
            color = AndroidColor.parseColor("#EB121722")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(cardRect, 28f, 28f, cardBgPaint)

        val cardBorder = Paint().apply {
            color = primaryColor
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(cardRect, 28f, 28f, cardBorder)

        var contentY = cardY + 50f

        // Badges Row (City & Category)
        var curX = 55f
        if (reel.showCityBadge && reel.cityHindi.isNotBlank()) {
            val cityPaint = Paint().apply {
                color = primaryColor
                isAntiAlias = true
            }
            val textPaint = TextPaint().apply {
                color = AndroidColor.WHITE
                textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val text = "📍 ${reel.cityHindi}"
            val textWidth = textPaint.measureText(text)
            val rect = RectF(curX, contentY, curX + textWidth + 30f, contentY + 44f)
            canvas.drawRoundRect(rect, 10f, 10f, cityPaint)
            canvas.drawText(text, curX + 15f, contentY + 31f, textPaint)
            curX += textWidth + 45f
        }

        if (reel.showCategoryBadge && reel.categoryHindi.isNotBlank()) {
            val catPaint = Paint().apply {
                color = AndroidColor.parseColor("#37474F")
                isAntiAlias = true
            }
            val textPaint = TextPaint().apply {
                color = AndroidColor.WHITE
                textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val text = reel.categoryHindi
            val textWidth = textPaint.measureText(text)
            val rect = RectF(curX, contentY, curX + textWidth + 30f, contentY + 44f)
            canvas.drawRoundRect(rect, 10f, 10f, catPaint)
            canvas.drawText(text, curX + 15f, contentY + 31f, textPaint)
        }

        contentY += 65f

        // Headline Text
        val headlinePaint = TextPaint().apply {
            color = AndroidColor.WHITE
            textSize = 42f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val headlineText = reel.headline.ifBlank { "सिटी खबर: आज की प्रमुख वीडियो रिपोर्ट" }
        val headlineLayout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(headlineText, 0, headlineText.length, headlinePaint, width - 110)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(8f, 1.15f)
                .setIncludePad(true)
                .setMaxLines(3)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(headlineText, headlinePaint, width - 110, Layout.Alignment.ALIGN_NORMAL, 1.15f, 8f, true)
        }

        canvas.save()
        canvas.translate(55f, contentY)
        headlineLayout.draw(canvas)
        canvas.restore()

        contentY += headlineLayout.height + 15f

        // Summary Snippet
        if (reel.summary.isNotBlank()) {
            val summaryPaint = TextPaint().apply {
                color = AndroidColor.parseColor("#CFD8DC")
                textSize = 28f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                isAntiAlias = true
            }
            val summaryLayout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                StaticLayout.Builder.obtain(reel.summary, 0, reel.summary.length, summaryPaint, width - 110)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(6f, 1.1f)
                    .setIncludePad(true)
                    .setMaxLines(2)
                    .build()
            } else {
                @Suppress("DEPRECATION")
                StaticLayout(reel.summary, summaryPaint, width - 110, Layout.Alignment.ALIGN_NORMAL, 1.1f, 6f, true)
            }

            canvas.save()
            canvas.translate(55f, contentY)
            summaryLayout.draw(canvas)
            canvas.restore()
        }

        // 6. Bottom Footer & Progress Line
        val footerY = height - 90f
        val footerBg = Paint().apply {
            color = AndroidColor.parseColor("#F5080B10")
            isAntiAlias = true
        }
        canvas.drawRect(0f, footerY, width.toFloat(), height.toFloat(), footerBg)

        // Animated Video Progress Bar at the bottom of the video
        val progressTrackPaint = Paint().apply {
            color = AndroidColor.parseColor("#44FFFFFF")
            strokeWidth = 6f
        }
        canvas.drawLine(0f, footerY, width.toFloat(), footerY, progressTrackPaint)

        val progressPaint = Paint().apply {
            color = primaryColor
            strokeWidth = 6f
            isAntiAlias = true
        }
        canvas.drawLine(0f, footerY, width * progress, footerY, progressPaint)

        val repPaint = TextPaint().apply {
            color = AndroidColor.WHITE
            textSize = 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val reporter = if (reel.showReporter && reel.reporterName.isNotBlank()) "✍️ ${reel.reporterName}" else "📰 सिटी खबर स्पेशल"
        canvas.drawText(reporter, 40f, footerY + 54f, repPaint)

        if (reel.showWatermark) {
            val wmPaint = TextPaint().apply {
                color = primaryColor
                textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val wm = "citykhabar.in"
            val wmW = wmPaint.measureText(wm)
            canvas.drawText(wm, width - wmW - 40f, footerY + 54f, wmPaint)
        }
    }
}
