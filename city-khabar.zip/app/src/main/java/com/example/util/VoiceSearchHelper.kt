package com.example.util

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * State representation of the Hindi Voice Search Engine.
 */
sealed class VoiceSearchUiState {
    data object Idle : VoiceSearchUiState()
    data object Initializing : VoiceSearchUiState()
    data class Listening(val rmsDb: Float = 0f) : VoiceSearchUiState()
    data object Processing : VoiceSearchUiState()
    data class Success(val spokenText: String) : VoiceSearchUiState()
    data class Error(val errorMessageHindi: String, val canRetry: Boolean = true) : VoiceSearchUiState()
}

/**
 * Voice Search Controller configured for Hindi (hi-IN) speech recognition.
 */
class VoiceSearchHelper(private val context: Context) {

    private val _uiState = MutableStateFlow<VoiceSearchUiState>(VoiceSearchUiState.Idle)
    val uiState: StateFlow<VoiceSearchUiState> = _uiState.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null

    val isRecognitionAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(
        onResult: ((String) -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        stopListening()

        if (!isRecognitionAvailable) {
            val errorMsg = "इस डिवाइस पर वॉइस सर्च की सुविधा उपलब्ध नहीं है।"
            _uiState.value = VoiceSearchUiState.Error(errorMsg, canRetry = false)
            onError?.invoke(errorMsg)
            return
        }

        try {
            _uiState.value = VoiceSearchUiState.Initializing

            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _uiState.value = VoiceSearchUiState.Listening(0f)
                    }

                    override fun onBeginningOfSpeech() {
                        _uiState.value = VoiceSearchUiState.Listening(0f)
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        val current = _uiState.value
                        if (current is VoiceSearchUiState.Listening) {
                            _uiState.value = VoiceSearchUiState.Listening(rmsdB.coerceAtLeast(0f))
                        }
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _uiState.value = VoiceSearchUiState.Processing
                    }

                    override fun onError(errorCode: Int) {
                        val hindiError = getHindiErrorMessage(errorCode)
                        _uiState.value = VoiceSearchUiState.Error(hindiError, canRetry = true)
                        onError?.invoke(hindiError)
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull()?.trim()

                        if (!spokenText.isNullOrBlank()) {
                            _uiState.value = VoiceSearchUiState.Success(spokenText)
                            onResult?.invoke(spokenText)
                        } else {
                            val noMatchMsg = "कोई शब्द पहचाना नहीं जा सका। कृपया दोबारा बोलें।"
                            _uiState.value = VoiceSearchUiState.Error(noMatchMsg, canRetry = true)
                            onError?.invoke(noMatchMsg)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val partialText = matches?.firstOrNull()?.trim()
                        if (!partialText.isNullOrBlank()) {
                            // Can show live partial transcription
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "हिंदी में समाचार खोजें...")
                putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("hi-IN", "hi", "en-IN", "en"))
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }

            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            val errorMsg = "वॉइस सर्च शुरू करने में समस्या आई: ${e.localizedMessage ?: "कृपया दोबारा प्रयास करें।"}"
            _uiState.value = VoiceSearchUiState.Error(errorMsg, canRetry = true)
            onError?.invoke(errorMsg)
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (ignored: Exception) {
        } finally {
            speechRecognizer = null
        }
    }

    fun reset() {
        stopListening()
        _uiState.value = VoiceSearchUiState.Idle
    }

    private fun getHindiErrorMessage(errorCode: Int): String {
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> "ऑडियो रिकॉर्ड करने में समस्या हुई। कृपया माइक जांचें।"
            SpeechRecognizer.ERROR_CLIENT -> "वॉइस सर्विस में अस्थायी त्रुटि हुई।"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "माइक (Microphone) की अनुमति नहीं मिली है।"
            SpeechRecognizer.ERROR_NETWORK -> "इंटरनेट कनेक्शन की समस्या है। कृपया नेटवर्क जांचें।"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "सर्वर से कनेक्ट होने में समय समाप्त हो गया।"
            SpeechRecognizer.ERROR_NO_MATCH -> "आवाज़ सुनाई नहीं दी या पहचानी नहीं जा सकी। कृपया दोबारा बोलें।"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "वॉइस सर्विस व्यस्त है, कृपया एक पल बाद प्रयास करें।"
            SpeechRecognizer.ERROR_SERVER -> "वॉइस सर्च सर्वर से कोई प्रतिक्रिया नहीं मिली।"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "कोई आवाज़ नहीं मिली। कृपया माइक के पास बोलें।"
            else -> "वॉइस सर्च में त्रुटि हुई। कृपया पुनः प्रयास करें।"
        }
    }
}
