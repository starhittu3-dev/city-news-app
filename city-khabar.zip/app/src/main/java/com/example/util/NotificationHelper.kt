package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.model.NotificationType

object NotificationHelper {

    const val CHANNEL_BREAKING = "city_khabar_breaking_channel"
    const val CHANNEL_IMPORTANT = "city_khabar_important_channel"
    const val CHANNEL_CITY = "city_khabar_city_channel"
    const val CHANNEL_DAILY = "city_khabar_daily_channel"
    const val CHANNEL_GENERAL = "city_khabar_general_channel"

    const val EXTRA_NEWS_ID = "EXTRA_NEWS_ID"
    const val EXTRA_OPEN_NOTIFICATIONS = "EXTRA_OPEN_NOTIFICATIONS"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // 1. Breaking News Channel (High Priority)
            val breakingChannel = NotificationChannel(
                CHANNEL_BREAKING,
                "🚨 ब्रेकिंग न्यूज़ (Breaking News Alerts)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "अति-महत्वपूर्ण ब्रेकिंग न्यूज़ और लाइव अपडेट्स"
                enableVibration(true)
                setShowBadge(true)
            }

            // 2. Important News Channel (High Priority)
            val importantChannel = NotificationChannel(
                CHANNEL_IMPORTANT,
                "⭐ महत्वपूर्ण समाचार (Important News)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "राज्य व राष्ट्रीय महत्वपूर्ण समाचार और विशेष सुर्खियां"
                enableVibration(true)
                setShowBadge(true)
            }

            // 3. Selected City News Channel
            val cityChannel = NotificationChannel(
                CHANNEL_CITY,
                "🏙️ चयनित शहर समाचार (City News)",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "आपके चयनित शहर की मुख्य घटनाएं और स्थानीय समाचार"
                enableVibration(true)
                setShowBadge(true)
            }

            // 4. Daily Bulletin Channel
            val dailyChannel = NotificationChannel(
                CHANNEL_DAILY,
                "📰 दैनिक समाचार बुलेटिन (Daily Updates)",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "सुबह और शाम का प्रमुख समाचार बुलेटिन"
                setShowBadge(true)
            }

            // 5. General / System Channel
            val generalChannel = NotificationChannel(
                CHANNEL_GENERAL,
                "🔔 सिटी ख़बर अपडेट्स (General Alerts)",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "ऐप सूचनाएं और सिस्टम संदेश"
            }

            notificationManager.createNotificationChannels(
                listOf(breakingChannel, importantChannel, cityChannel, dailyChannel, generalChannel)
            )
        }
    }

    fun sendSystemNotification(
        context: Context,
        notificationId: Int,
        title: String,
        message: String,
        type: NotificationType,
        newsId: String? = null
    ) {
        // Ensure channels are created
        createNotificationChannels(context)

        // Check POST_NOTIFICATIONS permission on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionCheck = ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            )
            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                // Cannot post system notification without permission, in-app notification list will still function
                return
            }
        }

        val channelId = when (type) {
            NotificationType.BREAKING_NEWS -> CHANNEL_BREAKING
            NotificationType.IMPORTANT_NEWS -> CHANNEL_IMPORTANT
            NotificationType.CITY_IMPORTANT -> CHANNEL_CITY
            NotificationType.DAILY_UPDATE -> CHANNEL_DAILY
            NotificationType.SYSTEM -> CHANNEL_GENERAL
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_NEWS_ID", newsId)
            putExtra("EXTRA_OPEN_NOTIFICATIONS", true)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val smallIcon = context.applicationInfo.icon.takeIf { it != 0 } ?: android.R.drawable.ic_dialog_info

        val notificationBuilder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(smallIcon)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(
                if (type == NotificationType.BREAKING_NEWS) NotificationCompat.PRIORITY_HIGH
                else NotificationCompat.PRIORITY_DEFAULT
            )
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        try {
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(notificationId, notificationBuilder.build())
        } catch (e: SecurityException) {
            // Permission not granted or restricted
        }
    }
}
