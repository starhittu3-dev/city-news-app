package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.model.PostColorTheme
import com.example.model.PostCustomization
import com.example.model.PostTemplateType
import com.example.model.ReelColorTheme
import com.example.model.ReelCustomization
import com.example.model.ReelTemplateType
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

object PostExportUtil {

    /**
     * Renders a high-resolution news post bitmap based on the template and customization.
     */
    fun renderPostBitmap(context: Context, post: PostCustomization): Bitmap {
        val width = 1080
        val height = when (post.templateType) {
            PostTemplateType.STORY_9_16 -> 1920
            PostTemplateType.SQUARE_SOCIAL -> 1080
            else -> 1350 // 4:5 standard portrait social card
        }

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Determine colors
        val isDarkTheme = post.colorTheme == PostColorTheme.CRIMSON_DARK || 
                          post.colorTheme == PostColorTheme.MIDNIGHT_BLACK
        
        val bgColor = when (post.colorTheme) {
            PostColorTheme.ORANGE_FIRE -> AndroidColor.parseColor("#FFF5F0")
            PostColorTheme.CRIMSON_DARK -> AndroidColor.parseColor("#150A0A")
            PostColorTheme.SAFFRON_GOLD -> AndroidColor.parseColor("#FFF9E6")
            PostColorTheme.MIDNIGHT_BLACK -> AndroidColor.parseColor("#0F141A")
            PostColorTheme.CLEAN_WHITE -> AndroidColor.parseColor("#FFFFFF")
        }

        val primaryBrandColor = when (post.colorTheme) {
            PostColorTheme.ORANGE_FIRE -> AndroidColor.parseColor("#E64A19")
            PostColorTheme.CRIMSON_DARK -> AndroidColor.parseColor("#D32F2F")
            PostColorTheme.SAFFRON_GOLD -> AndroidColor.parseColor("#F57C00")
            PostColorTheme.MIDNIGHT_BLACK -> AndroidColor.parseColor("#FF5722")
            PostColorTheme.CLEAN_WHITE -> AndroidColor.parseColor("#E64A19")
        }

        val textColor = if (isDarkTheme) AndroidColor.WHITE else AndroidColor.parseColor("#1A1A1A")
        val subTextColor = if (isDarkTheme) AndroidColor.parseColor("#B0BEC5") else AndroidColor.parseColor("#546E7A")

        // Draw Background
        val bgPaint = Paint().apply {
            color = bgColor
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Draw Header Banner
        val headerHeight = 160f
        val headerPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), 0f,
                primaryBrandColor,
                AndroidColor.parseColor("#BF360C"),
                Shader.TileMode.CLAMP
            )
            isAntiAlias = true
        }
        canvas.drawRect(0f, 0f, width.toFloat(), headerHeight, headerPaint)

        // Header Title (City Khabar / सिटी ख़बर)
        val brandPaint = TextPaint().apply {
            color = AndroidColor.WHITE
            textSize = 58f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("सिटी ख़बर | CITY KHABAR", 60f, 105f, brandPaint)

        // City Tag in Header
        if (post.showCityBadge && post.cityHindi.isNotBlank()) {
            val cityBadgePaint = Paint().apply {
                color = AndroidColor.parseColor("#33000000")
                isAntiAlias = true
            }
            val cityText = "📍 ${post.cityHindi}"
            val cityTextPaint = TextPaint().apply {
                color = AndroidColor.WHITE
                textSize = 38f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val badgeWidth = cityTextPaint.measureText(cityText) + 50f
            val badgeRect = RectF(width - badgeWidth - 50f, 50f, width - 50f, 120f)
            canvas.drawRoundRect(badgeRect, 20f, 20f, cityBadgePaint)
            canvas.drawText(cityText, width - badgeWidth - 25f, 100f, cityTextPaint)
        }

        var currentY = headerHeight + 30f

        // Breaking News Tag
        if (post.showBreakingTag) {
            val tagRect = RectF(60f, currentY, 400f, currentY + 65f)
            val tagPaint = Paint().apply {
                color = AndroidColor.parseColor("#E53935")
                isAntiAlias = true
            }
            canvas.drawRoundRect(tagRect, 12f, 12f, tagPaint)

            val tagTextPaint = TextPaint().apply {
                color = AndroidColor.WHITE
                textSize = 34f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.drawText("🔴 ब्रेकिंग न्यूज़", 85f, currentY + 46f, tagTextPaint)
            currentY += 95f
        }

        // Draw Image if present
        if (post.imageResId != 0) {
            try {
                val origBitmap = BitmapFactory.decodeResource(context.resources, post.imageResId)
                if (origBitmap != null) {
                    val imageHeight = when (post.templateType) {
                        PostTemplateType.STORY_9_16 -> 750
                        PostTemplateType.SQUARE_SOCIAL -> 450
                        else -> 520
                    }
                    val destRect = RectF(60f, currentY, width - 60f, currentY + imageHeight)
                    val srcRect = Rect(0, 0, origBitmap.width, origBitmap.height)
                    
                    // Draw rounded clip or background for image
                    val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    canvas.drawBitmap(origBitmap, srcRect, destRect, imgPaint)

                    // Draw subtle border around photo
                    val borderPaint = Paint().apply {
                        color = primaryBrandColor
                        style = Paint.Style.STROKE
                        strokeWidth = 6f
                        isAntiAlias = true
                    }
                    canvas.drawRoundRect(destRect, 16f, 16f, borderPaint)

                    currentY += imageHeight + 45f
                }
            } catch (_: Exception) {
                currentY += 20f
            }
        }

        // Headline Text (StaticLayout for multiline devnagari wrapping)
        val headlineTextPaint = TextPaint().apply {
            color = if (post.templateType == PostTemplateType.EDITORIAL_MINIMAL) primaryBrandColor else textColor
            textSize = when (post.templateType) {
                PostTemplateType.STORY_9_16 -> 52f
                PostTemplateType.SQUARE_SOCIAL -> 46f
                else -> 54f
            }
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val textWidth = (width - 120)
        val headline = post.headline.ifBlank { "सिटी खबर: शहर की सबसे बड़ी ताज़ा खबर" }

        val headlineLayout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(headline, 0, headline.length, headlineTextPaint, textWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(10f, 1.15f)
                .setIncludePad(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(headline, headlineTextPaint, textWidth, Layout.Alignment.ALIGN_NORMAL, 1.15f, 10f, true)
        }

        canvas.save()
        canvas.translate(60f, currentY)
        headlineLayout.draw(canvas)
        canvas.restore()

        currentY += headlineLayout.height + 30f

        // Short Summary Text
        if (post.summary.isNotBlank()) {
            val summaryTextPaint = TextPaint().apply {
                color = subTextColor
                textSize = 36f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                isAntiAlias = true
            }

            val summaryLayout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                StaticLayout.Builder.obtain(post.summary, 0, post.summary.length, summaryTextPaint, textWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(8f, 1.15f)
                    .setIncludePad(true)
                    .build()
            } else {
                @Suppress("DEPRECATION")
                StaticLayout(post.summary, summaryTextPaint, textWidth, Layout.Alignment.ALIGN_NORMAL, 1.15f, 8f, true)
            }

            canvas.save()
            canvas.translate(60f, currentY)
            summaryLayout.draw(canvas)
            canvas.restore()
        }

        // Draw Footer Bar
        val footerHeight = 120f
        val footerY = height - footerHeight
        val footerBgPaint = Paint().apply {
            color = if (isDarkTheme) AndroidColor.parseColor("#1C232B") else AndroidColor.parseColor("#ECEFF1")
            isAntiAlias = true
        }
        canvas.drawRect(0f, footerY, width.toFloat(), height.toFloat(), footerBgPaint)

        // Accent line above footer
        val accentLinePaint = Paint().apply {
            color = primaryBrandColor
            strokeWidth = 6f
            isAntiAlias = true
        }
        canvas.drawLine(0f, footerY, width.toFloat(), footerY, accentLinePaint)

        // Footer Info: Reporter and Watermark
        val footerTextPaint = TextPaint().apply {
            color = if (isDarkTheme) AndroidColor.WHITE else AndroidColor.parseColor("#37474F")
            textSize = 32f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val reporter = if (post.showReporter && post.reporterName.isNotBlank()) "✍️ ${post.reporterName}" else "📰 सिटी खबर स्पेशल"
        canvas.drawText(reporter, 60f, footerY + 70f, footerTextPaint)

        if (post.showWatermark) {
            val watermarkPaint = TextPaint().apply {
                color = primaryBrandColor
                textSize = 32f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val watermarkText = "citykhabar.in"
            val wmWidth = watermarkPaint.measureText(watermarkText)
            canvas.drawText(watermarkText, width - wmWidth - 60f, footerY + 70f, watermarkPaint)
        }

        return bitmap
    }

    /**
     * Saves bitmap to device Pictures / MediaStore gallery and returns local file or Uri.
     */
    fun saveBitmapToGallery(context: Context, bitmap: Bitmap, title: String): Uri? {
        val fileName = "CityKhabar_${System.currentTimeMillis()}.png"
        var uri: Uri? = null

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CityKhabar")
                }
                val resolver = context.contentResolver
                uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    val out: OutputStream? = resolver.openOutputStream(uri)
                    if (out != null) {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                        out.flush()
                        out.close()
                    }
                }
            } else {
                val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + "/CityKhabar"
                val file = File(imagesDir)
                if (!file.exists()) file.mkdirs()
                val imageFile = File(imagesDir, fileName)
                val out = FileOutputStream(imageFile)
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
                out.close()
                uri = Uri.fromFile(imageFile)
            }
            Toast.makeText(context, "✅ पोस्ट गैलरी में सफलतापूर्वक सेव हो गया!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "सेव करने में त्रुटि: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
        return uri
    }

    /**
     * Shares the news post with image and pre-formatted Hindi caption.
     */
    fun sharePost(context: Context, post: PostCustomization) {
        try {
            val bitmap = renderPostBitmap(context, post)
            
            // Save to temporary cache for sharing via FileProvider
            val cachePath = File(context.cacheDir, "images")
            cachePath.mkdirs()
            val tempFile = File(cachePath, "city_khabar_share.png")
            val stream = FileOutputStream(tempFile)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            stream.close()

            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                tempFile
            )

            val shareCaption = buildString {
                append("📢 *${post.headline}*\n\n")
                if (post.summary.isNotBlank()) {
                    append("${post.summary}\n\n")
                }
                if (post.cityHindi.isNotBlank()) {
                    append("📍 शहर: ${post.cityHindi}\n")
                }
                append("📰 स्रोत: सिटी खबर (City Khabar)\n")
                append("📲 ताज़ा खबरों के लिए डाउनलोड करें 'सिटी खबर' ऐप\n")
                append("#CityKhabar #HindiNews #सिटीखबर #BreakingNews #${post.cityHindi.replace(" ", "")}")
            }

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_TEXT, shareCaption)
                putExtra(Intent.EXTRA_SUBJECT, post.headline)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(Intent.createChooser(intent, "खबर पोस्ट शेयर करें (Share News)"))
        } catch (e: Exception) {
            // Fallback to text share if image generation fails
            val textIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "${post.headline}\n\n${post.summary}\n\n- सिटी खबर")
            }
            context.startActivity(Intent.createChooser(textIntent, "खबर शेयर करें"))
        }
    }

    /**
     * Renders a dedicated, pixel-perfect 9:16 high-resolution (1080x1920) vertical video reel bitmap.
     */
    fun renderReelBitmap(context: Context, reel: ReelCustomization): Bitmap {
        val width = 1080
        val height = 1920

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val primaryColor = when (reel.colorTheme) {
            ReelColorTheme.ORANGE_FIRE -> AndroidColor.parseColor("#E64A19")
            ReelColorTheme.CRIMSON_DARK -> AndroidColor.parseColor("#D32F2F")
            ReelColorTheme.SAFFRON_ROYAL -> AndroidColor.parseColor("#F57C00")
            ReelColorTheme.MIDNIGHT_CYBER -> AndroidColor.parseColor("#FF5722")
            ReelColorTheme.EMERALD_GREEN -> AndroidColor.parseColor("#2E7D32")
        }

        val secondaryColor = when (reel.colorTheme) {
            ReelColorTheme.ORANGE_FIRE -> AndroidColor.parseColor("#BF360C")
            ReelColorTheme.CRIMSON_DARK -> AndroidColor.parseColor("#B71C1C")
            ReelColorTheme.SAFFRON_ROYAL -> AndroidColor.parseColor("#E65100")
            ReelColorTheme.MIDNIGHT_CYBER -> AndroidColor.parseColor("#00E5FF")
            ReelColorTheme.EMERALD_GREEN -> AndroidColor.parseColor("#00C853")
        }

        val bgColor = when (reel.colorTheme) {
            ReelColorTheme.ORANGE_FIRE -> AndroidColor.parseColor("#140702")
            ReelColorTheme.CRIMSON_DARK -> AndroidColor.parseColor("#150A0A")
            ReelColorTheme.SAFFRON_ROYAL -> AndroidColor.parseColor("#1C1304")
            ReelColorTheme.MIDNIGHT_CYBER -> AndroidColor.parseColor("#0A0E17")
            ReelColorTheme.EMERALD_GREEN -> AndroidColor.parseColor("#051408")
        }

        // Base Background Fill
        val bgPaint = Paint().apply {
            color = bgColor
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Draw Template-Specific Layouts
        when (reel.templateType) {
            ReelTemplateType.CINEMATIC_OVERLAY -> {
                // 1. Cinematic Fullscreen Bleed
                if (reel.imageResId != 0) {
                    try {
                        val origBitmap = BitmapFactory.decodeResource(context.resources, reel.imageResId)
                        if (origBitmap != null) {
                            val destRect = RectF(0f, 0f, width.toFloat(), height.toFloat())
                            val srcRect = Rect(0, 0, origBitmap.width, origBitmap.height)
                            val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                            canvas.drawBitmap(origBitmap, srcRect, destRect, imgPaint)
                        }
                    } catch (_: Exception) {}
                }

                // Dark Gradients: Top status bar & Bottom heavy reading gradient
                val gradientPaint = Paint().apply {
                    shader = LinearGradient(
                        0f, 0f, 0f, height.toFloat(),
                        intArrayOf(
                            AndroidColor.parseColor("#CC000000"),
                            AndroidColor.parseColor("#44000000"),
                            AndroidColor.parseColor("#DD000000"),
                            AndroidColor.parseColor("#FA000000")
                        ),
                        floatArrayOf(0f, 0.35f, 0.65f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    isAntiAlias = true
                }
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), gradientPaint)

                // Top Header Branding
                drawTopReelHeader(canvas, width, reel, primaryColor)

                // Bottom Content Glass Card
                val cardY = height - 760f
                val cardRect = RectF(50f, cardY, width - 50f, height - 120f)
                val cardPaint = Paint().apply {
                    color = AndroidColor.parseColor("#EE161B22")
                    style = Paint.Style.FILL
                    isAntiAlias = true
                }
                canvas.drawRoundRect(cardRect, 36f, 36f, cardPaint)

                // Glowing border
                val cardBorder = Paint().apply {
                    color = primaryColor
                    style = Paint.Style.STROKE
                    strokeWidth = 4f
                    isAntiAlias = true
                }
                canvas.drawRoundRect(cardRect, 36f, 36f, cardBorder)

                // Badges row inside card
                var innerY = cardY + 60f
                drawReelBadges(canvas, 90f, innerY, reel, primaryColor)
                innerY += 70f

                // Headline
                innerY = drawReelHeadline(canvas, 90f, innerY, width - 180, reel.headline, AndroidColor.WHITE, 54f)
                innerY += 20f

                // Summary
                if (reel.summary.isNotBlank()) {
                    drawReelSummary(canvas, 90f, innerY, width - 180, reel.summary, AndroidColor.parseColor("#ECEFF1"), 36f)
                }

                // Reporter Byline & Watermark at bottom
                drawReelFooter(canvas, width, height, reel, primaryColor)
            }

            ReelTemplateType.STUDIO_BULLETIN -> {
                // Top Header Bar
                drawTopReelHeader(canvas, width, reel, primaryColor)

                // Featured Center Video Frame
                val imageY = 220f
                val imageHeight = 900f
                if (reel.imageResId != 0) {
                    try {
                        val origBitmap = BitmapFactory.decodeResource(context.resources, reel.imageResId)
                        if (origBitmap != null) {
                            val destRect = RectF(50f, imageY, width - 50f, imageY + imageHeight)
                            val srcRect = Rect(0, 0, origBitmap.width, origBitmap.height)
                            val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                            canvas.drawBitmap(origBitmap, srcRect, destRect, imgPaint)

                            // Frame Border
                            val borderPaint = Paint().apply {
                                color = primaryColor
                                style = Paint.Style.STROKE
                                strokeWidth = 8f
                                isAntiAlias = true
                            }
                            canvas.drawRoundRect(destRect, 28f, 28f, borderPaint)
                        }
                    } catch (_: Exception) {}
                }

                // Studio Bulletin Lower-Third Tag
                val tagY = imageY + imageHeight - 80f
                val tagRect = RectF(80f, tagY, 480f, tagY + 70f)
                val tagPaint = Paint().apply {
                    color = AndroidColor.parseColor("#E53935")
                    style = Paint.Style.FILL
                    isAntiAlias = true
                }
                canvas.drawRoundRect(tagRect, 14f, 14f, tagPaint)
                val tagTextPaint = TextPaint().apply {
                    color = AndroidColor.WHITE
                    textSize = 34f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    isAntiAlias = true
                }
                canvas.drawText("🔴 लाइव बुलेटिन", 110f, tagY + 48f, tagTextPaint)

                // Yellow News Anchor Headline Lower-Third Banner
                val newsBoxY = imageY + imageHeight + 40f
                val newsBoxRect = RectF(50f, newsBoxY, width - 50f, height - 160f)
                val boxPaint = Paint().apply {
                    color = AndroidColor.parseColor("#FFFDE7")
                    style = Paint.Style.FILL
                    isAntiAlias = true
                }
                canvas.drawRoundRect(newsBoxRect, 28f, 28f, boxPaint)

                // Yellow Headline Stripe
                val stripeRect = RectF(50f, newsBoxY, width - 50f, newsBoxY + 110f)
                val stripePaint = Paint().apply {
                    color = AndroidColor.parseColor("#FDD835")
                    isAntiAlias = true
                }
                canvas.drawRoundRect(stripeRect, 28f, 28f, stripePaint)

                val stripeTextPaint = TextPaint().apply {
                    color = AndroidColor.parseColor("#212121")
                    textSize = 40f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    isAntiAlias = true
                }
                canvas.drawText("⚡ शहर की सबसे बड़ी खबर: ${reel.cityHindi}", 80f, newsBoxY + 70f, stripeTextPaint)

                var innerY = newsBoxY + 150f
                innerY = drawReelHeadline(canvas, 80f, innerY, width - 160, reel.headline, AndroidColor.parseColor("#1A1A1A"), 50f)
                innerY += 20f
                if (reel.summary.isNotBlank()) {
                    drawReelSummary(canvas, 80f, innerY, width - 160, reel.summary, AndroidColor.parseColor("#424242"), 36f)
                }

                drawReelFooter(canvas, width, height, reel, primaryColor)
            }

            ReelTemplateType.MAGAZINE_HIGHLIGHT -> {
                // Editorial Saffron/Gold Framing
                val borderFrame = Paint().apply {
                    color = primaryColor
                    style = Paint.Style.STROKE
                    strokeWidth = 14f
                    isAntiAlias = true
                }
                canvas.drawRect(15f, 15f, width - 15f, height - 15f, borderFrame)

                drawTopReelHeader(canvas, width, reel, primaryColor)

                // Hero Image
                val imageY = 240f
                val imageHeight = 820f
                if (reel.imageResId != 0) {
                    try {
                        val origBitmap = BitmapFactory.decodeResource(context.resources, reel.imageResId)
                        if (origBitmap != null) {
                            val destRect = RectF(60f, imageY, width - 60f, imageY + imageHeight)
                            val srcRect = Rect(0, 0, origBitmap.width, origBitmap.height)
                            val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                            canvas.drawBitmap(origBitmap, srcRect, destRect, imgPaint)
                        }
                    } catch (_: Exception) {}
                }

                // Magazine White Card
                val cardY = imageY + imageHeight + 30f
                val cardRect = RectF(60f, cardY, width - 60f, height - 150f)
                val cardPaint = Paint().apply {
                    color = AndroidColor.parseColor("#FFFDF9")
                    isAntiAlias = true
                }
                canvas.drawRoundRect(cardRect, 24f, 24f, cardPaint)

                var innerY = cardY + 60f
                drawReelBadges(canvas, 90f, innerY, reel, primaryColor, onLightBg = true)
                innerY += 70f

                innerY = drawReelHeadline(canvas, 90f, innerY, width - 180, reel.headline, AndroidColor.parseColor("#1B1B1B"), 50f)
                innerY += 24f

                // Accent Line
                val linePaint = Paint().apply {
                    color = primaryColor
                    strokeWidth = 6f
                    isAntiAlias = true
                }
                canvas.drawLine(90f, innerY, 200f, innerY, linePaint)
                innerY += 35f

                if (reel.summary.isNotBlank()) {
                    drawReelSummary(canvas, 90f, innerY, width - 180, reel.summary, AndroidColor.parseColor("#4A4A4A"), 36f)
                }

                drawReelFooter(canvas, width, height, reel, primaryColor)
            }

            ReelTemplateType.MIDNIGHT_NEON -> {
                // Cyber Dark Backdrop with Neon Grid Glow
                val glowPaint = Paint().apply {
                    shader = LinearGradient(
                        0f, 0f, width.toFloat(), height.toFloat(),
                        AndroidColor.parseColor("#1A237E"),
                        AndroidColor.parseColor("#000000"),
                        Shader.TileMode.CLAMP
                    )
                    isAntiAlias = true
                }
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), glowPaint)

                drawTopReelHeader(canvas, width, reel, primaryColor)

                // Neon framed photo
                val imageY = 230f
                val imageHeight = 820f
                if (reel.imageResId != 0) {
                    try {
                        val origBitmap = BitmapFactory.decodeResource(context.resources, reel.imageResId)
                        if (origBitmap != null) {
                            val destRect = RectF(60f, imageY, width - 60f, imageY + imageHeight)
                            val srcRect = Rect(0, 0, origBitmap.width, origBitmap.height)
                            val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                            canvas.drawBitmap(origBitmap, srcRect, destRect, imgPaint)

                            // Neon Cyan/Orange Stroke
                            val neonStroke = Paint().apply {
                                color = secondaryColor
                                style = Paint.Style.STROKE
                                strokeWidth = 8f
                                isAntiAlias = true
                            }
                            canvas.drawRoundRect(destRect, 28f, 28f, neonStroke)
                        }
                    } catch (_: Exception) {}
                }

                // Dark Neon Card
                val cardY = imageY + imageHeight + 40f
                val cardRect = RectF(60f, cardY, width - 60f, height - 160f)
                val cardPaint = Paint().apply {
                    color = AndroidColor.parseColor("#E60D1524")
                    isAntiAlias = true
                }
                canvas.drawRoundRect(cardRect, 28f, 28f, cardPaint)

                val cardStroke = Paint().apply {
                    color = primaryColor
                    style = Paint.Style.STROKE
                    strokeWidth = 4f
                    isAntiAlias = true
                }
                canvas.drawRoundRect(cardRect, 28f, 28f, cardStroke)

                var innerY = cardY + 60f
                drawReelBadges(canvas, 90f, innerY, reel, secondaryColor)
                innerY += 70f

                innerY = drawReelHeadline(canvas, 90f, innerY, width - 180, reel.headline, AndroidColor.parseColor("#FFFFFF"), 52f)
                innerY += 20f

                if (reel.summary.isNotBlank()) {
                    drawReelSummary(canvas, 90f, innerY, width - 180, reel.summary, AndroidColor.parseColor("#B0BEC5"), 36f)
                }

                drawReelFooter(canvas, width, height, reel, primaryColor)
            }

            ReelTemplateType.BREAKING_FLASH -> {
                // Default: 🔴 BREAKING FLASH High Energy Reel
                // Top Header
                drawTopReelHeader(canvas, width, reel, primaryColor)

                // Center Highlight Photo
                val imageY = 230f
                val imageHeight = 820f
                if (reel.imageResId != 0) {
                    try {
                        val origBitmap = BitmapFactory.decodeResource(context.resources, reel.imageResId)
                        if (origBitmap != null) {
                            val destRect = RectF(50f, imageY, width - 50f, imageY + imageHeight)
                            val srcRect = Rect(0, 0, origBitmap.width, origBitmap.height)
                            val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                            canvas.drawBitmap(origBitmap, srcRect, destRect, imgPaint)

                            // Glowing Border
                            val borderPaint = Paint().apply {
                                color = primaryColor
                                style = Paint.Style.STROKE
                                strokeWidth = 8f
                                isAntiAlias = true
                            }
                            canvas.drawRoundRect(destRect, 28f, 28f, borderPaint)
                        }
                    } catch (_: Exception) {}
                }

                // Breaking Bar Overlay
                val barY = imageY + imageHeight - 90f
                val barRect = RectF(70f, barY, width - 70f, barY + 80f)
                val barPaint = Paint().apply {
                    color = AndroidColor.parseColor("#E53935")
                    isAntiAlias = true
                }
                canvas.drawRoundRect(barRect, 16f, 16f, barPaint)

                val barTextPaint = TextPaint().apply {
                    color = AndroidColor.WHITE
                    textSize = 38f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    isAntiAlias = true
                }
                canvas.drawText("🔴 BREAKING NEWS • ${reel.categoryHindi.uppercase()}", 100f, barY + 54f, barTextPaint)

                // Lower Info Card
                val cardY = imageY + imageHeight + 30f
                val cardRect = RectF(50f, cardY, width - 50f, height - 160f)
                val cardPaint = Paint().apply {
                    color = AndroidColor.parseColor("#F51E0C06")
                    isAntiAlias = true
                }
                canvas.drawRoundRect(cardRect, 30f, 30f, cardPaint)

                val cardBorder = Paint().apply {
                    color = primaryColor
                    style = Paint.Style.STROKE
                    strokeWidth = 4f
                    isAntiAlias = true
                }
                canvas.drawRoundRect(cardRect, 30f, 30f, cardBorder)

                var innerY = cardY + 60f
                drawReelBadges(canvas, 80f, innerY, reel, primaryColor)
                innerY += 70f

                innerY = drawReelHeadline(canvas, 80f, innerY, width - 160, reel.headline, AndroidColor.WHITE, 52f)
                innerY += 20f

                if (reel.summary.isNotBlank()) {
                    drawReelSummary(canvas, 80f, innerY, width - 160, reel.summary, AndroidColor.parseColor("#FFE0B2"), 36f)
                }

                drawReelFooter(canvas, width, height, reel, primaryColor)
            }
        }

        return bitmap
    }

    private fun drawTopReelHeader(canvas: Canvas, width: Int, reel: ReelCustomization, primaryColor: Int) {
        val headerHeight = 180f
        val headerPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), 0f,
                primaryColor,
                AndroidColor.parseColor("#BF360C"),
                Shader.TileMode.CLAMP
            )
            isAntiAlias = true
        }
        canvas.drawRect(0f, 0f, width.toFloat(), headerHeight, headerPaint)

        // Logo text
        val logoPaint = TextPaint().apply {
            color = AndroidColor.WHITE
            textSize = 54f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("सिटी ख़बर | CITY KHABAR", 60f, 115f, logoPaint)

        // 9:16 Reel Badge
        val reelBadgePaint = Paint().apply {
            color = AndroidColor.parseColor("#33000000")
            isAntiAlias = true
        }
        val reelBadgeRect = RectF(width - 240f, 60f, width - 60f, 130f)
        canvas.drawRoundRect(reelBadgeRect, 18f, 18f, reelBadgePaint)

        val reelTextPaint = TextPaint().apply {
            color = AndroidColor.WHITE
            textSize = 32f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("📱 9:16 रील", width - 220f, 108f, reelTextPaint)
    }

    private fun drawReelBadges(canvas: Canvas, startX: Float, startY: Float, reel: ReelCustomization, primaryColor: Int, onLightBg: Boolean = false) {
        var curX = startX

        // Category Badge
        if (reel.showCategoryBadge && reel.categoryHindi.isNotBlank()) {
            val catPaint = Paint().apply {
                color = primaryColor
                isAntiAlias = true
            }
            val textPaint = TextPaint().apply {
                color = AndroidColor.WHITE
                textSize = 30f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val catText = reel.categoryHindi
            val textWidth = textPaint.measureText(catText)
            val rect = RectF(curX, startY, curX + textWidth + 40f, startY + 52f)
            canvas.drawRoundRect(rect, 14f, 14f, catPaint)
            canvas.drawText(catText, curX + 20f, startY + 37f, textPaint)
            curX += textWidth + 60f
        }

        // City Badge
        if (reel.showCityBadge && reel.cityHindi.isNotBlank()) {
            val cityPaint = Paint().apply {
                color = if (onLightBg) AndroidColor.parseColor("#E0E0E0") else AndroidColor.parseColor("#37474F")
                isAntiAlias = true
            }
            val textPaint = TextPaint().apply {
                color = if (onLightBg) AndroidColor.parseColor("#212121") else AndroidColor.WHITE
                textSize = 30f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val cityText = "📍 ${reel.cityHindi}"
            val textWidth = textPaint.measureText(cityText)
            val rect = RectF(curX, startY, curX + textWidth + 40f, startY + 52f)
            canvas.drawRoundRect(rect, 14f, 14f, cityPaint)
            canvas.drawText(cityText, curX + 20f, startY + 37f, textPaint)
        }
    }

    private fun drawReelHeadline(canvas: Canvas, x: Float, y: Float, width: Int, text: String, color: Int, size: Float): Float {
        val paint = TextPaint().apply {
            this.color = color
            this.textSize = size
            this.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            this.isAntiAlias = true
        }

        val content = text.ifBlank { "सिटी खबर: आज की सबसे बड़ी ताज़ा रील रिपोर्ट" }
        val layout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(content, 0, content.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(12f, 1.15f)
                .setIncludePad(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(content, paint, width, Layout.Alignment.ALIGN_NORMAL, 1.15f, 12f, true)
        }

        canvas.save()
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restore()

        return y + layout.height
    }

    private fun drawReelSummary(canvas: Canvas, x: Float, y: Float, width: Int, text: String, color: Int, size: Float) {
        val paint = TextPaint().apply {
            this.color = color
            this.textSize = size
            this.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            this.isAntiAlias = true
        }

        val layout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(8f, 1.15f)
                .setIncludePad(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, paint, width, Layout.Alignment.ALIGN_NORMAL, 1.15f, 8f, true)
        }

        canvas.save()
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun drawReelFooter(canvas: Canvas, width: Int, height: Int, reel: ReelCustomization, primaryColor: Int) {
        val footerHeight = 120f
        val footerY = height - footerHeight

        val footerBg = Paint().apply {
            color = AndroidColor.parseColor("#EE0B0E14")
            isAntiAlias = true
        }
        canvas.drawRect(0f, footerY, width.toFloat(), height.toFloat(), footerBg)

        // Accent top line
        val accentLine = Paint().apply {
            color = primaryColor
            strokeWidth = 6f
            isAntiAlias = true
        }
        canvas.drawLine(0f, footerY, width.toFloat(), footerY, accentLine)

        // Reporter credit
        val repPaint = TextPaint().apply {
            color = AndroidColor.WHITE
            textSize = 32f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val repText = if (reel.showReporter && reel.reporterName.isNotBlank()) "✍️ ${reel.reporterName}" else "📰 सिटी खबर स्पेशल रील"
        canvas.drawText(repText, 60f, footerY + 70f, repPaint)

        // Official watermark
        if (reel.showWatermark) {
            val wmPaint = TextPaint().apply {
                color = primaryColor
                textSize = 32f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val wmText = "citykhabar.in"
            val wmWidth = wmPaint.measureText(wmText)
            canvas.drawText(wmText, width - wmWidth - 60f, footerY + 70f, wmPaint)
        }
    }

    /**
     * Saves 9:16 Reel Bitmap to device Gallery.
     */
    fun saveReelToGallery(context: Context, bitmap: Bitmap, title: String): Uri? {
        val fileName = "CityKhabar_Reel_${System.currentTimeMillis()}.png"
        var uri: Uri? = null

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CityKhabar_Reels")
                }
                val resolver = context.contentResolver
                uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    val out: OutputStream? = resolver.openOutputStream(uri)
                    if (out != null) {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                        out.flush()
                        out.close()
                    }
                }
            } else {
                val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + "/CityKhabar_Reels"
                val file = File(imagesDir)
                if (!file.exists()) file.mkdirs()
                val imageFile = File(imagesDir, fileName)
                val out = FileOutputStream(imageFile)
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
                out.close()
                uri = Uri.fromFile(imageFile)
            }
            Toast.makeText(context, "✅ 9:16 रील गैलरी में सफलतापूर्वक सेव हो गई!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "रील सेव करने में त्रुटि: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
        return uri
    }

    /**
     * Shares 9:16 vertical Reel with formatted Hindi caption.
     */
    fun shareReel(context: Context, reel: ReelCustomization) {
        try {
            val bitmap = renderReelBitmap(context, reel)

            val cachePath = File(context.cacheDir, "reels")
            cachePath.mkdirs()
            val tempFile = File(cachePath, "city_khabar_reel_share.png")
            val stream = FileOutputStream(tempFile)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            stream.close()

            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                tempFile
            )

            val shareCaption = buildString {
                append("🎬 *[9:16 वीडियो रील] ${reel.headline}*\n\n")
                if (reel.summary.isNotBlank()) {
                    append("${reel.summary}\n\n")
                }
                if (reel.cityHindi.isNotBlank()) {
                    append("📍 शहर: ${reel.cityHindi} | 🏷️ श्रेणी: ${reel.categoryHindi}\n")
                }
                append("✍️ रिपोर्टर: ${reel.reporterName}\n")
                append("📰 स्रोत: सिटी खबर (City Khabar Reel)\n\n")
                append("📲 ताज़ा रील व वीडियो खबरों के लिए डाउनलोड करें 'सिटी खबर' ऐप\n")
                append("#CityKhabar #CityKhabarReel #HindiNews #Reels #BreakingNews #${reel.cityHindi.replace(" ", "")}")
            }

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_TEXT, shareCaption)
                putExtra(Intent.EXTRA_SUBJECT, reel.headline)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(Intent.createChooser(intent, "9:16 रील शेयर करें (Share Reel)"))
        } catch (e: Exception) {
            val textIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "🎬 ${reel.headline}\n\n${reel.summary}\n\n- सिटी खबर 9:16 रील")
            }
            context.startActivity(Intent.createChooser(textIntent, "रील शेयर करें"))
        }
    }
}
