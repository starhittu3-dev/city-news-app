package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.PostCustomization
import com.example.ui.components.AppBottomNavigationBar
import com.example.ui.components.ArticleDetailModal
import com.example.ui.components.AuthBottomSheet
import com.example.ui.components.CitySelectorSheet
import com.example.ui.components.ReelPreviewModal
import com.example.ui.screens.CityScreen
import com.example.ui.screens.CreatePostScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NewsScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ReelsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.TrendingScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.NotificationHelper
import com.example.util.PostExportUtil
import com.example.viewmodel.AppNavTab
import com.example.viewmodel.NewsViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: NewsViewModel = viewModel()
            val themeMode by viewModel.themeMode.collectAsState()
            var showSplash by remember { mutableStateOf(true) }

            MyApplicationTheme(themeMode = themeMode) {
                Box(modifier = Modifier.fillMaxSize()) {
                    CityKhabarApp(viewModel = viewModel)

                    androidx.compose.animation.AnimatedVisibility(
                        visible = showSplash,
                        exit = androidx.compose.animation.fadeOut(
                            animationSpec = androidx.compose.animation.core.tween(300)
                        )
                    ) {
                        SplashScreen(
                            onSplashFinished = { showSplash = false }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CityKhabarApp(
    viewModel: NewsViewModel = viewModel()
) {
    val context = LocalContext.current

    val currentTab by viewModel.currentTab.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val selectedCity by viewModel.selectedCity.collectAsState()
    val favoriteCityIds by viewModel.favoriteCityIds.collectAsState()
    val followedCityIds by viewModel.followedCityIds.collectAsState()
    val primaryCityId by viewModel.primaryCityId.collectAsState()
    val followedCities by viewModel.followedCities.collectAsState()
    val recentCityIds by viewModel.recentCityIds.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isCityModalOpen by viewModel.isCityModalOpen.collectAsState()
    val detailedArticle by viewModel.detailedArticle.collectAsState()
    val audioState by viewModel.audioState.collectAsState()
    val creationStudioMode by viewModel.creationStudioMode.collectAsState()
    val reelCustomization by viewModel.reelCustomization.collectAsState()
    val isReelPreviewOpen by viewModel.isReelPreviewOpen.collectAsState()
    val postCustomization by viewModel.postCustomization.collectAsState()
    val likedArticleIds by viewModel.likedArticleIds.collectAsState()
    val savedArticles by viewModel.savedArticles.collectAsState()
    val createdPostsHistory by viewModel.createdPostsHistory.collectAsState()
    val reels by viewModel.reels.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()
    val refreshError by viewModel.refreshError.collectAsState()
    val allNewsList by viewModel.currentNewsList.collectAsState()
    val isReelGenerating by viewModel.isReelGenerating.collectAsState()
    val reelGenerationProgress by viewModel.reelGenerationProgress.collectAsState()
    val currentGeneratedVideoPath by viewModel.currentGeneratedVideoPath.collectAsState()
    val userAccount by viewModel.userAccount.collectAsState()
    val authPromptReason by viewModel.authPromptReason.collectAsState()
    val savedReels by viewModel.savedReels.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()

    // Notification StateFlows
    val notifications by viewModel.notifications.collectAsState()
    val unreadNotificationsCount by viewModel.unreadNotificationsCount.collectAsState()
    val notificationPreferences by viewModel.notificationPreferences.collectAsState()
    val isNotificationsOpen by viewModel.isNotificationsOpen.collectAsState()
    val isProfileOpen by viewModel.isProfileOpen.collectAsState()
    val searchHistory by viewModel.searchHistory.collectAsState()

    // Offline StateFlows
    val isOfflineActive by viewModel.isOfflineActive.collectAsState()
    val offlineArticleIds by viewModel.offlineArticleIds.collectAsState()
    val cachedArticles by viewModel.cachedArticles.collectAsState()
    val isManualOfflineMode by viewModel.isManualOfflineMode.collectAsState()

    // Request POST_NOTIFICATIONS permission on Android 13+ (API 33+)
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { /* Permission result handled */ }

        LaunchedEffect(Unit) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Handle Intent when app is opened from a system notification
    val activity = context as? ComponentActivity
    LaunchedEffect(Unit) {
        activity?.intent?.let { intent ->
            if (intent.getBooleanExtra(NotificationHelper.EXTRA_OPEN_NOTIFICATIONS, false)) {
                val newsId = intent.getLongExtra(NotificationHelper.EXTRA_NEWS_ID, -1L)
                if (newsId != -1L) {
                    viewModel.openArticleDetailById(newsId)
                } else {
                    viewModel.openNotifications()
                }
            }
        }
    }

    val filteredNews = remember(allNewsList, selectedCity, selectedCategory, searchQuery) {
        viewModel.getFilteredNews()
    }
    val cityNews = remember(allNewsList, selectedCity) {
        viewModel.getCityNews(selectedCity.nameHindi)
    }
    val breakingNews = remember(allNewsList) {
        viewModel.getBreakingNews()
    }
    val trendingNews = remember(allNewsList, selectedCity, selectedCategory) {
        viewModel.getTrendingNews()
    }
    val myCitiesNews = remember(allNewsList, followedCityIds) {
        viewModel.getMyCitiesNews()
    }

    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current

    // Handle Back Press gracefully and clear focus/IME to prevent ImeBackDispatcher callback warnings
    BackHandler(enabled = isProfileOpen || isNotificationsOpen || authPromptReason != null || isReelPreviewOpen || detailedArticle != null || isCityModalOpen || currentTab != AppNavTab.HOME) {
        focusManager.clearFocus(force = true)
        keyboardController?.hide()
        when {
            isProfileOpen -> viewModel.closeProfile()
            isNotificationsOpen -> viewModel.closeNotifications()
            authPromptReason != null -> viewModel.dismissAuthPrompt()
            isReelPreviewOpen -> viewModel.closeReelPreview()
            detailedArticle != null -> viewModel.closeArticleDetail()
            isCityModalOpen -> viewModel.toggleCityModal(false)
            currentTab != AppNavTab.HOME -> viewModel.setTab(AppNavTab.HOME)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Show bottom navigation on all primary tabs (unless article modal is open)
            if (detailedArticle == null && !isReelPreviewOpen) {
                AppBottomNavigationBar(
                    currentTab = currentTab,
                    onTabSelected = {
                        focusManager.clearFocus(force = true)
                        keyboardController?.hide()
                        viewModel.setTab(it)
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tab Content with Smooth Transitions
            AnimatedContent(
                targetState = currentTab,
                label = "tabTransition"
            ) { tab ->
                when (tab) {
                    AppNavTab.HOME -> {
                        HomeScreen(
                            selectedCity = selectedCity,
                            selectedCategory = selectedCategory,
                            newsList = filteredNews,
                            breakingNews = breakingNews,
                            trendingNews = trendingNews,
                            likedArticleIds = likedArticleIds,
                            followedCities = followedCities,
                            primaryCityId = primaryCityId,
                            myCitiesNews = myCitiesNews,
                            onSelectCity = { viewModel.selectCity(it) },
                            offlineArticleIds = offlineArticleIds,
                            isOfflineActive = isOfflineActive,
                            themeMode = themeMode,
                            userAccount = userAccount,
                            unreadNotificationsCount = unreadNotificationsCount,
                            onNotificationsClick = { viewModel.openNotifications() },
                            onProfileClick = { viewModel.openProfile() },
                            onToggleTheme = { viewModel.toggleQuickTheme() },
                            isRefreshing = isRefreshing,
                            refreshError = refreshError,
                            onRefresh = { viewModel.refreshNews() },
                            onDismissError = { viewModel.dismissRefreshError() },
                            isArticleBookmarked = { id -> viewModel.isArticleBookmarked(id) },
                            onCityClick = { viewModel.toggleCityModal(true) },
                            onSearchClick = { viewModel.setTab(AppNavTab.NEWS) },
                            onVoiceSearchResult = { spoken ->
                                viewModel.setTab(AppNavTab.NEWS)
                                viewModel.submitSearchQuery(spoken)
                            },
                            onCategorySelected = { viewModel.selectCategory(it) },
                            onArticleClick = { viewModel.openArticleDetail(it) },
                            onLikeClick = { viewModel.toggleLikeArticle(it) },
                            onBookmarkClick = { viewModel.toggleBookmarkWithAuthPrompt(it) },
                            onCreatePostClick = { viewModel.startCreatingReelFromArticle(it) },
                            onViewAllTrendingClick = { viewModel.setTab(AppNavTab.TRENDING) }
                        )
                    }

                    AppNavTab.CITY -> {
                        CityScreen(
                            selectedCity = selectedCity,
                            cityNewsList = cityNews,
                            likedArticleIds = likedArticleIds,
                            isArticleBookmarked = { id -> viewModel.isArticleBookmarked(id) },
                            onChangeCityClick = { viewModel.toggleCityModal(true) },
                            onArticleClick = { viewModel.openArticleDetail(it) },
                            onLikeClick = { viewModel.toggleLikeArticle(it) },
                            onBookmarkClick = { viewModel.toggleBookmarkWithAuthPrompt(it) },
                            onCreatePostClick = { viewModel.startCreatingReelFromArticle(it) }
                        )
                    }

                    AppNavTab.TRENDING -> {
                        TrendingScreen(
                            trendingNewsList = trendingNews,
                            selectedCity = selectedCity,
                            selectedCategory = selectedCategory,
                            likedArticleIds = likedArticleIds,
                            isRefreshing = isRefreshing,
                            refreshError = refreshError,
                            onRefresh = { viewModel.refreshNews() },
                            onDismissError = { viewModel.dismissRefreshError() },
                            isArticleBookmarked = { id -> viewModel.isArticleBookmarked(id) },
                            onCityPickerClick = { viewModel.toggleCityModal(true) },
                            onCategorySelected = { viewModel.selectCategory(it) },
                            onArticleClick = { viewModel.openArticleDetail(it) },
                            onLikeClick = { viewModel.toggleLikeArticle(it) },
                            onBookmarkClick = { viewModel.toggleBookmarkWithAuthPrompt(it) },
                            onCreatePostClick = { viewModel.startCreatingReelFromArticle(it) },
                            onBackClick = { viewModel.setTab(AppNavTab.HOME) }
                        )
                    }

                    AppNavTab.NEWS -> {
                        NewsScreen(
                            newsList = filteredNews,
                            savedNewsList = savedArticles,
                            cachedNewsList = cachedArticles,
                            breakingNewsList = breakingNews,
                            selectedCity = selectedCity,
                            selectedCategory = selectedCategory,
                            searchQuery = searchQuery,
                            searchHistory = searchHistory,
                            likedArticleIds = likedArticleIds,
                            offlineArticleIds = offlineArticleIds,
                            isOfflineActive = isOfflineActive,
                            isRefreshing = isRefreshing,
                            refreshError = refreshError,
                            onRefresh = { viewModel.refreshNews() },
                            onDismissError = { viewModel.dismissRefreshError() },
                            onCityPickerClick = { viewModel.toggleCityModal(true) },
                            isArticleBookmarked = { id -> viewModel.isArticleBookmarked(id) },
                            onCategorySelected = { viewModel.selectCategory(it) },
                            onSearchQueryChange = { viewModel.setSearchQuery(it) },
                            onSubmitSearch = { viewModel.submitSearchQuery(it) },
                            onDeleteHistoryItem = { viewModel.deleteSearchHistoryItem(it) },
                            onClearAllHistory = { viewModel.clearAllSearchHistory() },
                            onArticleClick = { viewModel.openArticleDetail(it) },
                            onLikeClick = { viewModel.toggleLikeArticle(it) },
                            onBookmarkClick = { viewModel.toggleBookmarkWithAuthPrompt(it) },
                            onCreatePostClick = { viewModel.startCreatingReelFromArticle(it) }
                        )
                    }

                    AppNavTab.CREATE -> {
                        CreatePostScreen(
                            creationMode = creationStudioMode,
                            onModeChange = { viewModel.setCreationStudioMode(it) },
                            liveNewsList = allNewsList,
                            onSelectLiveArticle = { viewModel.startCreatingReelFromArticle(it) },
                            // Reel Props
                            reelCustomization = reelCustomization,
                            onReelTemplateSelect = { viewModel.updateReelTemplate(it) },
                            onReelThemeSelect = { viewModel.updateReelTheme(it) },
                            onReelHeadlineChange = { viewModel.updateReelHeadline(it) },
                            onReelSummaryChange = { viewModel.updateReelSummary(it) },
                            onReelCityChange = { viewModel.updateReelCity(it) },
                            onReelCategoryChange = { viewModel.updateReelCategory(it) },
                            onReelReporterChange = { viewModel.updateReelReporter(it) },
                            onReelImageSelect = { viewModel.updateReelImage(it) },
                            onToggleReelCity = { viewModel.toggleReelCityBadge(it) },
                            onToggleReelCategory = { viewModel.toggleReelCategoryBadge(it) },
                            onToggleReelReporter = { viewModel.toggleReelReporter(it) },
                            onToggleReelWatermark = { viewModel.toggleReelWatermark(it) },
                            onOpenReelPreview = { viewModel.openReelPreview() },
                            onDownloadReelClick = { viewModel.downloadCurrentReel(context) },
                            onShareReelClick = { viewModel.shareCurrentReel(context) },
                            isReelGenerating = isReelGenerating,
                            reelGenerationProgress = reelGenerationProgress,
                            onGenerateAndPlayReelClick = { viewModel.generateAndSaveReelVideo(context, navigateToReels = true) },
                            // Post Props
                            postCustomization = postCustomization,
                            onPostCustomizationChange = { viewModel.updatePostCustomization(it) },
                            onPostTemplateSelect = { viewModel.updateTemplateType(it) },
                            onPostColorThemeSelect = { viewModel.updateColorTheme(it) },
                            onPostHeadlineChange = { viewModel.updateHeadline(it) },
                            onPostSummaryChange = { viewModel.updateSummary(it) },
                            onPostCityChange = { viewModel.updateCity(it) },
                            onPostReporterChange = { viewModel.updateReporterName(it) },
                            onPostImageSelect = { viewModel.updateImageRes(it) },
                            onTogglePostReporter = { viewModel.toggleReporterVisible(it) },
                            onTogglePostCity = { viewModel.toggleCityBadgeVisible(it) },
                            onTogglePostWatermark = { viewModel.toggleWatermarkVisible(it) },
                            onTogglePostBreaking = { viewModel.toggleBreakingTagVisible(it) },
                            onDownloadPostClick = { viewModel.downloadCurrentPost(context) },
                            onSharePostClick = { viewModel.shareCurrentPost(context) }
                        )
                    }

                    AppNavTab.REELS -> {
                        ReelsScreen(
                            reels = reels,
                            isReelSaved = { viewModel.isReelSaved(it) },
                            onSaveReelClick = { viewModel.toggleSaveReelWithAuthPrompt(it) },
                            onVideoSourceRequired = { reel -> viewModel.ensureReelVideoReady(context, reel) },
                            onCreatePostFromReel = { reel ->
                                viewModel.startCreatingReelFromArticle(
                                    com.example.model.NewsItem(
                                        id = reel.id,
                                        title = reel.title,
                                        summary = "सिटी खबर वीडियो रील - ${reel.cityHindi}",
                                        fullContent = "ताज़ा वीडियो रिपोर्ट: ${reel.title}",
                                        cityHindi = reel.cityHindi,
                                        cityEnglish = reel.cityHindi,
                                        category = com.example.model.NewsCategory.ALL,
                                        source = "सिटी खबर रील्स",
                                        timeAgo = "अभी-अभी",
                                        publishDate = "आज",
                                        imageResId = reel.thumbnailResId,
                                        reporterName = reel.reporterName
                                    )
                                )
                            }
                        )
                    }

                    AppNavTab.SETTINGS -> {
                        SettingsScreen(
                            selectedCity = selectedCity,
                            savedNewsCount = savedArticles.size,
                            createdPostsHistory = createdPostsHistory,
                            userAccount = userAccount,
                            savedArticles = savedArticles,
                            cachedArticles = cachedArticles,
                            offlineArticlesCount = offlineArticleIds.size,
                            cachedArticlesCount = cachedArticles.size,
                            isManualOfflineMode = isManualOfflineMode,
                            likedArticleIds = likedArticleIds,
                            savedReelsCount = savedReels.size,
                            favoriteCitiesCount = favoriteCityIds.size,
                            isSyncing = isSyncing,
                            themeMode = themeMode,
                            notificationPreferences = notificationPreferences,
                            unreadNotificationsCount = unreadNotificationsCount,
                            onThemeModeChange = { viewModel.setThemeMode(it) },
                            onChangeCityClick = { viewModel.toggleCityModal(true) },
                            onDeleteCreatedPost = { viewModel.deleteCreatedPost(it) },
                            onToggleNotificationsEnabled = { viewModel.toggleNotificationsEnabled(it) },
                            onToggleBreakingNews = { viewModel.toggleBreakingNewsEnabled(it) },
                            onToggleImportantNews = { viewModel.toggleImportantNewsEnabled(it) },
                            onToggleCityNews = { viewModel.toggleCityNewsEnabled(it) },
                            onToggleDailyUpdates = { viewModel.toggleDailyUpdatesEnabled(it) },
                            onOpenNotificationsPage = { viewModel.openNotifications() },
                            onSendTestNotification = { viewModel.sendTestNotification(it) },
                            onSignInClick = { viewModel.signInWithGoogle() },
                            onSignOutClick = { viewModel.signOut() },
                            onSyncClick = { viewModel.syncAllUserData() },
                            onOpenProfile = { viewModel.openProfile() },
                            onActivatePremiumClick = { viewModel.activatePremium() },
                            onArticleClick = { viewModel.openArticleDetail(it) },
                            onBookmarkClick = { viewModel.toggleBookmarkWithAuthPrompt(it) },
                            onLikeClick = { viewModel.toggleLikeArticle(it) },
                            onCreatePostClick = { viewModel.startCreatingReelFromArticle(it) },
                            onClearAllSavedNews = { viewModel.clearAllSavedNews() },
                            onClearOfflineCache = { viewModel.clearOfflineCache() },
                            onClearAllOfflineData = { viewModel.clearAllOfflineData() },
                            onToggleManualOfflineMode = { viewModel.toggleManualOfflineMode(it) },
                            onExploreNewsClick = { viewModel.setTab(AppNavTab.NEWS) }
                        )
                    }
                }
            }

            // Fullscreen Notifications Screen Modal Overlay
            if (isNotificationsOpen) {
                AnimatedVisibility(
                    visible = true,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                ) {
                    NotificationsScreen(
                        notifications = notifications,
                        unreadCount = unreadNotificationsCount,
                        notificationPreferences = notificationPreferences,
                        selectedCity = selectedCity,
                        onBackClick = { viewModel.closeNotifications() },
                        onNotificationClick = { viewModel.onNotificationClicked(it) },
                        onMarkAllAsRead = { viewModel.markAllNotificationsAsRead() },
                        onDeleteNotification = { viewModel.deleteNotification(it) },
                        onClearAllNotifications = { viewModel.clearAllNotifications() },
                        onSendTestNotification = { viewModel.sendTestNotification(it) },
                        onOpenSettings = {
                            viewModel.closeNotifications()
                            viewModel.setTab(AppNavTab.SETTINGS)
                        }
                    )
                }
            }

            // Fullscreen Profile Screen Modal Overlay
            if (isProfileOpen) {
                AnimatedVisibility(
                    visible = true,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                ) {
                    ProfileScreen(
                        userAccount = userAccount,
                        savedNewsCount = savedArticles.size,
                        favoriteCitiesCount = favoriteCityIds.size,
                        createdPostsCount = createdPostsHistory.size,
                        savedReelsCount = savedReels.size,
                        isSyncing = isSyncing,
                        selectedCity = selectedCity,
                        themeMode = themeMode,
                        onBackClick = { viewModel.closeProfile() },
                        onSignInWithGoogle = { viewModel.signInWithGoogle() },
                        onSignInCustom = { name, email, phone, city, bio, avatarId ->
                            viewModel.signInWithCustomAccount(name, email, phone, city, bio, avatarId)
                        },
                        onUpdateProfile = { name, email, phone, bio, city, avatarId, photoUrl ->
                            viewModel.updateUserProfile(name, email, phone, bio, city, avatarId, photoUrl)
                        },
                        onSignOut = { viewModel.signOut() },
                        onSyncClick = { viewModel.syncAllUserData() },
                        onOpenBookmarks = {
                            viewModel.closeProfile()
                            viewModel.setTab(AppNavTab.SETTINGS)
                        },
                        onOpenNotifications = {
                            viewModel.closeProfile()
                            viewModel.openNotifications()
                        },
                        onOpenSettings = {
                            viewModel.closeProfile()
                            viewModel.setTab(AppNavTab.SETTINGS)
                        }
                    )
                }
            }

            // City Selector Modal BottomSheet
            if (isCityModalOpen) {
                CitySelectorSheet(
                    cities = viewModel.allCities,
                    selectedCity = selectedCity,
                    favoriteCityIds = favoriteCityIds,
                    followedCityIds = followedCityIds,
                    primaryCityId = primaryCityId,
                    recentCityIds = recentCityIds,
                    onCitySelected = { viewModel.selectCity(it) },
                    onToggleFavorite = { viewModel.toggleFavoriteCity(it) },
                    onToggleFollow = { viewModel.toggleFollowCity(it) },
                    onSetPrimaryCity = { viewModel.setPrimaryCity(it) },
                    onClearRecent = { viewModel.clearRecentCities() },
                    onDismiss = { viewModel.toggleCityModal(false) }
                )
            }

            // Fullscreen 9:16 Reel Preview Modal
            if (isReelPreviewOpen) {
                ReelPreviewModal(
                    reel = reelCustomization,
                    videoPath = currentGeneratedVideoPath,
                    onDismiss = { viewModel.closeReelPreview() },
                    onDownload = { viewModel.downloadCurrentReel(context) },
                    onShare = { viewModel.shareCurrentReel(context) },
                    onEdit = { viewModel.closeReelPreview() }
                )
            }

            // Full Article Reader Modal
            detailedArticle?.let { article ->
                AnimatedVisibility(
                    visible = true,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                ) {
                    ArticleDetailModal(
                        article = article,
                        isLiked = likedArticleIds.contains(article.id),
                        isBookmarked = viewModel.isArticleBookmarked(article.id),
                        isOfflineAvailable = offlineArticleIds.contains(article.id) || viewModel.isArticleBookmarked(article.id),
                        audioState = audioState,
                        onClose = { viewModel.closeArticleDetail() },
                        onLikeClick = { viewModel.toggleLikeArticle(article.id) },
                        onBookmarkClick = { viewModel.toggleBookmarkWithAuthPrompt(article) },
                        onShareClick = {
                            PostExportUtil.sharePost(
                                context,
                                PostCustomization(
                                    headline = article.title,
                                    summary = article.summary,
                                    cityHindi = article.cityHindi,
                                    reporterName = article.reporterName,
                                    imageResId = article.imageResId
                                )
                            )
                        },
                        onToggleAudio = { viewModel.toggleAudioReadout(article) },
                        onCycleAudioSpeed = { viewModel.cycleAudioSpeed() },
                        onCreatePost = { viewModel.startCreatingPostFromArticle(article) },
                        onCreateReel = { viewModel.startCreatingReelFromArticle(article) }
                    )
                }
            }

            // Optional User Authentication Bottom Sheet Prompt
            authPromptReason?.let { reason ->
                AuthBottomSheet(
                    reason = reason,
                    onSignInWithGoogle = { viewModel.signInWithGoogle() },
                    onContinueAsGuest = { viewModel.continueAsGuest() },
                    onDismiss = { viewModel.dismissAuthPrompt() }
                )
            }
        }
    }
}
