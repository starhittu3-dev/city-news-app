package com.example.model

data class CityInfo(
    val id: String,
    val nameHindi: String,
    val nameEnglish: String,
    val stateHindi: String,
    val tempCelsius: String,
    val weatherCondition: String,
    val aqi: Int,
    val aqiStatus: String,
    val isPopular: Boolean = false,
    val imageResId: Int,
    val newsCount: Int = 24
)
