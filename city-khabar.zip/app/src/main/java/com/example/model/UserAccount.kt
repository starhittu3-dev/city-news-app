package com.example.model

/**
 * Represents the current user account state in City Khabar.
 * Supports guest mode without forcing authentication, and Google Sign-In for cloud sync.
 */
data class UserAccount(
    val id: String = "guest_user",
    val displayName: String = "अतिथि पाठक (Guest)",
    val email: String = "",
    val photoUrl: String? = null,
    val phone: String? = null,
    val bio: String? = null,
    val city: String? = null,
    val avatarId: String = "avatar_1",
    val isGuest: Boolean = true,
    val isPremium: Boolean = false,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val lastSyncTimestamp: Long = 0L,
    val syncEnabled: Boolean = true
) {
    companion object {
        val GUEST_DEFAULT = UserAccount(
            id = "guest_user",
            displayName = "अतिथि पाठक (Guest)",
            email = "",
            photoUrl = null,
            phone = null,
            bio = null,
            city = null,
            avatarId = "avatar_guest",
            isGuest = true,
            isPremium = false,
            createdAtTimestamp = System.currentTimeMillis(),
            lastSyncTimestamp = 0L,
            syncEnabled = false
        )
    }
}

/**
 * Reasons for prompting the user to sign in, explaining the specific benefit.
 */
enum class AuthPromptReason(
    val titleHindi: String,
    val subtitleHindi: String,
    val actionLabelHindi: String
) {
    SAVE_FAVORITE(
        titleHindi = "पसंदीदा खबर सेव करें",
        subtitleHindi = "अपनी पसंदीदा खबरों को सुरक्षित रखें और सभी डिवाइस पर कभी भी पढ़ें।",
        actionLabelHindi = "सेव करने हेतु साइन इन करें"
    ),
    SAVE_REEL(
        titleHindi = "वीडियो रील सेव करें",
        subtitleHindi = "शानदार वीडियो रील्स को अपनी लाइब्रेरी में सेव और डाउनलोड करें।",
        actionLabelHindi = "रील सेव करने हेतु साइन इन करें"
    ),
    SAVE_POST(
        titleHindi = "पोस्टर व प्रोजेक्ट सेव करें",
        subtitleHindi = "अपने बनाए गए कस्टम न्यूज़ पोस्टर्स और रील्स का हमेशा के लिए बैकअप रखें।",
        actionLabelHindi = "प्रोजेक्ट सुरक्षित करें"
    ),
    PREMIUM_FEATURES(
        titleHindi = "सिटी खबर प्रीमियम सुविधाएं",
        subtitleHindi = "विज्ञापन-मुक्त समाचार, एक्सक्लूसिव एचडी टेम्पलेट्स और अनलिमिटेड क्लाउड सिंक का लाभ उठाएं।",
        actionLabelHindi = "प्रीमियम अनलॉक करें"
    ),
    ACCOUNT_SYNC(
        titleHindi = "क्लाउड बैकअप एवं सिंक",
        subtitleHindi = "अपनी सेटिंग्स, पसंदीदा शहरों और सेव की गई खबरों को गूगल अकाउंट से सिंक करें।",
        actionLabelHindi = "सिंक सक्रिय करें"
    ),
    GENERAL(
        titleHindi = "सिटी खबर अकाउंट",
        subtitleHindi = "साइन इन करें और व्यक्तिगत अनुभव, समाचार अलर्ट व बैकअप का आनंद लें।",
        actionLabelHindi = "साइन इन करें"
    )
}

/**
 * Summary of synced user items for display in the profile & sync dashboard.
 */
data class UserSyncSummary(
    val savedNewsCount: Int = 0,
    val favoriteCitiesCount: Int = 0,
    val savedPostsCount: Int = 0,
    val savedReelsCount: Int = 0,
    val isPremium: Boolean = false,
    val lastSyncFormatted: String = "सिंक नहीं हुआ",
    val isSyncing: Boolean = false
)
