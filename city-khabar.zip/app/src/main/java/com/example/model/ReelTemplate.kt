package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.BreakingNewsRed
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DarkBg
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.SaffronGold

/**
 * 9:16 Vertical Reel Templates for City Khabar news stories.
 */
enum class ReelTemplateType(
    val id: String,
    val nameHindi: String,
    val subtitleHindi: String,
    val iconName: String
) {
    BREAKING_FLASH(
        id = "breaking_flash",
        nameHindi = "🔴 ब्रेकिंग न्यूज़ रील",
        subtitleHindi = "हाई-इम्पैक्ट रेड व ऑरेंज टीवी ब्रॉडकास्ट स्टाइल",
        iconName = "campaign"
    ),
    CINEMATIC_OVERLAY(
        id = "cinematic_overlay",
        nameHindi = "🎬 सिनेमैटिक डार्क रील",
        subtitleHindi = "फुल-स्क्रीन 9:16 बैकड्रॉप व फ्रॉस्टेड ग्लास कार्ड",
        iconName = "movie"
    ),
    STUDIO_BULLETIN(
        id = "studio_bulletin",
        nameHindi = "📺 न्यूज़रूम बुलेटिन",
        subtitleHindi = "लोअर-थर्ड यलो हेडलाइन व लाइव एंकर स्टाइल",
        iconName = "tv"
    ),
    MAGAZINE_HIGHLIGHT(
        id = "magazine_highlight",
        nameHindi = "📖 मैगज़ीन हाइलाइट",
        subtitleHindi = "रॉयल केसरिया और व्हाइट क्लीन विजुअल कार्ड",
        iconName = "article"
    ),
    MIDNIGHT_NEON(
        id = "midnight_neon",
        nameHindi = "⚡ मिडनाइट नियॉन",
        subtitleHindi = "डार्क साइबर थीम विथ हाई-कंट्रास्ट नियॉन एक्सेंट",
        iconName = "bolt"
    )
}

/**
 * Color themes specifically tuned for 9:16 vertical video reels.
 */
enum class ReelColorTheme(
    val id: String,
    val nameHindi: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val backgroundColor: Color,
    val cardBackground: Color,
    val textColor: Color,
    val accentColor: Color
) {
    ORANGE_FIRE(
        id = "orange_fire",
        nameHindi = "ज्वलनशील नारंगी",
        primaryColor = OrangePrimary,
        secondaryColor = CrimsonRed,
        backgroundColor = Color(0xFF140702),
        cardBackground = Color(0xDD2A1208),
        textColor = Color(0xFFFFFFFF),
        accentColor = Color(0xFFFFAB91)
    ),
    CRIMSON_DARK(
        id = "crimson_dark",
        nameHindi = "क्रिमसन डार्क",
        primaryColor = CrimsonRed,
        secondaryColor = Color(0xFFB71C1C),
        backgroundColor = DarkBg,
        cardBackground = Color(0xDD1F0505),
        textColor = Color(0xFFFFFFFF),
        accentColor = Color(0xFFFF8A80)
    ),
    SAFFRON_ROYAL(
        id = "saffron_royal",
        nameHindi = "रॉयल केसरिया",
        primaryColor = SaffronGold,
        secondaryColor = OrangePrimary,
        backgroundColor = Color(0xFF1C1304),
        cardBackground = Color(0xDD31220A),
        textColor = Color(0xFFFFFFFF),
        accentColor = Color(0xFFFFD54F)
    ),
    MIDNIGHT_CYBER(
        id = "midnight_cyber",
        nameHindi = "मिडनाइट साइबर",
        primaryColor = Color(0xFFFF5722),
        secondaryColor = Color(0xFF00E5FF),
        backgroundColor = Color(0xFF0A0E17),
        cardBackground = Color(0xDD131B2A),
        textColor = Color(0xFFF0F4F8),
        accentColor = Color(0xFF00E5FF)
    ),
    EMERALD_GREEN(
        id = "emerald_green",
        nameHindi = "प्रीमियम एमराल्ड",
        primaryColor = Color(0xFF2E7D32),
        secondaryColor = Color(0xFF00C853),
        backgroundColor = Color(0xFF051408),
        cardBackground = Color(0xDD0C2410),
        textColor = Color(0xFFFFFFFF),
        accentColor = Color(0xFF69F0AE)
    )
}

/**
 * Full state customization data class for creating a 9:16 vertical Reel.
 */
data class ReelCustomization(
    val selectedArticleId: String = "",
    val headline: String = "",
    val summary: String = "",
    val cityHindi: String = "नई दिल्ली",
    val categoryHindi: String = "राजनीति",
    val reporterName: String = "सिटी खबर विशेष संवाददाता",
    val source: String = "सिटी खबर डिजिटल",
    val dateText: String = "आज की ताज़ा रिपोर्ट",
    val imageResId: Int = 0,
    val templateType: ReelTemplateType = ReelTemplateType.BREAKING_FLASH,
    val colorTheme: ReelColorTheme = ReelColorTheme.ORANGE_FIRE,
    val showBranding: Boolean = true,
    val showCityBadge: Boolean = true,
    val showCategoryBadge: Boolean = true,
    val showReporter: Boolean = true,
    val showWatermark: Boolean = true,
    val showLivePulse: Boolean = true,
    val headlineFontSize: Float = 22f
)
