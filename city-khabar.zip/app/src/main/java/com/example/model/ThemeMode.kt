package com.example.model

enum class ThemeMode(
    val id: String,
    val titleHindi: String,
    val titleEnglish: String,
    val descriptionHindi: String,
    val iconEmoji: String
) {
    SYSTEM(
        id = "system",
        titleHindi = "सिस्टम डिफ़ॉल्ट",
        titleEnglish = "System Default",
        descriptionHindi = "डिवाइस की डिफ़ॉल्ट सेटिंग अनुसार स्वतः सेट होगा",
        iconEmoji = "📱"
    ),
    LIGHT(
        id = "light",
        titleHindi = "लाइट मोड",
        titleEnglish = "Light Mode",
        descriptionHindi = "उज्ज्वल व स्पष्ट दिन का पढ़ने का अनुभव",
        iconEmoji = "☀️"
    ),
    DARK(
        id = "dark",
        titleHindi = "डार्क मोड",
        titleEnglish = "Dark Mode",
        descriptionHindi = "कम रोशनी में आँखों के लिए आरामदायक व बैटरी बचत",
        iconEmoji = "🌙"
    );

    companion object {
        fun fromId(id: String?): ThemeMode {
            return entries.find { it.id.equals(id, ignoreCase = true) } ?: SYSTEM
        }
    }
}
