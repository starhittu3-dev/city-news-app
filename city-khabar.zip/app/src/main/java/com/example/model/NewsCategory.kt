package com.example.model

enum class NewsCategory(
    val id: String,
    val titleHindi: String,
    val titleEnglish: String,
    val iconName: String
) {
    ALL("all", "सभी", "All", "explore"),
    POLITICS("politics", "राजनीति", "Politics", "policy"),
    SPORTS("sports", "खेल", "Sports", "sports"),
    BUSINESS("business", "व्यापार", "Business", "trending_up"),
    WEATHER("weather", "मौसम", "Weather", "wb_sunny"),
    ENTERTAINMENT("entertainment", "मनोरंजन", "Entertainment", "movie"),
    LOCAL("local", "स्थानीय", "Local", "location_city"),
    CRIME("crime", "अपराध", "Crime", "gavel"),
    TECH("tech", "टेक्नोलॉजी", "Tech", "devices")
}
