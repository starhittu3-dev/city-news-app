package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DarkBg
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.SaffronGold

enum class PostTemplateType(
    val id: String,
    val nameHindi: String,
    val descriptionHindi: String,
    val previewIcon: String
) {
    BREAKING_NEWS(
        id = "breaking",
        nameHindi = "🔴 ब्रेकिंग न्यूज़ पोस्टर",
        descriptionHindi = "उच्च प्रभाव वाला लाल-नारंगी बोल्ड न्यूज़ बैनर",
        previewIcon = "campaign"
    ),
    EDITORIAL_MINIMAL(
        id = "editorial",
        nameHindi = "📰 संपादकीय कार्ड",
        descriptionHindi = "साफ-सुथरा प्रीमियम मैग्जीन लेआउट",
        previewIcon = "article"
    ),
    STORY_9_16(
        id = "story",
        nameHindi = "📱 इंस्टाग्राम रील/स्टोरी (9:16)",
        descriptionHindi = "फुल स्क्रीन वर्टिकल विजुअल स्टोरी",
        previewIcon = "smartphone"
    ),
    NEWSPAPER_FRONT(
        id = "newspaper",
        nameHindi = "🗞️ दैनिक समाचार पत्र",
        descriptionHindi = "क्लासिक अख़बार फ्रंट-पेज स्टाइल",
        previewIcon = "newspaper"
    ),
    SQUARE_SOCIAL(
        id = "square",
        nameHindi = "⏹️ सोशल मीडिया स्क्वायर (1:1)",
        descriptionHindi = "फेसबुक व व्हाट्सएप स्टेटस के लिए परफेक्ट",
        previewIcon = "grid_view"
    )
}

enum class PostColorTheme(
    val id: String,
    val nameHindi: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val backgroundColor: Color,
    val textColor: Color
) {
    ORANGE_FIRE(
        id = "orange_fire",
        nameHindi = "ज्वलनशील नारंगी",
        primaryColor = OrangePrimary,
        secondaryColor = CrimsonRed,
        backgroundColor = Color(0xFFFFF5F2),
        textColor = Color(0xFF212121)
    ),
    CRIMSON_DARK(
        id = "crimson_dark",
        nameHindi = "क्रिमसन डार्क",
        primaryColor = CrimsonRed,
        secondaryColor = Color(0xFFB71C1C),
        backgroundColor = DarkBg,
        textColor = Color(0xFFFFFFFF)
    ),
    SAFFRON_GOLD(
        id = "saffron_gold",
        nameHindi = "शाही केसरिया",
        primaryColor = SaffronGold,
        secondaryColor = OrangePrimary,
        backgroundColor = Color(0xFFFFF8E1),
        textColor = Color(0xFF2E1C0C)
    ),
    MIDNIGHT_BLACK(
        id = "midnight_black",
        nameHindi = "मिडनाइट ब्लैक",
        primaryColor = Color(0xFFFF5722),
        secondaryColor = Color(0xFF37474F),
        backgroundColor = Color(0xFF101418),
        textColor = Color(0xFFF0F4F8)
    ),
    CLEAN_WHITE(
        id = "clean_white",
        nameHindi = "स्वच्छ श्वेत",
        primaryColor = OrangePrimary,
        secondaryColor = Color(0xFF757575),
        backgroundColor = Color(0xFFFFFFFF),
        textColor = Color(0xFF1A1A1A)
    )
}

data class PostCustomization(
    val templateType: PostTemplateType = PostTemplateType.BREAKING_NEWS,
    val colorTheme: PostColorTheme = PostColorTheme.ORANGE_FIRE,
    val headline: String = "",
    val summary: String = "",
    val cityHindi: String = "",
    val reporterName: String = "सिटी खबर विशेष रिपोर्ट",
    val dateText: String = "",
    val sourceText: String = "सिटी खबर डिजिटल",
    val imageResId: Int = 0,
    val showReporter: Boolean = true,
    val showCityBadge: Boolean = true,
    val showWatermark: Boolean = true,
    val showDate: Boolean = true,
    val showBreakingTag: Boolean = true,
    val headlineFontSize: Float = 20f
)
