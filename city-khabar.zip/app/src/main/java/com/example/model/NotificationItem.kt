package com.example.model

enum class NotificationType(
    val id: String,
    val titleHindi: String,
    val titleEnglish: String,
    val iconEmoji: String
) {
    BREAKING_NEWS(
        id = "breaking",
        titleHindi = "🚨 ब्रेकिंग न्यूज़",
        titleEnglish = "Breaking News",
        iconEmoji = "🚨"
    ),
    IMPORTANT_NEWS(
        id = "important",
        titleHindi = "⭐ महत्वपूर्ण समाचार",
        titleEnglish = "Important News",
        iconEmoji = "⭐"
    ),
    CITY_IMPORTANT(
        id = "city_important",
        titleHindi = "🏙️ चयनित शहर समाचार",
        titleEnglish = "Selected City News",
        iconEmoji = "🏙️"
    ),
    DAILY_UPDATE(
        id = "daily_update",
        titleHindi = "📰 दैनिक समाचार अपडेट्स",
        titleEnglish = "Daily News Updates",
        iconEmoji = "📰"
    ),
    SYSTEM(
        id = "system",
        titleHindi = "🔔 सिस्टम अलर्ट",
        titleEnglish = "System Alert",
        iconEmoji = "🔔"
    );

    companion object {
        fun fromId(id: String): NotificationType {
            return entries.find { it.id.equals(id, ignoreCase = true) } ?: SYSTEM
        }
    }
}

data class NotificationItem(
    val id: String,
    val newsId: String? = null,
    val title: String,
    val message: String,
    val type: NotificationType = NotificationType.BREAKING_NEWS,
    val cityNameHindi: String = "राष्ट्रीय",
    val timestamp: Long = System.currentTimeMillis(),
    val timeAgo: String = "अभी-अभी",
    val isRead: Boolean = false,
    val imageResId: Int = 0
)

data class NotificationPreferences(
    val notificationsEnabled: Boolean = true,
    val breakingNewsEnabled: Boolean = true,
    val importantNewsEnabled: Boolean = true,
    val cityNewsEnabled: Boolean = true,
    val dailyUpdatesEnabled: Boolean = true
)
