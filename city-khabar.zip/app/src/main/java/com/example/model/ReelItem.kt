package com.example.model

data class ReelItem(
    val id: String,
    val title: String,
    val description: String,
    val cityHindi: String,
    val category: String,
    val reporter: String,
    val imageResId: Int,
    val likesCount: Int,
    val commentsCount: Int,
    val sharesCount: Int,
    val timeAgo: String,
    val isLiked: Boolean = false,
    val videoPath: String? = null,
    val videoUri: String? = null,
    val durationSeconds: Int = 5
) {
    val reporterName: String get() = reporter
    val thumbnailResId: Int get() = imageResId
}

