package com.example.model

data class NewsItem(
    val id: String,
    val title: String,
    val summary: String,
    val fullContent: String,
    val cityHindi: String,
    val cityEnglish: String,
    val category: NewsCategory,
    val source: String,
    val timeAgo: String,
    val publishDate: String,
    val imageResId: Int,
    val isBreaking: Boolean = false,
    val isTrending: Boolean = false,
    val reporterName: String = "सिटी खबर ब्यूरो",
    val likesCount: Int = 142,
    val sharesCount: Int = 38,
    val viewsCount: String = "12.4K",
    val isBookmarked: Boolean = false,
    val isLiked: Boolean = false
)
