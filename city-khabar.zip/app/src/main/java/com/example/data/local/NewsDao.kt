package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NewsDao {
    @Query("SELECT * FROM saved_news ORDER BY savedAtTimestamp DESC")
    fun getAllSavedNews(): Flow<List<SavedNewsEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM saved_news WHERE id = :newsId)")
    fun isNewsSaved(newsId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedNews(news: SavedNewsEntity)

    @Query("DELETE FROM saved_news WHERE id = :newsId")
    suspend fun deleteSavedNewsById(newsId: String)

    @Query("DELETE FROM saved_news")
    suspend fun clearAllSavedNews()

    @Query("SELECT * FROM created_posts ORDER BY createdAtTimestamp DESC")
    fun getAllCreatedPosts(): Flow<List<CreatedPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCreatedPost(post: CreatedPostEntity): Long

    @Query("DELETE FROM created_posts WHERE id = :postId")
    suspend fun deleteCreatedPostById(postId: Long)

    // Favorite & Followed Cities
    @Query("SELECT * FROM favorite_cities ORDER BY addedAtTimestamp DESC")
    fun getAllFavoriteCities(): Flow<List<FavoriteCityEntity>>

    @Query("SELECT cityId FROM favorite_cities WHERE isPrimary = 1 LIMIT 1")
    fun getPrimaryCityId(): Flow<String?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavoriteCity(city: FavoriteCityEntity)

    @Query("UPDATE favorite_cities SET isPrimary = 0")
    suspend fun clearPrimaryCityFlags()

    @Query("UPDATE favorite_cities SET isPrimary = 1 WHERE cityId = :cityId")
    suspend fun markCityAsPrimary(cityId: String)

    @Query("DELETE FROM favorite_cities WHERE cityId = :cityId")
    suspend fun deleteFavoriteCity(cityId: String)

    // Recent Cities
    @Query("SELECT * FROM recent_cities ORDER BY selectedAtTimestamp DESC LIMIT 10")
    fun getRecentCities(): Flow<List<RecentCityEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentCity(city: RecentCityEntity)

    @Query("DELETE FROM recent_cities WHERE cityId = :cityId")
    suspend fun deleteRecentCity(cityId: String)

    @Query("DELETE FROM recent_cities")
    suspend fun clearRecentCities()

    // Saved Reels
    @Query("SELECT * FROM saved_reels ORDER BY savedAtTimestamp DESC")
    fun getAllSavedReels(): Flow<List<SavedReelEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM saved_reels WHERE id = :reelId)")
    fun isReelSaved(reelId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedReel(reel: SavedReelEntity)

    @Query("DELETE FROM saved_reels WHERE id = :reelId")
    suspend fun deleteSavedReelById(reelId: String)

    // User Account
    @Query("SELECT * FROM user_account WHERE id = 'primary_account' LIMIT 1")
    fun getUserAccount(): Flow<UserAccountEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateUserAccount(account: UserAccountEntity)

    @Query("DELETE FROM user_account WHERE id = 'primary_account'")
    suspend fun clearUserAccount()

    // In-App Notifications
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<AppNotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE isRead = 0")
    fun getUnreadNotificationsCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotificationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<AppNotificationEntity>)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :notificationId")
    suspend fun markNotificationAsRead(notificationId: String)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllNotificationsAsRead()

    @Query("DELETE FROM notifications WHERE id = :notificationId")
    suspend fun deleteNotificationById(notificationId: String)

    @Query("DELETE FROM notifications")
    suspend fun clearAllNotifications()

    // Notification Preferences
    @Query("SELECT * FROM notification_preferences WHERE id = 'default_preferences' LIMIT 1")
    fun getNotificationPreferences(): Flow<NotificationPreferencesEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveNotificationPreferences(preferences: NotificationPreferencesEntity)

    // Search History
    @Query("SELECT * FROM search_history ORDER BY searchedAtTimestamp DESC LIMIT 20")
    fun getAllSearchHistory(): Flow<List<SearchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSearchHistory(entry: SearchHistoryEntity)

    @Query("DELETE FROM search_history WHERE `query` = :query")
    suspend fun deleteSearchHistoryItem(query: String)

    @Query("DELETE FROM search_history")
    suspend fun clearAllSearchHistory()

    // Offline Cached Articles
    @Query("SELECT * FROM cached_articles ORDER BY cachedAtTimestamp DESC")
    fun getAllCachedArticles(): Flow<List<CachedArticleEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM cached_articles WHERE id = :articleId) OR EXISTS(SELECT 1 FROM saved_news WHERE id = :articleId)")
    fun isArticleOfflineAvailable(articleId: String): Flow<Boolean>

    @Query("SELECT id FROM cached_articles UNION SELECT id FROM saved_news")
    fun getAllOfflineArticleIds(): Flow<List<String>>

    @Query("SELECT COUNT(DISTINCT id) FROM (SELECT id FROM cached_articles UNION SELECT id FROM saved_news)")
    fun getOfflineArticlesCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCachedArticle(article: CachedArticleEntity)

    @Query("DELETE FROM cached_articles WHERE id = :articleId")
    suspend fun deleteCachedArticleById(articleId: String)

    @Query("DELETE FROM cached_articles WHERE isSavedBookmark = 0")
    suspend fun clearAutoCachedArticles()

    @Query("DELETE FROM cached_articles")
    suspend fun clearAllCachedArticles()

    @Query("DELETE FROM cached_articles WHERE id NOT IN (SELECT id FROM cached_articles ORDER BY cachedAtTimestamp DESC LIMIT :limit)")
    suspend fun trimCachedArticles(limit: Int)
}
