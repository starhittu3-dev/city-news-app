package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SavedNewsEntity::class,
        CreatedPostEntity::class,
        FavoriteCityEntity::class,
        RecentCityEntity::class,
        SavedReelEntity::class,
        UserAccountEntity::class,
        AppNotificationEntity::class,
        NotificationPreferencesEntity::class,
        SearchHistoryEntity::class,
        CachedArticleEntity::class
    ],
    version = 9,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun newsDao(): NewsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "city_khabar_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
