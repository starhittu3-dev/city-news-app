package com.example.data

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.CreatedPostEntity
import com.example.data.local.FavoriteCityEntity
import com.example.data.local.RecentCityEntity
import com.example.data.local.SavedNewsEntity
import com.example.data.network.LiveNewsService
import com.example.model.CityInfo
import com.example.model.NewsCategory
import com.example.model.NewsItem
import com.example.model.ReelItem
import com.example.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

import com.example.model.NotificationItem
import com.example.model.NotificationPreferences
import com.example.model.NotificationType
import com.example.data.local.AppNotificationEntity
import com.example.data.local.CachedArticleEntity
import com.example.data.local.NotificationPreferencesEntity
import kotlinx.coroutines.flow.combine

/**
 * Repository coordinating news data between live external news services (Google News RSS / REST),
 * Room database offline caches, and dynamic real-time generators.
 *
 * NOTE ON API CONNECTIVITY & DELAYED FEEDS:
 * -----------------------------------------
 * When connecting to public news feeds or free API plans (which often bundle 15m - 24h delayed feeds),
 * this repository ensures that the UI ALWAYS receives current, fresh publication timestamps
 * matching the user's real time. Whenever the user taps "ताज़ा करें" (Refresh), old cache is bypassed
 * and the freshest live items are immediately placed at the top of the feed.
 */
class NewsRepository(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val dao = db.newsDao()
    private val liveNewsService = LiveNewsService()
    private val prefs = context.getSharedPreferences("city_khabar_prefs", Context.MODE_PRIVATE)

    // Initialize with dynamic real-time timestamps calculated from current system time
    private val _currentNewsList = MutableStateFlow<List<NewsItem>>(NewsDataSeed.getDynamicInitialNews())
    val currentNewsList: StateFlow<List<NewsItem>> = _currentNewsList.asStateFlow()

    private var refreshCount = 0

    fun getCities(): List<CityInfo> = NewsDataSeed.CITIES

    fun getCityById(cityId: String): CityInfo? {
        return NewsDataSeed.CITIES.find { it.id.equals(cityId, ignoreCase = true) }
    }

    fun getAllNews(): List<NewsItem> = _currentNewsList.value

    fun getBreakingNews(): List<NewsItem> {
        return _currentNewsList.value.filter { it.isBreaking }
    }

    fun getTrendingNews(
        selectedCity: String? = null,
        selectedCategory: NewsCategory = NewsCategory.ALL
    ): List<NewsItem> {
        val current = _currentNewsList.value
        if (current.isEmpty()) return emptyList()

        // 1. Filter by city if specified and valid
        var pool = current
        if (!selectedCity.isNullOrBlank() && selectedCity != "सभी शहर") {
            val cityFiltered = pool.filter { it.cityHindi.equals(selectedCity, ignoreCase = true) }
            if (cityFiltered.isNotEmpty()) {
                pool = cityFiltered
            }
        }

        // 2. Filter by category if specified
        if (selectedCategory != NewsCategory.ALL) {
            val categoryFiltered = pool.filter { it.category == selectedCategory }
            if (categoryFiltered.isNotEmpty()) {
                pool = categoryFiltered
            }
        }

        // 3. Dynamic Trending Score Calculator:
        // Combines isTrending flag, isBreaking importance, likes, shares, views count, and recency
        fun calculateScore(item: NewsItem): Double {
            var score = 0.0
            if (item.isTrending) score += 1000.0
            if (item.isBreaking) score += 450.0
            score += item.likesCount * 3.5
            score += item.sharesCount * 8.0

            // Parse views (e.g. "15.4K" -> 15400)
            val viewsNumber = try {
                val clean = item.viewsCount.replace("K", "", ignoreCase = true).trim()
                clean.toDouble() * 1000
            } catch (e: Exception) {
                5000.0
            }
            score += (viewsNumber / 100.0)

            return score
        }

        // 4. Sort strictly by trending popularity score
        val ranked = pool.sortedByDescending { calculateScore(it) }

        // 5. Fallback: If no explicit trending data exists, return the top important/breaking items
        return if (ranked.isNotEmpty()) ranked else current.sortedByDescending { if (it.isBreaking) 1 else 0 }.take(10)
    }

    fun getNewsByCity(cityNameHindi: String): List<NewsItem> {
        val current = _currentNewsList.value
        if (cityNameHindi.isEmpty() || cityNameHindi == "सभी शहर") {
            return current
        }
        val list = current.filter { it.cityHindi.equals(cityNameHindi, ignoreCase = true) }
        return if (list.isNotEmpty()) list else current
    }

    fun getNewsFiltered(
        selectedCity: String?,
        selectedCategory: NewsCategory,
        searchQuery: String = ""
    ): List<NewsItem> {
        var list = _currentNewsList.value

        if (!selectedCity.isNullOrBlank() && selectedCity != "सभी शहर") {
            list = list.filter { it.cityHindi.equals(selectedCity, ignoreCase = true) }
        }

        if (selectedCategory != NewsCategory.ALL) {
            list = list.filter { it.category == selectedCategory }
        }

        if (searchQuery.isNotBlank()) {
            val query = searchQuery.trim().lowercase()
            list = list.filter { item ->
                item.title.lowercase().contains(query) ||
                item.summary.lowercase().contains(query) ||
                item.fullContent.lowercase().contains(query) ||
                item.cityHindi.lowercase().contains(query) ||
                item.cityEnglish.lowercase().contains(query) ||
                item.category.titleHindi.lowercase().contains(query) ||
                item.category.titleEnglish.lowercase().contains(query) ||
                item.reporterName.lowercase().contains(query) ||
                item.source.lowercase().contains(query)
            }
        }

        return list
    }

    /**
     * Fetches fresh news directly from live network feed / real-time generator.
     * Bypasses stale cached dates and injects current live publication timestamps.
     */
    suspend fun refreshLatestNews(selectedCityName: String? = null, forceError: Boolean = false): Result<List<NewsItem>> {
        return try {
            if (forceError) {
                return Result.failure(Exception("Network connection failed"))
            }

            refreshCount++
            // Query live network news feed
            val freshLiveItems = liveNewsService.fetchLatestLiveNews(selectedCityName, refreshCount)

            val baseList = _currentNewsList.value
            // Put fresh items at the top and deduplicate by title
            val updatedList = (freshLiveItems + baseList).distinctBy { it.title }
            _currentNewsList.value = updatedList

            Result.success(updatedList)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Reels list with dynamic video caching
    private val _reelsList = MutableStateFlow<List<ReelItem>>(NewsDataSeed.REELS_DATA)
    val reelsList: StateFlow<List<ReelItem>> = _reelsList.asStateFlow()

    fun getReels(): List<ReelItem> = _reelsList.value

    fun addNewReel(reel: ReelItem) {
        _reelsList.value = listOf(reel) + _reelsList.value.filter { it.id != reel.id }
    }

    fun updateReelVideoPath(reelId: String, videoPath: String) {
        _reelsList.value = _reelsList.value.map { item ->
            if (item.id == reelId) item.copy(videoPath = videoPath) else item
        }
    }

    // Room Database Operations for Saved News
    fun getAllSavedNews(): Flow<List<NewsItem>> {
        return dao.getAllSavedNews().map { entities ->
            entities.map { entity ->
                NewsItem(
                    id = entity.id,
                    title = entity.title,
                    summary = entity.summary,
                    fullContent = entity.fullContent,
                    cityHindi = entity.cityHindi,
                    cityEnglish = entity.cityEnglish,
                    category = NewsCategory.entries.find { it.id == entity.categoryId } ?: NewsCategory.LOCAL,
                    source = entity.source,
                    timeAgo = entity.timeAgo,
                    publishDate = entity.publishDate,
                    imageResId = entity.imageResId,
                    reporterName = entity.reporterName,
                    isBookmarked = true
                )
            }
        }
    }

    fun isNewsSaved(newsId: String): Flow<Boolean> = dao.isNewsSaved(newsId)

    suspend fun toggleBookmark(news: NewsItem, isCurrentlySaved: Boolean) {
        if (isCurrentlySaved) {
            dao.deleteSavedNewsById(news.id)
        } else {
            dao.insertSavedNews(
                SavedNewsEntity(
                    id = news.id,
                    title = news.title,
                    summary = news.summary,
                    fullContent = news.fullContent,
                    cityHindi = news.cityHindi,
                    cityEnglish = news.cityEnglish,
                    categoryId = news.category.id,
                    source = news.source,
                    timeAgo = news.timeAgo,
                    publishDate = news.publishDate,
                    imageResId = news.imageResId,
                    reporterName = news.reporterName
                )
            )
        }
    }

    suspend fun clearAllSavedNews() {
        dao.clearAllSavedNews()
    }

    // =========================================================
    // ROOM DATABASE OPERATIONS FOR OFFLINE CACHED ARTICLES
    // =========================================================

    /**
     * Automatically caches an article into Room DB when opened by the user.
     * Manages storage footprint by trimming auto-cached articles beyond the 50 most recent.
     */
    suspend fun cacheArticle(news: NewsItem) {
        val entity = CachedArticleEntity(
            id = news.id,
            title = news.title,
            summary = news.summary,
            fullContent = news.fullContent,
            cityHindi = news.cityHindi,
            cityEnglish = news.cityEnglish,
            categoryId = news.category.id,
            source = news.source,
            timeAgo = news.timeAgo,
            publishDate = news.publishDate,
            imageResId = news.imageResId,
            reporterName = news.reporterName,
            isBreaking = news.isBreaking,
            isTrending = news.isTrending,
            likesCount = news.likesCount,
            sharesCount = news.sharesCount,
            viewsCount = news.viewsCount,
            isSavedBookmark = news.isBookmarked,
            isAutoCached = true,
            cachedAtTimestamp = System.currentTimeMillis()
        )
        dao.insertCachedArticle(entity)
        // Storage management: keep max 50 auto-cached articles in local database
        dao.trimCachedArticles(limit = 50)
    }

    fun getAllCachedArticles(): Flow<List<NewsItem>> {
        return dao.getAllCachedArticles().map { entities ->
            entities.map { entity ->
                NewsItem(
                    id = entity.id,
                    title = entity.title,
                    summary = entity.summary,
                    fullContent = entity.fullContent,
                    cityHindi = entity.cityHindi,
                    cityEnglish = entity.cityEnglish,
                    category = NewsCategory.entries.find { it.id == entity.categoryId } ?: NewsCategory.LOCAL,
                    source = entity.source,
                    timeAgo = entity.timeAgo,
                    publishDate = entity.publishDate,
                    imageResId = entity.imageResId,
                    reporterName = entity.reporterName,
                    isBreaking = entity.isBreaking,
                    isTrending = entity.isTrending,
                    likesCount = entity.likesCount,
                    sharesCount = entity.sharesCount,
                    viewsCount = entity.viewsCount,
                    isBookmarked = entity.isSavedBookmark
                )
            }
        }
    }

    /**
     * Returns all offline-accessible articles by combining both user bookmarks (Saved)
     * and auto-cached recently read articles, eliminating duplicates and sorted by recency.
     */
    fun getAllOfflineArticles(): Flow<List<NewsItem>> {
        return combine(
            getAllSavedNews(),
            getAllCachedArticles()
        ) { savedList, cachedList ->
            val savedMap = savedList.associateBy { it.id }
            val combined = mutableListOf<NewsItem>()

            // Add saved items first
            combined.addAll(savedList)

            // Add cached items that aren't already in saved list (or mark them as bookmarked if they are)
            cachedList.forEach { cached ->
                if (!savedMap.containsKey(cached.id)) {
                    combined.add(cached.copy(isBookmarked = false))
                }
            }
            combined
        }
    }

    fun isArticleOfflineAvailable(articleId: String): Flow<Boolean> =
        dao.isArticleOfflineAvailable(articleId)

    fun getOfflineArticleIds(): Flow<Set<String>> =
        dao.getAllOfflineArticleIds().map { it.toSet() }

    fun getOfflineArticlesCount(): Flow<Int> =
        dao.getOfflineArticlesCount()

    suspend fun clearAutoCachedArticles() {
        dao.clearAutoCachedArticles()
    }

    suspend fun clearAllOfflineData() {
        dao.clearAllCachedArticles()
        dao.clearAllSavedNews()
    }

    // Room Database Operations for Created Posts
    fun getAllCreatedPosts(): Flow<List<CreatedPostEntity>> = dao.getAllCreatedPosts()

    suspend fun saveCreatedPost(post: CreatedPostEntity): Long {
        return dao.insertCreatedPost(post)
    }

    suspend fun deleteCreatedPost(postId: Long) {
        dao.deleteCreatedPostById(postId)
    }

    // Favorite & Followed Cities Room Operations
    fun getFavoriteCityIds(): Flow<Set<String>> {
        return dao.getAllFavoriteCities().map { list -> list.map { it.cityId }.toSet() }
    }

    fun getFollowedCityIds(): Flow<Set<String>> = getFavoriteCityIds()

    fun getPrimaryCityId(): Flow<String?> {
        return dao.getPrimaryCityId().map { id ->
            id ?: prefs.getString("primary_city_id", "bhopal")
        }
    }

    fun getSavedPrimaryCityId(): String {
        return prefs.getString("primary_city_id", "bhopal") ?: "bhopal"
    }

    suspend fun setPrimaryCity(cityId: String) {
        prefs.edit().putString("primary_city_id", cityId).apply()
        dao.clearPrimaryCityFlags()
        // Ensure the primary city is also in the followed list
        dao.insertFavoriteCity(FavoriteCityEntity(cityId = cityId, isPrimary = true))
    }

    suspend fun toggleFavoriteCity(cityId: String, isCurrentlyFavorite: Boolean) {
        if (isCurrentlyFavorite) {
            dao.deleteFavoriteCity(cityId)
            val currentPrimary = prefs.getString("primary_city_id", null)
            if (currentPrimary == cityId) {
                prefs.edit().remove("primary_city_id").apply()
            }
        } else {
            dao.insertFavoriteCity(FavoriteCityEntity(cityId = cityId, isPrimary = false))
        }
    }

    suspend fun followCity(cityId: String, setAsPrimary: Boolean = false) {
        if (setAsPrimary) {
            setPrimaryCity(cityId)
        } else {
            dao.insertFavoriteCity(FavoriteCityEntity(cityId = cityId, isPrimary = false))
        }
    }

    suspend fun unfollowCity(cityId: String) {
        dao.deleteFavoriteCity(cityId)
        val currentPrimary = prefs.getString("primary_city_id", null)
        if (currentPrimary == cityId) {
            prefs.edit().remove("primary_city_id").apply()
        }
    }

    /**
     * Retrieves combined news feed from all followed cities.
     */
    fun getNewsForFollowedCities(followedCityIds: Set<String>): List<NewsItem> {
        if (followedCityIds.isEmpty()) return emptyList()
        val followedCityNames = NewsDataSeed.CITIES
            .filter { followedCityIds.contains(it.id) }
            .map { it.nameHindi }
            .toSet()

        return _currentNewsList.value.filter { item ->
            followedCityNames.any { it.equals(item.cityHindi, ignoreCase = true) }
        }
    }

    /**
     * Checks if notification should be dispatched for a specific city based on user's followed cities.
     */
    fun shouldSendCityNotification(cityNameHindi: String, followedCityIds: Set<String>): Boolean {
        if (cityNameHindi.isBlank() || cityNameHindi == "राष्ट्रीय" || cityNameHindi == "राज्य") {
            return true
        }
        val followedCityNames = NewsDataSeed.CITIES
            .filter { followedCityIds.contains(it.id) }
            .map { it.nameHindi }
            .toSet()

        return followedCityNames.any { it.equals(cityNameHindi, ignoreCase = true) }
    }

    // Recent Cities Room Operations
    fun getRecentCityIds(): Flow<List<String>> {
        return dao.getRecentCities().map { list -> list.map { it.cityId } }
    }

    suspend fun recordRecentCity(cityId: String) {
        dao.insertRecentCity(RecentCityEntity(cityId = cityId))
    }

    suspend fun clearRecentCities() {
        dao.clearRecentCities()
    }

    // Search History Room Operations
    fun getAllSearchHistory(): Flow<List<String>> {
        return dao.getAllSearchHistory().map { list -> list.map { it.query } }
    }

    suspend fun recordSearchQuery(query: String) {
        val trimmed = query.trim()
        if (trimmed.isNotBlank()) {
            dao.insertSearchHistory(
                com.example.data.local.SearchHistoryEntity(
                    query = trimmed,
                    searchedAtTimestamp = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun deleteSearchHistoryItem(query: String) {
        dao.deleteSearchHistoryItem(query.trim())
    }

    suspend fun clearAllSearchHistory() {
        dao.clearAllSearchHistory()
    }

    // App Theme Preference
    fun getSavedThemeMode(): ThemeMode {
        val savedId = prefs.getString("app_theme_mode", ThemeMode.SYSTEM.id)
        return ThemeMode.fromId(savedId)
    }

    fun saveThemeMode(mode: ThemeMode) {
        prefs.edit().putString("app_theme_mode", mode.id).apply()
    }

    // Saved Reels Room Operations
    fun getAllSavedReels(): Flow<List<com.example.data.local.SavedReelEntity>> = dao.getAllSavedReels()

    fun isReelSaved(reelId: String): Flow<Boolean> = dao.isReelSaved(reelId)

    suspend fun saveReel(reel: ReelItem) {
        dao.insertSavedReel(
            com.example.data.local.SavedReelEntity(
                id = reel.id,
                title = reel.title,
                description = reel.description,
                cityHindi = reel.cityHindi,
                category = reel.category,
                reporterName = reel.reporterName,
                thumbnailResId = reel.thumbnailResId,
                videoPath = reel.videoPath,
                likesCount = reel.likesCount,
                commentsCount = reel.commentsCount,
                sharesCount = reel.sharesCount,
                durationSeconds = reel.durationSeconds
            )
        )
    }

    suspend fun deleteSavedReel(reelId: String) {
        dao.deleteSavedReelById(reelId)
    }

    // User Account & Cloud Sync Operations
    fun getUserAccount(): Flow<com.example.model.UserAccount> {
        return dao.getUserAccount().map { entity ->
            if (entity == null || entity.isGuest) {
                com.example.model.UserAccount.GUEST_DEFAULT
            } else {
                com.example.model.UserAccount(
                    id = entity.userId,
                    displayName = entity.displayName,
                    email = entity.email,
                    photoUrl = entity.photoUrl,
                    phone = entity.phone,
                    bio = entity.bio,
                    city = entity.city,
                    avatarId = entity.avatarId,
                    isGuest = entity.isGuest,
                    isPremium = entity.isPremium,
                    createdAtTimestamp = entity.createdAtTimestamp,
                    lastSyncTimestamp = entity.lastSyncTimestamp,
                    syncEnabled = entity.syncEnabled
                )
            }
        }
    }

    suspend fun signInWithGoogle(
        displayName: String = "रोहित शर्मा (Rohit Sharma)",
        email: String = "rohit.sharma@gmail.com",
        photoUrl: String? = null
    ): com.example.model.UserAccount {
        val now = System.currentTimeMillis()
        val entity = com.example.data.local.UserAccountEntity(
            id = "primary_account",
            userId = "google_user_${email.hashCode()}",
            displayName = displayName,
            email = email,
            photoUrl = photoUrl,
            phone = "+91 98765 43210",
            bio = "दैनिक ताज़ा खबरों और स्थानीय रिपोर्टिंग का पाठक 📰",
            city = "भोपाल",
            avatarId = "avatar_1",
            isGuest = false,
            isPremium = prefs.getBoolean("user_is_premium", false),
            createdAtTimestamp = now,
            lastSyncTimestamp = now,
            syncEnabled = true
        )
        dao.insertOrUpdateUserAccount(entity)
        return com.example.model.UserAccount(
            id = entity.userId,
            displayName = entity.displayName,
            email = entity.email,
            photoUrl = entity.photoUrl,
            phone = entity.phone,
            bio = entity.bio,
            city = entity.city,
            avatarId = entity.avatarId,
            isGuest = false,
            isPremium = entity.isPremium,
            createdAtTimestamp = entity.createdAtTimestamp,
            lastSyncTimestamp = entity.lastSyncTimestamp,
            syncEnabled = true
        )
    }

    suspend fun signInWithCustomAccount(
        displayName: String,
        email: String,
        phone: String? = null,
        city: String? = null,
        bio: String? = null,
        avatarId: String = "avatar_1"
    ): com.example.model.UserAccount {
        val now = System.currentTimeMillis()
        val entity = com.example.data.local.UserAccountEntity(
            id = "primary_account",
            userId = "user_${email.hashCode()}",
            displayName = displayName.ifBlank { "सिटी खबर पाठक" },
            email = email,
            photoUrl = null,
            phone = phone ?: "+91 98765 00000",
            bio = bio ?: "सिटी खबर का सक्रिय पाठक व क्रिएटर 📰",
            city = city ?: "इंदौर",
            avatarId = avatarId,
            isGuest = false,
            isPremium = prefs.getBoolean("user_is_premium", false),
            createdAtTimestamp = now,
            lastSyncTimestamp = now,
            syncEnabled = true
        )
        dao.insertOrUpdateUserAccount(entity)
        return com.example.model.UserAccount(
            id = entity.userId,
            displayName = entity.displayName,
            email = entity.email,
            photoUrl = entity.photoUrl,
            phone = entity.phone,
            bio = entity.bio,
            city = entity.city,
            avatarId = entity.avatarId,
            isGuest = false,
            isPremium = entity.isPremium,
            createdAtTimestamp = entity.createdAtTimestamp,
            lastSyncTimestamp = entity.lastSyncTimestamp,
            syncEnabled = true
        )
    }

    suspend fun updateUserProfile(
        displayName: String,
        email: String,
        phone: String?,
        bio: String?,
        city: String?,
        avatarId: String,
        photoUrl: String? = null
    ) {
        val now = System.currentTimeMillis()
        val entity = com.example.data.local.UserAccountEntity(
            id = "primary_account",
            userId = "user_${email.hashCode()}",
            displayName = displayName.ifBlank { "सिटी खबर पाठक" },
            email = email,
            photoUrl = photoUrl,
            phone = phone,
            bio = bio,
            city = city,
            avatarId = avatarId,
            isGuest = false,
            isPremium = prefs.getBoolean("user_is_premium", false),
            createdAtTimestamp = now,
            lastSyncTimestamp = now,
            syncEnabled = true
        )
        dao.insertOrUpdateUserAccount(entity)
    }

    suspend fun signOut() {
        dao.clearUserAccount()
    }

    suspend fun syncUserData(): Long {
        val now = System.currentTimeMillis()
        val account = dao.getUserAccount()
        // Update sync timestamp in database
        dao.insertOrUpdateUserAccount(
            com.example.data.local.UserAccountEntity(
                id = "primary_account",
                userId = "current_user",
                displayName = "सिटी खबर पाठक",
                email = prefs.getString("user_email", "user@citykhabar.in") ?: "user@citykhabar.in",
                isGuest = false,
                isPremium = prefs.getBoolean("user_is_premium", false),
                lastSyncTimestamp = now,
                syncEnabled = true
            )
        )
        return now
    }

    suspend fun setPremiumStatus(isPremium: Boolean) {
        prefs.edit().putBoolean("user_is_premium", isPremium).apply()
        dao.insertOrUpdateUserAccount(
            com.example.data.local.UserAccountEntity(
                id = "primary_account",
                userId = "premium_user",
                displayName = "सिटी खबर VIP पाठक",
                email = prefs.getString("user_email", "vip.reader@citykhabar.in") ?: "vip.reader@citykhabar.in",
                isGuest = false,
                isPremium = isPremium,
                lastSyncTimestamp = System.currentTimeMillis(),
                syncEnabled = true
            )
        )
    }

    // ==========================================
    // NOTIFICATION OPERATIONS (Room Database)
    // ==========================================

    fun getAllNotifications(): Flow<List<NotificationItem>> {
        return dao.getAllNotifications().map { entities ->
            entities.map { entity ->
                NotificationItem(
                    id = entity.id,
                    newsId = entity.newsId,
                    title = entity.title,
                    message = entity.message,
                    type = NotificationType.fromId(entity.typeId),
                    cityNameHindi = entity.cityNameHindi,
                    timestamp = entity.timestamp,
                    timeAgo = entity.timeAgo,
                    isRead = entity.isRead,
                    imageResId = entity.imageResId
                )
            }
        }
    }

    fun getUnreadNotificationsCount(): Flow<Int> {
        return dao.getUnreadNotificationsCount()
    }

    suspend fun insertNotification(item: NotificationItem) {
        dao.insertNotification(
            AppNotificationEntity(
                id = item.id,
                newsId = item.newsId,
                title = item.title,
                message = item.message,
                typeId = item.type.id,
                cityNameHindi = item.cityNameHindi,
                timestamp = item.timestamp,
                timeAgo = item.timeAgo,
                isRead = item.isRead,
                imageResId = item.imageResId
            )
        )
    }

    suspend fun markNotificationAsRead(id: String) {
        dao.markNotificationAsRead(id)
    }

    suspend fun markAllNotificationsAsRead() {
        dao.markAllNotificationsAsRead()
    }

    suspend fun deleteNotification(id: String) {
        dao.deleteNotificationById(id)
    }

    suspend fun clearAllNotifications() {
        dao.clearAllNotifications()
    }

    fun getNotificationPreferences(): Flow<NotificationPreferences> {
        return dao.getNotificationPreferences().map { entity ->
            if (entity == null) {
                NotificationPreferences()
            } else {
                NotificationPreferences(
                    notificationsEnabled = entity.notificationsEnabled,
                    breakingNewsEnabled = entity.breakingNewsEnabled,
                    importantNewsEnabled = entity.importantNewsEnabled,
                    cityNewsEnabled = entity.cityNewsEnabled,
                    dailyUpdatesEnabled = entity.dailyUpdatesEnabled
                )
            }
        }
    }

    suspend fun saveNotificationPreferences(preferences: NotificationPreferences) {
        dao.saveNotificationPreferences(
            NotificationPreferencesEntity(
                id = "default_preferences",
                notificationsEnabled = preferences.notificationsEnabled,
                breakingNewsEnabled = preferences.breakingNewsEnabled,
                importantNewsEnabled = preferences.importantNewsEnabled,
                cityNewsEnabled = preferences.cityNewsEnabled,
                dailyUpdatesEnabled = preferences.dailyUpdatesEnabled,
                updatedAtTimestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun createLiveNotificationFromArticle(
        newsItem: com.example.model.NewsItem,
        type: NotificationType = NotificationType.BREAKING_NEWS,
        customMessage: String? = null
    ): NotificationItem {
        val notif = NotificationItem(
            id = "live_notif_${newsItem.id}_${System.currentTimeMillis()}",
            newsId = newsItem.id,
            title = when (type) {
                NotificationType.BREAKING_NEWS -> "🚨 ब्रेकिंग: ${newsItem.title}"
                NotificationType.IMPORTANT_NEWS -> "⭐ मुख्य खबर: ${newsItem.title}"
                NotificationType.CITY_IMPORTANT -> "🏙️ ${newsItem.cityHindi}: ${newsItem.title}"
                NotificationType.DAILY_UPDATE -> "📰 दैनिक बुलेटिन: ${newsItem.title}"
                NotificationType.SYSTEM -> "🔔 ${newsItem.title}"
            },
            message = customMessage ?: newsItem.summary.take(120),
            type = type,
            cityNameHindi = newsItem.cityHindi,
            timestamp = System.currentTimeMillis(),
            timeAgo = "अभी-अभी",
            isRead = false,
            imageResId = newsItem.imageResId
        )
        insertNotification(notif)
        return notif
    }

    suspend fun seedInitialNotificationsIfEmpty() {
        val initialList = listOf(
            NotificationItem(
                id = "notif_1",
                newsId = "news_1",
                title = "🚨 इंदौर: 50 नई इलेक्ट्रिक बसों को सीएम ने दिखाई हरी झंडी",
                message = "बीआरटीएस कॉरिडोर पर प्रदूषण मुक्त स्मार्ट यात्रा शुरू, आज से हर 5 मिनट में उपलब्ध।",
                type = NotificationType.BREAKING_NEWS,
                cityNameHindi = "इंदौर",
                timestamp = System.currentTimeMillis() - (8 * 60 * 1000L),
                timeAgo = "8 मिनट पहले",
                isRead = false,
                imageResId = 0
            ),
            NotificationItem(
                id = "notif_2",
                newsId = "news_3",
                title = "⭐ महत्वपूर्ण: राज्य लोक सेवा आयोग परीक्षा की नई तिथि घोषित",
                message = "प्रवेश पत्र डाउनलोड लिंक आधिकारिक पोर्टल पर सक्रिय, सभी केंद्रों पर कड़ी सुरक्षा व्यवस्था।",
                type = NotificationType.IMPORTANT_NEWS,
                cityNameHindi = "राज्य",
                timestamp = System.currentTimeMillis() - (20 * 60 * 1000L),
                timeAgo = "20 मिनट पहले",
                isRead = false,
                imageResId = 0
            ),
            NotificationItem(
                id = "notif_3",
                newsId = "news_2",
                title = "🏙️ भोपाल: स्मार्ट सिटी पार्क में नया साइंस म्यूजियम उद्घाटित",
                message = "विद्यार्थियों व पर्यटकों के लिए खगोल विज्ञान एवं 3D स्पेस शो की विशेष व्यवस्था।",
                type = NotificationType.CITY_IMPORTANT,
                cityNameHindi = "भोपाल",
                timestamp = System.currentTimeMillis() - (35 * 60 * 1000L),
                timeAgo = "35 मिनट पहले",
                isRead = false,
                imageResId = 0
            ),
            NotificationItem(
                id = "notif_4",
                newsId = "news_4",
                title = "📰 दैनिक बुलेटिन: आज की 10 बड़ी खबरें व सुर्खियां",
                message = "मेट्रो का ट्रायल रन सफल, नई सौर ऊर्जा नीति और खेल जगत के ताज़ा परिणाम।",
                type = NotificationType.DAILY_UPDATE,
                cityNameHindi = "राष्ट्रीय",
                timestamp = System.currentTimeMillis() - (2 * 3600 * 1000L),
                timeAgo = "2 घंटे पहले",
                isRead = true,
                imageResId = 0
            ),
            NotificationItem(
                id = "notif_5",
                newsId = "news_5",
                title = "🚨 दिल्ली-एनसीआर: प्रदूषण नियंत्रण हेतु नया ग्रेडेड एक्शन प्लान लागू",
                message = "पर्यावरण मंत्रालय ने जारी किए दिशा-निर्देश, निर्माण कार्यों पर सख्त निगरानी।",
                type = NotificationType.BREAKING_NEWS,
                cityNameHindi = "दिल्ली",
                timestamp = System.currentTimeMillis() - (4 * 3600 * 1000L),
                timeAgo = "4 घंटे पहले",
                isRead = true,
                imageResId = 0
            ),
            NotificationItem(
                id = "notif_6",
                newsId = "news_6",
                title = "🏙️ जयपुर: परकोटे में हेरिटेज वॉक का दूसरा चरण शुरू",
                message = "पर्यटकों को आकर्षित करने के लिए हवा महल से अल्बर्ट हॉल तक नई इलेक्ट्रिक बग्गी सेवा।",
                type = NotificationType.CITY_IMPORTANT,
                cityNameHindi = "जयपुर",
                timestamp = System.currentTimeMillis() - (6 * 3600 * 1000L),
                timeAgo = "6 घंटे पहले",
                isRead = true,
                imageResId = 0
            )
        )

        initialList.forEach { notif ->
            dao.insertNotification(
                AppNotificationEntity(
                    id = notif.id,
                    newsId = notif.newsId,
                    title = notif.title,
                    message = notif.message,
                    typeId = notif.type.id,
                    cityNameHindi = notif.cityNameHindi,
                    timestamp = notif.timestamp,
                    timeAgo = notif.timeAgo,
                    isRead = notif.isRead,
                    imageResId = notif.imageResId
                )
            )
        }
    }
}
