package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_news")
data class SavedNewsEntity(
    @PrimaryKey val id: String,
    val title: String,
    val summary: String,
    val fullContent: String,
    val cityHindi: String,
    val cityEnglish: String,
    val categoryId: String,
    val source: String,
    val timeAgo: String,
    val publishDate: String,
    val imageResId: Int,
    val reporterName: String,
    val savedAtTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "created_posts")
data class CreatedPostEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val templateId: String,
    val colorThemeId: String,
    val headline: String,
    val summary: String,
    val cityHindi: String,
    val reporterName: String,
    val imageResId: Int,
    val createdAtTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorite_cities")
data class FavoriteCityEntity(
    @PrimaryKey val cityId: String,
    val isPrimary: Boolean = false,
    val addedAtTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "recent_cities")
data class RecentCityEntity(
    @PrimaryKey val cityId: String,
    val selectedAtTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_reels")
data class SavedReelEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val cityHindi: String,
    val category: String,
    val reporterName: String,
    val thumbnailResId: Int,
    val videoPath: String? = null,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val durationSeconds: Int = 15,
    val savedAtTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_account")
data class UserAccountEntity(
    @PrimaryKey val id: String = "primary_account",
    val userId: String,
    val displayName: String,
    val email: String,
    val photoUrl: String? = null,
    val phone: String? = null,
    val bio: String? = null,
    val city: String? = null,
    val avatarId: String = "avatar_1",
    val isGuest: Boolean = true,
    val isPremium: Boolean = false,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val lastSyncTimestamp: Long = 0L,
    val syncEnabled: Boolean = true
)

@Entity(tableName = "notifications")
data class AppNotificationEntity(
    @PrimaryKey val id: String,
    val newsId: String? = null,
    val title: String,
    val message: String,
    val typeId: String = "breaking",
    val cityNameHindi: String = "राष्ट्रीय",
    val timestamp: Long = System.currentTimeMillis(),
    val timeAgo: String = "अभी-अभी",
    val isRead: Boolean = false,
    val imageResId: Int = 0
)

@Entity(tableName = "notification_preferences")
data class NotificationPreferencesEntity(
    @PrimaryKey val id: String = "default_preferences",
    val notificationsEnabled: Boolean = true,
    val breakingNewsEnabled: Boolean = true,
    val importantNewsEnabled: Boolean = true,
    val cityNewsEnabled: Boolean = true,
    val dailyUpdatesEnabled: Boolean = true,
    val updatedAtTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(
    @PrimaryKey val query: String,
    val searchedAtTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_articles")
data class CachedArticleEntity(
    @PrimaryKey val id: String,
    val title: String,
    val summary: String,
    val fullContent: String,
    val cityHindi: String,
    val cityEnglish: String,
    val categoryId: String,
    val source: String,
    val timeAgo: String,
    val publishDate: String,
    val imageResId: Int,
    val reporterName: String,
    val isBreaking: Boolean = false,
    val isTrending: Boolean = false,
    val likesCount: Int = 120,
    val sharesCount: Int = 45,
    val viewsCount: String = "12.5K",
    val isSavedBookmark: Boolean = false,
    val isAutoCached: Boolean = true,
    val cachedAtTimestamp: Long = System.currentTimeMillis()
)



