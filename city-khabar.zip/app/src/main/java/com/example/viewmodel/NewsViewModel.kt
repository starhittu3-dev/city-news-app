package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.NewsDataSeed
import com.example.data.NewsRepository
import com.example.data.local.CreatedPostEntity
import com.example.model.CityInfo
import com.example.model.NewsCategory
import com.example.model.NewsItem
import com.example.model.PostColorTheme
import com.example.model.PostCustomization
import com.example.model.PostTemplateType
import com.example.model.ReelColorTheme
import com.example.model.ReelCustomization
import com.example.model.ReelItem
import com.example.model.ReelTemplateType
import com.example.model.ThemeMode
import com.example.model.NotificationItem
import com.example.model.NotificationPreferences
import com.example.model.NotificationType
import com.example.util.NetworkConnectivityHelper
import com.example.util.NotificationHelper
import com.example.util.PostExportUtil
import com.example.util.ReelVideoGenerator
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppNavTab(
    val id: String,
    val titleHindi: String,
    val titleEnglish: String,
    val iconName: String
) {
    HOME("home", "होम", "Home", "home"),
    CITY("city", "शहर", "City", "location_city"),
    TRENDING("trending", "ट्रेंडिंग", "Trending", "trending_up"),
    NEWS("news", "खबरें", "News", "newspaper"),
    CREATE("create", "रील / पोस्ट", "Create", "add_photo_alternate"),
    REELS("reels", "रील्स", "Reels", "video_library"),
    SETTINGS("settings", "सेटिंग्स", "Settings", "settings")
}

enum class CreationStudioMode(
    val id: String,
    val titleHindi: String,
    val subtitleHindi: String,
    val ratioLabel: String
) {
    REEL_9_16(
        id = "reel_9_16",
        titleHindi = "🎬 9:16 वर्टिकल रील",
        subtitleHindi = "इंस्टाग्राम रील्स, यूट्यूब शॉर्ट्स व व्हाट्सएप स्टेटस",
        ratioLabel = "9:16"
    ),
    POST_4_5(
        id = "post_4_5",
        titleHindi = "🎨 सोशल मीडिया पोस्टर",
        subtitleHindi = "फेसबुक, व्हाट्सएप व इंस्टाग्राम फीड कार्ड",
        ratioLabel = "4:5 / 1:1"
    )
}

data class AudioReadoutState(
    val isPlaying: Boolean = false,
    val currentArticleId: String? = null,
    val progress: Float = 0f,
    val playbackSpeed: Float = 1.0f,
    val durationSeconds: Int = 45,
    val elapsedSeconds: Int = 0
)

class NewsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = NewsRepository(application.applicationContext)
    private val networkHelper = NetworkConnectivityHelper(application.applicationContext)

    // Real-Time Network Connectivity Observation
    val isOnline: StateFlow<Boolean> = networkHelper.isOnlineFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = networkHelper.isNetworkAvailable()
        )

    // Manual Offline Simulation Mode (can be toggled in Settings or testing)
    private val _isManualOfflineMode = MutableStateFlow(false)
    val isManualOfflineMode: StateFlow<Boolean> = _isManualOfflineMode.asStateFlow()

    // Combined active offline status (true if no network OR user enabled offline mode)
    val isOfflineActive: StateFlow<Boolean> = combine(
        isOnline,
        _isManualOfflineMode
    ) { online, manualOffline ->
        !online || manualOffline
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = !networkHelper.isNetworkAvailable()
    )

    fun toggleManualOfflineMode(enabled: Boolean) {
        _isManualOfflineMode.value = enabled
        if (enabled) {
            Toast.makeText(getApplication(), "ऑफलाइन मोड सक्रिय (Offline Mode Active)", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(getApplication(), "लाइव मोड सक्रिय (Live Online Mode)", Toast.LENGTH_SHORT).show()
        }
    }

    // Navigation Tab
    private val _currentTab = MutableStateFlow(AppNavTab.HOME)
    val currentTab: StateFlow<AppNavTab> = _currentTab.asStateFlow()

    // City Selection
    private val _selectedCity = MutableStateFlow<CityInfo>(
        repository.getCityById(repository.getSavedPrimaryCityId()) ?: NewsDataSeed.CITIES[0]
    )
    val selectedCity: StateFlow<CityInfo> = _selectedCity.asStateFlow()

    val allCities: List<CityInfo> = repository.getCities()

    // Followed / Favorite City IDs from Room Database
    val followedCityIds: StateFlow<Set<String>> = repository.getFollowedCityIds()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = setOf("bhopal", "delhi", "jaipur")
        )
    val favoriteCityIds: StateFlow<Set<String>> = followedCityIds

    val primaryCityId: StateFlow<String?> = repository.getPrimaryCityId()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = repository.getSavedPrimaryCityId()
        )

    val primaryCity: StateFlow<CityInfo?> = combine(primaryCityId, _selectedCity) { pId, currentSelected ->
        if (pId != null) repository.getCityById(pId) else currentSelected
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = repository.getCityById(repository.getSavedPrimaryCityId())
    )

    val followedCities: StateFlow<List<CityInfo>> = followedCityIds.map { ids ->
        allCities.filter { ids.contains(it.id) }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = allCities.filter { it.id in setOf("bhopal", "delhi", "jaipur") }
    )

    // Recently Selected City IDs from Room Database
    val recentCityIds: StateFlow<List<String>> = repository.getRecentCityIds()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = listOf("delhi", "mumbai", "jaipur", "bhopal")
        )

    init {
        // Initialize default recent and favorite seed if empty
        viewModelScope.launch {
            repository.recordRecentCity(NewsDataSeed.CITIES[0].id)
            NotificationHelper.createNotificationChannels(application.applicationContext)
            repository.seedInitialNotificationsIfEmpty()
            // Pre-cache initial articles so offline mode is instantly populated
            NewsDataSeed.INITIAL_NEWS.take(5).forEach { seedItem ->
                repository.cacheArticle(seedItem)
            }
        }
    }

    // Theme Mode Preference
    private val _themeMode = MutableStateFlow<ThemeMode>(repository.getSavedThemeMode())
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        repository.saveThemeMode(mode)
    }

    fun toggleQuickTheme() {
        val nextMode = when (_themeMode.value) {
            ThemeMode.DARK -> ThemeMode.LIGHT
            ThemeMode.LIGHT -> ThemeMode.DARK
            ThemeMode.SYSTEM -> ThemeMode.DARK
        }
        setThemeMode(nextMode)
    }

    // Category Filter
    private val _selectedCategory = MutableStateFlow(NewsCategory.ALL)
    val selectedCategory: StateFlow<NewsCategory> = _selectedCategory.asStateFlow()

    // Search Query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // City Selector Modal
    private val _isCityModalOpen = MutableStateFlow(false)
    val isCityModalOpen: StateFlow<Boolean> = _isCityModalOpen.asStateFlow()

    // Article Detail Modal/View
    private val _detailedArticle = MutableStateFlow<NewsItem?>(null)
    val detailedArticle: StateFlow<NewsItem?> = _detailedArticle.asStateFlow()

    // Audio Readout State (Hindi Text-to-Speech simulation)
    private val _audioState = MutableStateFlow(AudioReadoutState())
    val audioState: StateFlow<AudioReadoutState> = _audioState.asStateFlow()
    private var audioJob: Job? = null

    // Creation Studio Mode (Reel 9:16 vs Post 4:5)
    private val _creationStudioMode = MutableStateFlow(CreationStudioMode.REEL_9_16)
    val creationStudioMode: StateFlow<CreationStudioMode> = _creationStudioMode.asStateFlow()

    // 9:16 Reel Creator State
    private val _reelCustomization = MutableStateFlow(
        ReelCustomization(
            selectedArticleId = NewsDataSeed.INITIAL_NEWS[0].id,
            headline = NewsDataSeed.INITIAL_NEWS[0].title,
            summary = NewsDataSeed.INITIAL_NEWS[0].summary,
            cityHindi = NewsDataSeed.INITIAL_NEWS[0].cityHindi,
            categoryHindi = NewsDataSeed.INITIAL_NEWS[0].category.titleHindi,
            reporterName = NewsDataSeed.INITIAL_NEWS[0].reporterName,
            source = NewsDataSeed.INITIAL_NEWS[0].source,
            imageResId = NewsDataSeed.INITIAL_NEWS[0].imageResId,
            dateText = NewsDataSeed.INITIAL_NEWS[0].publishDate,
            templateType = ReelTemplateType.BREAKING_FLASH,
            colorTheme = ReelColorTheme.ORANGE_FIRE
        )
    )
    val reelCustomization: StateFlow<ReelCustomization> = _reelCustomization.asStateFlow()

    // Fullscreen Reel Preview Modal
    private val _isReelPreviewOpen = MutableStateFlow(false)
    val isReelPreviewOpen: StateFlow<Boolean> = _isReelPreviewOpen.asStateFlow()

    // Post Creator Studio State
    private val _postCustomization = MutableStateFlow(
        PostCustomization(
            templateType = PostTemplateType.BREAKING_NEWS,
            colorTheme = PostColorTheme.ORANGE_FIRE,
            headline = NewsDataSeed.INITIAL_NEWS[0].title,
            summary = NewsDataSeed.INITIAL_NEWS[0].summary,
            cityHindi = NewsDataSeed.INITIAL_NEWS[0].cityHindi,
            reporterName = NewsDataSeed.INITIAL_NEWS[0].reporterName,
            imageResId = NewsDataSeed.INITIAL_NEWS[0].imageResId,
            dateText = "21 अगस्त 2026",
            sourceText = "सिटी खबर"
        )
    )
    val postCustomization: StateFlow<PostCustomization> = _postCustomization.asStateFlow()

    // Liked Article IDs (in-memory fast toggle)
    private val _likedArticleIds = MutableStateFlow<Set<String>>(setOf("news_1", "news_3"))
    val likedArticleIds: StateFlow<Set<String>> = _likedArticleIds.asStateFlow()

    // Refresh & Live Feed States
    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _refreshError = MutableStateFlow<String?>(null)
    val refreshError: StateFlow<String?> = _refreshError.asStateFlow()

    val currentNewsList: StateFlow<List<NewsItem>> = repository.currentNewsList

    // Saved Bookmarks from Room Database
    val savedArticles: StateFlow<List<NewsItem>> = repository.getAllSavedNews()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Auto-cached recently opened articles from Room Database
    val cachedArticles: StateFlow<List<NewsItem>> = repository.getAllCachedArticles()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // All combined offline-available articles (Bookmarks + Auto-cached)
    val offlineArticles: StateFlow<List<NewsItem>> = repository.getAllOfflineArticles()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Set of article IDs available offline for fast UI badges
    val offlineArticleIds: StateFlow<Set<String>> = repository.getOfflineArticleIds()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptySet()
        )

    val offlineArticlesCount: StateFlow<Int> = repository.getOfflineArticlesCount()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    // Created Posts History from Room Database
    val createdPostsHistory: StateFlow<List<CreatedPostEntity>> = repository.getAllCreatedPosts()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Reels list from repository
    val reels: StateFlow<List<ReelItem>> = repository.reelsList

    // Saved Reels from Room Database
    val savedReels: StateFlow<List<com.example.data.local.SavedReelEntity>> = repository.getAllSavedReels()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // User Account & Authentication State (Room + Cloud Sync Ready)
    val userAccount: StateFlow<com.example.model.UserAccount> = repository.getUserAccount()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = com.example.model.UserAccount.GUEST_DEFAULT
        )

    // Fullscreen Profile Screen State
    private val _isProfileOpen = MutableStateFlow(false)
    val isProfileOpen: StateFlow<Boolean> = _isProfileOpen.asStateFlow()

    // Auth Prompt Dialog / BottomSheet State
    private val _authPromptReason = MutableStateFlow<com.example.model.AuthPromptReason?>(null)
    val authPromptReason: StateFlow<com.example.model.AuthPromptReason?> = _authPromptReason.asStateFlow()

    private var pendingAuthAction: (() -> Unit)? = null

    // Cloud Synchronization State
    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    // Video Reel Generation States
    private val _isReelGenerating = MutableStateFlow(false)
    val isReelGenerating: StateFlow<Boolean> = _isReelGenerating.asStateFlow()

    private val _reelGenerationProgress = MutableStateFlow(0f)
    val reelGenerationProgress: StateFlow<Float> = _reelGenerationProgress.asStateFlow()

    private val _currentGeneratedVideoPath = MutableStateFlow<String?>(null)
    val currentGeneratedVideoPath: StateFlow<String?> = _currentGeneratedVideoPath.asStateFlow()

    // In-App & System Notifications StateFlows
    val notifications: StateFlow<List<NotificationItem>> = repository.getAllNotifications()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val unreadNotificationsCount: StateFlow<Int> = repository.getUnreadNotificationsCount()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 2
        )

    val notificationPreferences: StateFlow<NotificationPreferences> = repository.getNotificationPreferences()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = NotificationPreferences()
        )

    private val _isNotificationsOpen = MutableStateFlow(false)
    val isNotificationsOpen: StateFlow<Boolean> = _isNotificationsOpen.asStateFlow()

    // Search History StateFlow
    val searchHistory: StateFlow<List<String>> = repository.getAllSearchHistory()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Actions
    fun setTab(tab: AppNavTab) {
        _currentTab.value = tab
    }

    fun selectCity(city: CityInfo) {
        val previousCity = _selectedCity.value
        _selectedCity.value = city
        _isCityModalOpen.value = false
        // Keep selected city synchronized across Create studio templates
        _reelCustomization.value = _reelCustomization.value.copy(cityHindi = city.nameHindi)
        _postCustomization.value = _postCustomization.value.copy(cityHindi = city.nameHindi)
        // Record in recent cities
        viewModelScope.launch {
            repository.recordRecentCity(city.id)

            // If user switched city and city notifications are enabled, post an alert
            if (previousCity.id != city.id && notificationPreferences.value.notificationsEnabled && notificationPreferences.value.cityNewsEnabled) {
                val cityAlertItem = NotificationItem(
                    id = "city_switch_${System.currentTimeMillis()}",
                    newsId = currentNewsList.value.firstOrNull { it.cityHindi.equals(city.nameHindi, ignoreCase = true) }?.id ?: "news_1",
                    title = "🏙️ ${city.nameHindi}: आपका पसंदीदा शहर चुना गया",
                    message = "${city.nameHindi} के सभी स्थानीय समाचार, ब्रेकिंग अपडेट्स और विशेष रिपोर्ट अब लाइव हैं।",
                    type = NotificationType.CITY_IMPORTANT,
                    cityNameHindi = city.nameHindi,
                    timestamp = System.currentTimeMillis(),
                    timeAgo = "अभी-अभी",
                    isRead = false,
                    imageResId = 0
                )
                repository.insertNotification(cityAlertItem)
                NotificationHelper.sendSystemNotification(
                    context = getApplication(),
                    notificationId = 101,
                    title = cityAlertItem.title,
                    message = cityAlertItem.message,
                    type = NotificationType.CITY_IMPORTANT,
                    newsId = cityAlertItem.newsId
                )
            }
        }
    }

    fun toggleFavoriteCity(cityId: String) {
        viewModelScope.launch {
            val isFav = favoriteCityIds.value.contains(cityId)
            repository.toggleFavoriteCity(cityId, isFav)
        }
    }

    fun followCity(cityId: String, setAsPrimary: Boolean = false) {
        viewModelScope.launch {
            repository.followCity(cityId, setAsPrimary)
            val city = repository.getCityById(cityId)
            if (city != null) {
                Toast.makeText(getApplication(), "${city.nameHindi} को फॉलो किया गया", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun unfollowCity(cityId: String) {
        viewModelScope.launch {
            repository.unfollowCity(cityId)
            val city = repository.getCityById(cityId)
            if (city != null) {
                Toast.makeText(getApplication(), "${city.nameHindi} को अनफॉलो किया गया", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun toggleFollowCity(cityId: String) {
        val isFollowed = followedCityIds.value.contains(cityId)
        if (isFollowed) {
            unfollowCity(cityId)
        } else {
            followCity(cityId)
        }
    }

    fun setPrimaryCity(cityId: String) {
        viewModelScope.launch {
            repository.setPrimaryCity(cityId)
            val city = repository.getCityById(cityId)
            if (city != null) {
                _selectedCity.value = city
                Toast.makeText(getApplication(), "${city.nameHindi} को प्राथमिक शहर सेट किया गया ⭐", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun isCityFollowed(cityId: String): Boolean {
        return followedCityIds.value.contains(cityId)
    }

    fun isCityPrimary(cityId: String): Boolean {
        return primaryCityId.value == cityId
    }

    fun getMyCitiesNews(): List<NewsItem> {
        return repository.getNewsForFollowedCities(followedCityIds.value)
    }

    fun clearRecentCities() {
        viewModelScope.launch {
            repository.clearRecentCities()
        }
    }

    fun toggleCityModal(show: Boolean) {
        _isCityModalOpen.value = show
    }

    fun selectCategory(category: NewsCategory) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun submitSearchQuery(query: String) {
        val trimmed = query.trim()
        _searchQuery.value = trimmed
        if (trimmed.isNotBlank()) {
            viewModelScope.launch {
                repository.recordSearchQuery(trimmed)
            }
        }
    }

    fun deleteSearchHistoryItem(query: String) {
        viewModelScope.launch {
            repository.deleteSearchHistoryItem(query)
        }
    }

    fun clearAllSearchHistory() {
        viewModelScope.launch {
            repository.clearAllSearchHistory()
        }
    }

    fun openArticleDetail(article: NewsItem) {
        _detailedArticle.value = article
        // Automatically cache opened article into Room DB for offline reading
        viewModelScope.launch {
            repository.cacheArticle(article)
        }
    }

    fun openArticleDetailById(newsId: Long) {
        val article = currentNewsList.value.find { it.id == newsId.toString() }
            ?: offlineArticles.value.find { it.id == newsId.toString() }
            ?: savedArticles.value.find { it.id == newsId.toString() }
        if (article != null) {
            closeNotifications()
            openArticleDetail(article)
        }
    }

    fun clearAutoCachedNews() {
        viewModelScope.launch {
            repository.clearAutoCachedArticles()
            Toast.makeText(getApplication(), "कैश की गई खबरें साफ कर दी गईं", Toast.LENGTH_SHORT).show()
        }
    }

    fun clearOfflineCache() {
        clearAutoCachedNews()
    }

    fun clearAllOfflineData() {
        viewModelScope.launch {
            repository.clearAllOfflineData()
            Toast.makeText(getApplication(), "सभी ऑफलाइन डेटा हटा दिया गया", Toast.LENGTH_SHORT).show()
        }
    }

    fun closeArticleDetail() {
        _detailedArticle.value = null
        stopAudioReadout()
    }

    fun toggleLikeArticle(articleId: String) {
        val current = _likedArticleIds.value.toMutableSet()
        if (current.contains(articleId)) {
            current.remove(articleId)
        } else {
            current.add(articleId)
        }
        _likedArticleIds.value = current
    }

    fun toggleBookmark(article: NewsItem) {
        viewModelScope.launch {
            val isCurrentlySaved = savedArticles.value.any { it.id == article.id }
            repository.toggleBookmark(article, isCurrentlySaved)
        }
    }

    /**
     * Intercepts bookmark action for guests. Prompts for Google Sign-In while providing "Continue as Guest" option.
     */
    fun toggleBookmarkWithAuthPrompt(article: NewsItem) {
        val isCurrentlySaved = savedArticles.value.any { it.id == article.id }
        if (isCurrentlySaved) {
            // Unsaving does not require auth prompt
            toggleBookmark(article)
        } else if (userAccount.value.isGuest) {
            showAuthPrompt(
                reason = com.example.model.AuthPromptReason.SAVE_FAVORITE,
                onProceed = { toggleBookmark(article) }
            )
        } else {
            toggleBookmark(article)
        }
    }

    fun isArticleBookmarked(articleId: String): Boolean {
        return savedArticles.value.any { it.id == articleId }
    }

    fun clearAllSavedNews() {
        viewModelScope.launch {
            repository.clearAllSavedNews()
        }
    }

    // Saved Reels Management
    fun isReelSaved(reelId: String): Boolean {
        return savedReels.value.any { it.id == reelId }
    }

    fun toggleSaveReel(reel: ReelItem) {
        viewModelScope.launch {
            val isSaved = isReelSaved(reel.id)
            if (isSaved) {
                repository.deleteSavedReel(reel.id)
            } else {
                repository.saveReel(reel)
            }
        }
    }

    fun toggleSaveReelWithAuthPrompt(reel: ReelItem) {
        val isSaved = isReelSaved(reel.id)
        if (isSaved) {
            toggleSaveReel(reel)
        } else if (userAccount.value.isGuest) {
            showAuthPrompt(
                reason = com.example.model.AuthPromptReason.SAVE_REEL,
                onProceed = { toggleSaveReel(reel) }
            )
        } else {
            toggleSaveReel(reel)
        }
    }

    // User Account & Authentication Actions
    fun showAuthPrompt(
        reason: com.example.model.AuthPromptReason,
        onProceed: (() -> Unit)? = null
    ) {
        pendingAuthAction = onProceed
        _authPromptReason.value = reason
    }

    fun dismissAuthPrompt() {
        _authPromptReason.value = null
        pendingAuthAction = null
    }

    fun continueAsGuest() {
        _authPromptReason.value = null
        val action = pendingAuthAction
        pendingAuthAction = null
        action?.invoke()
    }

    fun signInWithGoogle(
        displayName: String = "रोहित शर्मा (Rohit Sharma)",
        email: String = "rohit.sharma@gmail.com"
    ) {
        viewModelScope.launch {
            _isSyncing.value = true
            val account = repository.signInWithGoogle(
                displayName = displayName,
                email = email,
                photoUrl = null
            )
            // Perform automatic cloud sync of favorites, favorite cities, settings, saved posts, reels
            delay(500)
            repository.syncUserData()
            _isSyncing.value = false
            _authPromptReason.value = null

            val action = pendingAuthAction
            pendingAuthAction = null
            action?.invoke()
        }
    }

    fun openProfile() {
        _isProfileOpen.value = true
    }

    fun closeProfile() {
        _isProfileOpen.value = false
    }

    fun toggleProfileModal(show: Boolean) {
        _isProfileOpen.value = show
    }

    fun signInWithCustomAccount(
        displayName: String,
        email: String,
        phone: String? = null,
        city: String? = null,
        bio: String? = null,
        avatarId: String = "avatar_1"
    ) {
        viewModelScope.launch {
            _isSyncing.value = true
            repository.signInWithCustomAccount(
                displayName = displayName,
                email = email,
                phone = phone,
                city = city,
                bio = bio,
                avatarId = avatarId
            )
            delay(500)
            repository.syncUserData()
            _isSyncing.value = false
            _authPromptReason.value = null

            val action = pendingAuthAction
            pendingAuthAction = null
            action?.invoke()
        }
    }

    fun updateUserProfile(
        displayName: String,
        email: String,
        phone: String?,
        bio: String?,
        city: String?,
        avatarId: String,
        photoUrl: String? = null
    ) {
        viewModelScope.launch {
            repository.updateUserProfile(
                displayName = displayName,
                email = email,
                phone = phone,
                bio = bio,
                city = city,
                avatarId = avatarId,
                photoUrl = photoUrl
            )
        }
    }

    fun signOut() {
        viewModelScope.launch {
            repository.signOut()
        }
    }

    fun syncAllUserData() {
        viewModelScope.launch {
            _isSyncing.value = true
            delay(700)
            repository.syncUserData()
            _isSyncing.value = false
        }
    }

    fun activatePremium() {
        viewModelScope.launch {
            _isSyncing.value = true
            repository.setPremiumStatus(true)
            delay(400)
            _isSyncing.value = false
        }
    }

    fun requestPremiumWithAuthCheck(onProceed: (() -> Unit)? = null) {
        if (userAccount.value.isGuest) {
            showAuthPrompt(
                reason = com.example.model.AuthPromptReason.PREMIUM_FEATURES,
                onProceed = onProceed
            )
        } else {
            onProceed?.invoke()
        }
    }

    fun requestSavePostWithAuthCheck(onProceed: () -> Unit) {
        if (userAccount.value.isGuest) {
            showAuthPrompt(
                reason = com.example.model.AuthPromptReason.SAVE_POST,
                onProceed = onProceed
            )
        } else {
            onProceed()
        }
    }

    // ==========================================
    // NOTIFICATION OPERATIONS & CONTROLS
    // ==========================================

    fun openNotifications() {
        _isNotificationsOpen.value = true
    }

    fun closeNotifications() {
        _isNotificationsOpen.value = false
    }

    fun toggleNotificationsModal(show: Boolean) {
        _isNotificationsOpen.value = show
    }

    fun toggleNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            val current = notificationPreferences.value
            repository.saveNotificationPreferences(current.copy(notificationsEnabled = enabled))
        }
    }

    fun toggleBreakingNewsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            val current = notificationPreferences.value
            repository.saveNotificationPreferences(current.copy(breakingNewsEnabled = enabled))
        }
    }

    fun toggleImportantNewsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            val current = notificationPreferences.value
            repository.saveNotificationPreferences(current.copy(importantNewsEnabled = enabled))
        }
    }

    fun toggleCityNewsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            val current = notificationPreferences.value
            repository.saveNotificationPreferences(current.copy(cityNewsEnabled = enabled))
        }
    }

    fun toggleDailyUpdatesEnabled(enabled: Boolean) {
        viewModelScope.launch {
            val current = notificationPreferences.value
            repository.saveNotificationPreferences(current.copy(dailyUpdatesEnabled = enabled))
        }
    }

    fun markNotificationAsRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
            Toast.makeText(getApplication(), "सभी सूचनाएं पढ़ी हुई मार्क की गईं", Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteNotification(id: String) {
        viewModelScope.launch {
            repository.deleteNotification(id)
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            repository.clearAllNotifications()
            Toast.makeText(getApplication(), "सभी सूचनाएं हटा दी गईं", Toast.LENGTH_SHORT).show()
        }
    }

    fun onNotificationClicked(notification: NotificationItem) {
        viewModelScope.launch {
            repository.markNotificationAsRead(notification.id)
        }
        if (notification.newsId != null) {
            val article = currentNewsList.value.find { it.id == notification.newsId }
                ?: savedArticles.value.find { it.id == notification.newsId }
                ?: NewsDataSeed.INITIAL_NEWS.find { it.id == notification.newsId }
            if (article != null) {
                _detailedArticle.value = article
                _isNotificationsOpen.value = false
            }
        }
    }

    fun sendTestNotification(type: NotificationType = NotificationType.BREAKING_NEWS) {
        viewModelScope.launch {
            val prefs = notificationPreferences.value
            if (!prefs.notificationsEnabled) {
                Toast.makeText(getApplication(), "सूचनाएं बंद हैं! कृपया पहले सेटिंग्स से चालू करें।", Toast.LENGTH_SHORT).show()
                return@launch
            }

            val city = selectedCity.value
            val (title, message) = when (type) {
                NotificationType.BREAKING_NEWS -> {
                    "🚨 ब्रेकिंग अलर्ट: ${city.nameHindi} में नई स्मार्ट सिटी परियोजना शुरू" to
                    "सड़क चौड़ीकरण और सौर ऊर्जा ग्रिड के लिए ₹150 करोड़ के नए टेंडर आज जारी किए गए।"
                }
                NotificationType.IMPORTANT_NEWS -> {
                    "⭐ महत्वपूर्ण समाचार: राज्य लोक सेवा आयोग परीक्षा की नई तिथि घोषित" to
                    "प्रवेश पत्र डाउनलोड लिंक आधिकारिक पोर्टल पर सक्रिय, सभी परीक्षा केंद्रों पर कड़ी सुरक्षा व्यवस्था।"
                }
                NotificationType.CITY_IMPORTANT -> {
                    "🏙️ ${city.nameHindi} विशेष: नगर निगम की नई हेल्पलाइन सेवा शुरू" to
                    "नागरिक समस्याओं के 24 घंटे में समाधान हेतु सिंगल विंडो डिजिटल पोर्टल लॉन्च।"
                }
                NotificationType.DAILY_UPDATE -> {
                    "📰 दैनिक बुलेटिन: ${city.nameHindi} और राज्य के मुख्य समाचार" to
                    "मेट्रो विस्तार, मौसम अलर्ट और युवा रोजगार से जुड़ी आज की 5 प्रमुख खबरें।"
                }
                NotificationType.SYSTEM -> {
                    "🔔 सिटी ख़बर: आपका शहर ${city.nameHindi} सफलता पूर्वक सिंक हुआ" to
                    "ताज़ा स्थानीय समाचार और रील अपडेट्स अब आपके होमपेज पर उपलब्ध हैं।"
                }
            }

            val newItem = NotificationItem(
                id = "test_notif_${System.currentTimeMillis()}",
                newsId = currentNewsList.value.firstOrNull()?.id ?: "news_1",
                title = title,
                message = message,
                type = type,
                cityNameHindi = city.nameHindi,
                timestamp = System.currentTimeMillis(),
                timeAgo = "अभी-अभी",
                isRead = false,
                imageResId = 0
            )

            repository.insertNotification(newItem)

            NotificationHelper.sendSystemNotification(
                context = getApplication(),
                notificationId = (System.currentTimeMillis() % 10000).toInt(),
                title = title,
                message = message,
                type = type,
                newsId = newItem.newsId
            )

            Toast.makeText(getApplication(), "🔔 टेस्ट सूचना भेजी गई: ${type.titleHindi}", Toast.LENGTH_SHORT).show()
        }
    }

    // Audio Readout Controls
    fun toggleAudioReadout(article: NewsItem) {
        if (_audioState.value.isPlaying && _audioState.value.currentArticleId == article.id) {
            pauseAudioReadout()
        } else {
            startAudioReadout(article)
        }
    }

    private fun startAudioReadout(article: NewsItem) {
        audioJob?.cancel()
        _audioState.value = _audioState.value.copy(
            isPlaying = true,
            currentArticleId = article.id
        )
        audioJob = viewModelScope.launch {
            val totalSeconds = 45
            while (_audioState.value.elapsedSeconds < totalSeconds && _audioState.value.isPlaying) {
                delay((1000 / _audioState.value.playbackSpeed).toLong())
                val newElapsed = _audioState.value.elapsedSeconds + 1
                val progress = newElapsed.toFloat() / totalSeconds.toFloat()
                _audioState.value = _audioState.value.copy(
                    elapsedSeconds = newElapsed,
                    progress = progress.coerceIn(0f, 1f)
                )
            }
            if (_audioState.value.elapsedSeconds >= totalSeconds) {
                stopAudioReadout()
            }
        }
    }

    private fun pauseAudioReadout() {
        audioJob?.cancel()
        _audioState.value = _audioState.value.copy(isPlaying = false)
    }

    fun stopAudioReadout() {
        audioJob?.cancel()
        _audioState.value = AudioReadoutState()
    }

    fun cycleAudioSpeed() {
        val currentSpeed = _audioState.value.playbackSpeed
        val nextSpeed = when (currentSpeed) {
            1.0f -> 1.25f
            1.25f -> 1.5f
            1.5f -> 2.0f
            else -> 1.0f
        }
        _audioState.value = _audioState.value.copy(playbackSpeed = nextSpeed)
    }

    fun setCreationStudioMode(mode: CreationStudioMode) {
        _creationStudioMode.value = mode
    }

    // 9:16 Reel Creator Studio Functions
    fun startCreatingReelFromArticle(article: NewsItem) {
        _reelCustomization.value = _reelCustomization.value.copy(
            selectedArticleId = article.id,
            headline = article.title,
            summary = article.summary,
            cityHindi = article.cityHindi,
            categoryHindi = article.category.titleHindi,
            reporterName = article.reporterName,
            source = article.source,
            imageResId = article.imageResId,
            dateText = article.publishDate
        )
        // Also sync post customization for seamless tab switching
        _postCustomization.value = _postCustomization.value.copy(
            headline = article.title,
            summary = article.summary,
            cityHindi = article.cityHindi,
            reporterName = article.reporterName,
            imageResId = article.imageResId,
            dateText = article.publishDate
        )
        _creationStudioMode.value = CreationStudioMode.REEL_9_16
        _currentTab.value = AppNavTab.CREATE
        _detailedArticle.value = null
    }

    fun updateReelCustomization(customization: ReelCustomization) {
        _reelCustomization.value = customization
    }

    fun updateReelTemplate(type: ReelTemplateType) {
        _reelCustomization.value = _reelCustomization.value.copy(templateType = type)
    }

    fun updateReelTheme(theme: ReelColorTheme) {
        _reelCustomization.value = _reelCustomization.value.copy(colorTheme = theme)
    }

    fun updateReelHeadline(text: String) {
        _reelCustomization.value = _reelCustomization.value.copy(headline = text)
    }

    fun updateReelSummary(text: String) {
        _reelCustomization.value = _reelCustomization.value.copy(summary = text)
    }

    fun updateReelCity(cityName: String) {
        _reelCustomization.value = _reelCustomization.value.copy(cityHindi = cityName)
    }

    fun updateReelCategory(categoryName: String) {
        _reelCustomization.value = _reelCustomization.value.copy(categoryHindi = categoryName)
    }

    fun updateReelReporter(name: String) {
        _reelCustomization.value = _reelCustomization.value.copy(reporterName = name)
    }

    fun updateReelImage(resId: Int) {
        _reelCustomization.value = _reelCustomization.value.copy(imageResId = resId)
    }

    fun toggleReelCityBadge(show: Boolean) {
        _reelCustomization.value = _reelCustomization.value.copy(showCityBadge = show)
    }

    fun toggleReelCategoryBadge(show: Boolean) {
        _reelCustomization.value = _reelCustomization.value.copy(showCategoryBadge = show)
    }

    fun toggleReelReporter(show: Boolean) {
        _reelCustomization.value = _reelCustomization.value.copy(showReporter = show)
    }

    fun toggleReelWatermark(show: Boolean) {
        _reelCustomization.value = _reelCustomization.value.copy(showWatermark = show)
    }

    fun openReelPreview() {
        _isReelPreviewOpen.value = true
    }

    fun closeReelPreview() {
        _isReelPreviewOpen.value = false
    }

    /**
     * Ensures an actual playable MP4 video exists on device for any given ReelItem.
     */
    suspend fun ensureReelVideoReady(context: Context, reel: ReelItem): String? = withContext(Dispatchers.IO) {
        try {
            if (reel.videoPath != null && java.io.File(reel.videoPath).exists()) {
                return@withContext reel.videoPath
            }
            val videoFile = ReelVideoGenerator.getOrGenerateReelVideo(context, reel)
            repository.updateReelVideoPath(reel.id, videoFile.absolutePath)
            return@withContext videoFile.absolutePath
        } catch (e: Exception) {
            return@withContext null
        }
    }

    /**
     * Generates a playable MP4 video reel from the current studio customization,
     * adds it to the Reels screen, saves to database history, and optionally plays it.
     */
    fun generateAndSaveReelVideo(
        context: Context,
        navigateToReels: Boolean = false,
        onSuccess: (() -> Unit)? = null
    ) {
        if (_isReelGenerating.value) return
        _isReelGenerating.value = true
        _reelGenerationProgress.value = 0f

        viewModelScope.launch {
            try {
                val customization = _reelCustomization.value
                val videoFile = ReelVideoGenerator.generateCustomReelVideo(context, customization) { progress ->
                    _reelGenerationProgress.value = progress
                }

                _currentGeneratedVideoPath.value = videoFile.absolutePath

                val newReelItem = ReelItem(
                    id = "reel_custom_${System.currentTimeMillis()}",
                    title = customization.headline.ifBlank { "सिटी खबर: विशेष वीडियो रील रिपोर्ट" },
                    description = customization.summary,
                    cityHindi = customization.cityHindi,
                    category = customization.categoryHindi.ifBlank { "रील्स स्पेशल" },
                    reporter = customization.reporterName.ifBlank { "सिटी खबर स्पेशल" },
                    imageResId = customization.imageResId,
                    likesCount = 120,
                    commentsCount = 14,
                    sharesCount = 35,
                    timeAgo = "अभी-अभी (ताज़ा रील)",
                    isLiked = true,
                    videoPath = videoFile.absolutePath,
                    videoUri = android.net.Uri.fromFile(videoFile).toString()
                )

                // Add to repository so it immediately shows up on the Reels tab
                repository.addNewReel(newReelItem)

                // Save to Room history
                repository.saveCreatedPost(
                    CreatedPostEntity(
                        templateId = customization.templateType.id,
                        colorThemeId = customization.colorTheme.id,
                        headline = customization.headline,
                        summary = customization.summary,
                        cityHindi = customization.cityHindi,
                        reporterName = customization.reporterName,
                        imageResId = customization.imageResId
                    )
                )

                _isReelGenerating.value = false
                Toast.makeText(context, "✅ 9:16 वीडियो रील सफलतापूर्वक तैयार हो गई!", Toast.LENGTH_SHORT).show()

                if (navigateToReels) {
                    _currentTab.value = AppNavTab.REELS
                }

                onSuccess?.invoke()
            } catch (e: Exception) {
                _isReelGenerating.value = false
                Toast.makeText(context, "रील जनरेट करने में त्रुटि। फिर से कोशिश करें।", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun downloadCurrentReel(context: Context) {
        val reel = _reelCustomization.value
        val bitmap = PostExportUtil.renderReelBitmap(context, reel)
        PostExportUtil.saveReelToGallery(context, bitmap, reel.headline)

        // Also generate MP4 video in background for seamless video playback
        generateAndSaveReelVideo(context)

        // Save to Room Database History
        viewModelScope.launch {
            repository.saveCreatedPost(
                CreatedPostEntity(
                    templateId = reel.templateType.id,
                    colorThemeId = reel.colorTheme.id,
                    headline = reel.headline,
                    summary = reel.summary,
                    cityHindi = reel.cityHindi,
                    reporterName = reel.reporterName,
                    imageResId = reel.imageResId
                )
            )
        }
    }

    fun shareCurrentReel(context: Context) {
        val reel = _reelCustomization.value
        PostExportUtil.shareReel(context, reel)

        // Save to history
        viewModelScope.launch {
            repository.saveCreatedPost(
                CreatedPostEntity(
                    templateId = reel.templateType.id,
                    colorThemeId = reel.colorTheme.id,
                    headline = reel.headline,
                    summary = reel.summary,
                    cityHindi = reel.cityHindi,
                    reporterName = reel.reporterName,
                    imageResId = reel.imageResId
                )
            )
        }
    }

    // Post Creator Studio Functions
    fun startCreatingPostFromArticle(article: NewsItem) {
        _postCustomization.value = _postCustomization.value.copy(
            headline = article.title,
            summary = article.summary,
            cityHindi = article.cityHindi,
            reporterName = article.reporterName,
            imageResId = article.imageResId,
            dateText = article.publishDate
        )
        _creationStudioMode.value = CreationStudioMode.POST_4_5
        _currentTab.value = AppNavTab.CREATE
        _detailedArticle.value = null
    }

    fun updatePostCustomization(customization: PostCustomization) {
        _postCustomization.value = customization
    }

    fun updateTemplateType(type: PostTemplateType) {
        _postCustomization.value = _postCustomization.value.copy(templateType = type)
    }

    fun updateColorTheme(theme: PostColorTheme) {
        _postCustomization.value = _postCustomization.value.copy(colorTheme = theme)
    }

    fun updateHeadline(text: String) {
        _postCustomization.value = _postCustomization.value.copy(headline = text)
    }

    fun updateSummary(text: String) {
        _postCustomization.value = _postCustomization.value.copy(summary = text)
    }

    fun updateReporterName(name: String) {
        _postCustomization.value = _postCustomization.value.copy(reporterName = name)
    }

    fun updateCity(cityName: String) {
        _postCustomization.value = _postCustomization.value.copy(cityHindi = cityName)
    }

    fun updateImageRes(resId: Int) {
        _postCustomization.value = _postCustomization.value.copy(imageResId = resId)
    }

    fun toggleReporterVisible(show: Boolean) {
        _postCustomization.value = _postCustomization.value.copy(showReporter = show)
    }

    fun toggleCityBadgeVisible(show: Boolean) {
        _postCustomization.value = _postCustomization.value.copy(showCityBadge = show)
    }

    fun toggleWatermarkVisible(show: Boolean) {
        _postCustomization.value = _postCustomization.value.copy(showWatermark = show)
    }

    fun toggleBreakingTagVisible(show: Boolean) {
        _postCustomization.value = _postCustomization.value.copy(showBreakingTag = show)
    }

    fun downloadCurrentPost(context: Context) {
        val post = _postCustomization.value
        val bitmap = PostExportUtil.renderPostBitmap(context, post)
        PostExportUtil.saveBitmapToGallery(context, bitmap, post.headline)

        // Save to Room Database History
        viewModelScope.launch {
            repository.saveCreatedPost(
                CreatedPostEntity(
                    templateId = post.templateType.id,
                    colorThemeId = post.colorTheme.id,
                    headline = post.headline,
                    summary = post.summary,
                    cityHindi = post.cityHindi,
                    reporterName = post.reporterName,
                    imageResId = post.imageResId
                )
            )
        }
    }

    fun shareCurrentPost(context: Context) {
        val post = _postCustomization.value
        PostExportUtil.sharePost(context, post)

        // Save to history on share
        viewModelScope.launch {
            repository.saveCreatedPost(
                CreatedPostEntity(
                    templateId = post.templateType.id,
                    colorThemeId = post.colorTheme.id,
                    headline = post.headline,
                    summary = post.summary,
                    cityHindi = post.cityHindi,
                    reporterName = post.reporterName,
                    imageResId = post.imageResId
                )
            )
        }
    }

    fun deleteCreatedPost(postId: Long) {
        viewModelScope.launch {
            repository.deleteCreatedPost(postId)
        }
    }

    /**
     * Triggers news refresh. Keeps selected city, category, and search filters intact.
     * If refresh fails, sets Hindi error message: "खबरें अपडेट नहीं हो सकीं। फिर से कोशिश करें।"
     */
    fun refreshNews(forceError: Boolean = false) {
        if (_isRefreshing.value) return
        _isRefreshing.value = true
        _refreshError.value = null

        viewModelScope.launch {
            val cityName = if (_selectedCity.value.nameHindi == "सभी शहर") null else _selectedCity.value.nameHindi
            val result = repository.refreshLatestNews(selectedCityName = cityName, forceError = forceError)
            result.onSuccess {
                _refreshError.value = null
            }.onFailure {
                _refreshError.value = "खबरें अपडेट नहीं हो सकीं। फिर से कोशिश करें।"
            }
            _isRefreshing.value = false
        }
    }

    fun dismissRefreshError() {
        _refreshError.value = null
    }

    fun getFilteredNews(): List<NewsItem> {
        // If offline mode is active or no network, return cached/offline news filtered
        if (isOfflineActive.value && currentNewsList.value.isEmpty()) {
            return getOfflineFilteredNews()
        }
        return repository.getNewsFiltered(
            selectedCity = if (_selectedCity.value.nameHindi == "सभी शहर") null else _selectedCity.value.nameHindi,
            selectedCategory = _selectedCategory.value,
            searchQuery = _searchQuery.value
        )
    }

    fun getOfflineFilteredNews(): List<NewsItem> {
        val allOffline = if (offlineArticles.value.isNotEmpty()) offlineArticles.value else savedArticles.value
        val cityFilter = if (_selectedCity.value.nameHindi == "सभी शहर") null else _selectedCity.value.nameHindi
        val categoryFilter = _selectedCategory.value
        val query = _searchQuery.value.trim()

        return allOffline.filter { item ->
            val matchesCity = cityFilter == null || item.cityHindi.equals(cityFilter, ignoreCase = true)
            val matchesCategory = categoryFilter == NewsCategory.ALL || item.category == categoryFilter
            val matchesSearch = query.isBlank() ||
                    item.title.contains(query, ignoreCase = true) ||
                    item.summary.contains(query, ignoreCase = true) ||
                    item.cityHindi.contains(query, ignoreCase = true) ||
                    item.source.contains(query, ignoreCase = true)
            matchesCity && matchesCategory && matchesSearch
        }
    }

    fun getCityNews(cityName: String): List<NewsItem> {
        return repository.getNewsByCity(cityName)
    }

    fun getBreakingNews(): List<NewsItem> = repository.getBreakingNews()

    fun getTrendingNews(
        selectedCity: String? = null,
        selectedCategory: NewsCategory = NewsCategory.ALL
    ): List<NewsItem> {
        val city = if (selectedCity != null) {
            if (selectedCity == "सभी शहर") null else selectedCity
        } else {
            if (_selectedCity.value.nameHindi == "सभी शहर") null else _selectedCity.value.nameHindi
        }
        return repository.getTrendingNews(city, selectedCategory)
    }

    fun getTrendingNews(): List<NewsItem> {
        return repository.getTrendingNews(
            selectedCity = if (_selectedCity.value.nameHindi == "सभी शहर") null else _selectedCity.value.nameHindi,
            selectedCategory = _selectedCategory.value
        )
    }
}
