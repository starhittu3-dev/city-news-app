package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Diversity1
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.OrangeDark
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.VerifiedBadgeBlue

/**
 * About Us Screen for City Khabar.
 * Highlights the App name: City Khabar, Tagline: "आपके शहर की हर खबर",
 * and how the app helps users discover and create shareable content from city news.
 */
@Composable
fun AboutUsScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("about_us_screen")
    ) {
        // Top App Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 3.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("about_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "वापस जाएं",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                Column {
                    Text(
                        text = "हमारे बारे में (About Us)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "सिटी ख़बर • स्थानीय पत्रकारिता का नया युग",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 40.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Brand Identity Card
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(3.dp),
                    border = BorderStroke(1.dp, OrangePrimary.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth().testTag("about_hero_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // App Logo
                        Surface(
                            modifier = Modifier
                                .size(88.dp)
                                .shadow(elevation = 8.dp, shape = RoundedCornerShape(20.dp)),
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(2.dp, OrangePrimary.copy(alpha = 0.6f))
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_city_khabar_logo),
                                contentDescription = "City Khabar Logo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // App Name: City Khabar & Hindi
                        Text(
                            text = "City Khabar",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "सिटी ख़बर",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = OrangePrimary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Required Tagline: "आपके शहर की हर खबर"
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = OrangePrimary.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, OrangePrimary.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "“आपके शहर की हर खबर”",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = OrangeDark,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "संस्करण 1.0.0 • भारत में गर्व से निर्मित 🇮🇳",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Core Purpose: Discover and Create Shareable Content
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = OrangePrimary.copy(alpha = 0.12f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = OrangePrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "हमारा मिशन (Our Mission)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "सिटी खबर (City Khabar) केवल एक न्यूज़ ऐप नहीं है, बल्कि यह एक संपूर्ण स्थानीय समाचार और सोशल मीडिया कंटेंट निर्माण प्लेटफ़ॉर्म है।\n\nहमारा मुख्य उद्देश्य उपयोगकर्ताओं को उनके शहर की सटीक और ताज़ा खबरों से जोड़ना है, और साथ ही उन्हें उन खबरों से सुंदर, पेशेवर और आसानी से शेयर करने योग्य (Shareable) सोशल मीडिया पोस्टर्स और 9:16 वीडियो रील्स बनाने की सुविधा प्रदान करना है।",
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Key Highlights / Features
            item {
                Text(
                    text = "सिटी खबर की मुख्य विशेषताएं",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            item {
                FeatureHighlightCard(
                    icon = Icons.Default.LocationCity,
                    iconTint = OrangePrimary,
                    title = "हाइपरलोकल शहर समाचार (City News Discovery)",
                    description = "दिल्ली, मुंबई, लखनऊ, जयपुर, पटना, भोपाल, इंदौर सहित सभी प्रमुख शहरों के वार्ड व ज़िला स्तर की ताज़ा रिपोर्टिंग।"
                )
            }

            item {
                FeatureHighlightCard(
                    icon = Icons.Default.Movie,
                    iconTint = CrimsonRed,
                    title = "9:16 वर्टिकल वीडियो रील्स (Video Reels)",
                    description = "ताज़ा ब्रेकिंग खबरों को आकर्षक फुल-स्क्रीन रील्स के रूप में देखें और सीधे अपने फोन में वीडियो जनरेट कर WhatsApp/Instagram पर साझा करें।"
                )
            }

            item {
                FeatureHighlightCard(
                    icon = Icons.Default.Share,
                    iconTint = Color(0xFF2E7D32),
                    title = "क्रिएटिव पोस्टर स्टूडियो (Shareable Post Studio)",
                    description = "किसी भी खबर से एक क्लिक में ब्रेकिंग न्यूज़ बैनर, रिपोर्टर वॉटरमार्क और सिटी बैज के साथ हाई-रेज़ोल्यूशन पोस्टर तैयार करें।"
                )
            }

            item {
                FeatureHighlightCard(
                    icon = Icons.Default.Verified,
                    iconTint = VerifiedBadgeBlue,
                    title = "100% सत्यापित एवं निष्पक्ष पत्रकारिता",
                    description = "फेक न्यूज़ से मुक्त, आधिकारिक प्रेस विज्ञप्तियों एवं अनुभवी स्थानीय संवाददाताओं द्वारा क्रॉस-वेरिफाइड खबरें।"
                )
            }

            // Editorial Values & Integrity
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Diversity1,
                                contentDescription = null,
                                tint = OrangePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "संपादकीय नीति एवं सत्यनिष्ठा",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "• निष्पक्षता: किसी भी राजनीतिक या व्यावसायिक दबाव के बिना स्वतंत्र रिपोर्टिंग।\n• जनसरोकार: आम नागरिकों की समस्याएं, मौसम, यातायात, शिक्षा और विकास से जुड़े मुद्दे।\n• उत्तरदायित्व: यदि किसी तथ्य में त्रुटि पाई जाती है, तो उसे त्वरित रूप से सुधारने की प्रतिबद्धता।",
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Share App Action Button
            item {
                Button(
                    onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "📢 City Khabar (सिटी ख़बर) - \"आपके शहर की हर खबर\"\nताज़ा स्थानीय खबरें पढ़ें और शानदार पोस्टर व रील्स बनाएं! अभी डाउनलोड करें: https://citykhabar.in"
                            )
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "सिटी खबर ऐप शेयर करें"))
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("share_app_btn")
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("दोस्तों और परिजनों के साथ ऐप शेयर करें", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun FeatureHighlightCard(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    description: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = iconTint.copy(alpha = 0.12f),
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = description,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
