package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditLocation
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CreatedPostEntity
import com.example.model.CityInfo
import com.example.model.NotificationPreferences
import com.example.model.NotificationType
import com.example.model.ThemeMode
import com.example.model.UserAccount
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.OrangeDark
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.VerifiedBadgeBlue
import com.example.util.PostExportUtil

import com.example.model.NewsItem

enum class SettingsSubScreen {
    PRIVACY_POLICY,
    ABOUT_US,
    CONTACT_SUPPORT,
    SAVED_NEWS
}

@Composable
fun SettingsScreen(
    selectedCity: CityInfo,
    savedNewsCount: Int,
    createdPostsHistory: List<CreatedPostEntity>,
    userAccount: UserAccount = UserAccount.GUEST_DEFAULT,
    savedArticles: List<NewsItem> = emptyList(),
    cachedArticles: List<NewsItem> = emptyList(),
    offlineArticlesCount: Int = 0,
    cachedArticlesCount: Int = 0,
    isManualOfflineMode: Boolean = false,
    likedArticleIds: Set<String> = emptySet(),
    savedReelsCount: Int = 0,
    favoriteCitiesCount: Int = 3,
    isSyncing: Boolean = false,
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    notificationPreferences: NotificationPreferences = NotificationPreferences(),
    unreadNotificationsCount: Int = 0,
    onThemeModeChange: (ThemeMode) -> Unit = {},
    onChangeCityClick: () -> Unit,
    onDeleteCreatedPost: (Long) -> Unit,
    onToggleNotificationsEnabled: (Boolean) -> Unit = {},
    onToggleBreakingNews: (Boolean) -> Unit = {},
    onToggleImportantNews: (Boolean) -> Unit = {},
    onToggleCityNews: (Boolean) -> Unit = {},
    onToggleDailyUpdates: (Boolean) -> Unit = {},
    onOpenNotificationsPage: () -> Unit = {},
    onSendTestNotification: (NotificationType) -> Unit = {},
    onSignInClick: () -> Unit = {},
    onSignOutClick: () -> Unit = {},
    onSyncClick: () -> Unit = {},
    onOpenProfile: () -> Unit = {},
    onActivatePremiumClick: () -> Unit = {},
    onArticleClick: (NewsItem) -> Unit = {},
    onBookmarkClick: (NewsItem) -> Unit = {},
    onLikeClick: (String) -> Unit = {},
    onCreatePostClick: (NewsItem) -> Unit = {},
    onClearAllSavedNews: () -> Unit = {},
    onClearOfflineCache: () -> Unit = {},
    onClearAllOfflineData: () -> Unit = {},
    onToggleManualOfflineMode: (Boolean) -> Unit = {},
    onExploreNewsClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var notificationsEnabled by remember { mutableStateOf(true) }
    var activeSubScreen by remember { mutableStateOf<SettingsSubScreen?>(null) }
    var showSignOutDialog by remember { mutableStateOf(false) }
    var showClearOfflineCacheDialog by remember { mutableStateOf(false) }
    var showClearAllOfflineDialog by remember { mutableStateOf(false) }

    // Intercept back presses when inside a sub-screen
    BackHandler(enabled = activeSubScreen != null) {
        activeSubScreen = null
    }

    if (showClearOfflineCacheDialog) {
        AlertDialog(
            onDismissRequest = { showClearOfflineCacheDialog = false },
            title = {
                Text(
                    text = "ऑफलाइन कैश साफ करें?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "क्या आप हाल ही में पढ़ी गई $cachedArticlesCount कैश्ड खबरों का डेटा हटाना चाहते हैं? आपकी बुकमार्क की गई खबरें सुरक्षित रहेंगी।",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showClearOfflineCacheDialog = false
                        onClearOfflineCache()
                        android.widget.Toast.makeText(context, "ऑफलाइन कैश साफ कर दिया गया", android.widget.Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("कैश हटाएं", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearOfflineCacheDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    if (showClearAllOfflineDialog) {
        AlertDialog(
            onDismissRequest = { showClearAllOfflineDialog = false },
            title = {
                Text(
                    text = "सभी ऑफलाइन डेटा हटाएं?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "क्या आप सभी $offlineArticlesCount ऑफलाइन खबरें (कैश + सेव्ड खबरें) हटाना चाहते हैं?",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showClearAllOfflineDialog = false
                        onClearAllOfflineData()
                        android.widget.Toast.makeText(context, "सभी ऑफलाइन डेटा साफ कर दिया गया", android.widget.Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("सभी हटाएं", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearAllOfflineDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    if (showSignOutDialog) {
        AlertDialog(
            onDismissRequest = { showSignOutDialog = false },
            title = {
                Text(
                    text = "साइन आउट की पुष्टि",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "क्या आप अपने गूगल अकाउंट से साइन आउट करना चाहते हैं? आप किसी भी समय वापस साइन इन कर सकते हैं।",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSignOutDialog = false
                        onSignOutClick()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("साइन आउट करें", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    when (activeSubScreen) {
        SettingsSubScreen.PRIVACY_POLICY -> {
            PrivacyPolicyScreen(
                onBackClick = { activeSubScreen = null },
                modifier = modifier
            )
        }
        SettingsSubScreen.ABOUT_US -> {
            AboutUsScreen(
                onBackClick = { activeSubScreen = null },
                modifier = modifier
            )
        }
        SettingsSubScreen.CONTACT_SUPPORT -> {
            ContactSupportScreen(
                onBackClick = { activeSubScreen = null },
                modifier = modifier
            )
        }
        SettingsSubScreen.SAVED_NEWS -> {
            SavedNewsScreen(
                savedNewsList = savedArticles,
                cachedNewsList = cachedArticles,
                likedArticleIds = likedArticleIds,
                userAccount = userAccount,
                onBackClick = { activeSubScreen = null },
                onArticleClick = onArticleClick,
                onBookmarkClick = onBookmarkClick,
                onLikeClick = onLikeClick,
                onCreatePostClick = onCreatePostClick,
                onClearAllSavedNews = onClearAllSavedNews,
                onClearCachedNews = onClearOfflineCache,
                onClearAllOfflineData = onClearAllOfflineData,
                onSignInClick = onSignInClick,
                onExploreNewsClick = onExploreNewsClick,
                modifier = modifier
            )
        }
        null -> {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .testTag("settings_screen")
            ) {
                // Top Header
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 2.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(listOf(OrangePrimary, CrimsonRed))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("⚙️", fontSize = 18.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "सेटिंग्स व प्रोफाइल",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = OrangePrimary
                            )
                            Text(
                                text = "अकाउंट, सिंक और प्राथमिकताएं",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 80.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 1. Account & Profile Section
                    item {
                        Text(
                            text = "यूजर अकाउंट एवं प्रोफाइल (User Account)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("account_profile_card"),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            elevation = CardDefaults.cardElevation(2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                if (userAccount.isGuest) {
                                    // GUEST MODE VIEW
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            modifier = Modifier.size(54.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = Icons.Default.AccountCircle,
                                                    contentDescription = "Guest",
                                                    tint = Color.Gray,
                                                    modifier = Modifier.size(36.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(14.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "अतिथि पाठक (Guest)",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 16.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = Color.Gray.copy(alpha = 0.15f)
                                                ) {
                                                    Text(
                                                        text = "ऑफलाइन",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.Gray,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "साइन इन नहीं किया गया है। आपका डेटा स्थानीय डिवाइस पर सुरक्षित है।",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                lineHeight = 16.sp
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // Sign in with Google Button
                                    Button(
                                        onClick = onSignInClick,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(46.dp)
                                            .testTag("settings_google_signin_button"),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.surface,
                                            contentColor = MaterialTheme.colorScheme.onSurface
                                        ),
                                        border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.outlineVariant)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(20.dp)
                                                    .clip(CircleShape)
                                                    .background(Color.White),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("G", fontSize = 13.sp, fontWeight = FontWeight.Black, color = VerifiedBadgeBlue)
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = "Google से साइन इन करें",
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    OutlinedButton(
                                        onClick = onOpenProfile,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(42.dp)
                                            .testTag("settings_open_guest_profile_btn"),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = "मेरी प्रोफ़ाइल देखें / नया अकाउंट बनाएं",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = OrangePrimary
                                        )
                                    }
                                } else {
                                    // SIGNED IN USER VIEW
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable(onClick = onOpenProfile),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = OrangePrimary,
                                            modifier = Modifier.size(54.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(Brush.linearGradient(listOf(OrangePrimary, CrimsonRed))),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = userAccount.displayName.take(1).uppercase(),
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 22.sp
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(14.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = userAccount.displayName,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 16.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Icon(
                                                    imageVector = Icons.Default.Verified,
                                                    contentDescription = "Verified Google",
                                                    tint = VerifiedBadgeBlue,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = userAccount.email.ifBlank { "google_account@gmail.com" },
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (userAccount.isPremium) {
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = Color(0xFFFFD54F).copy(alpha = 0.2f),
                                                        border = BorderStroke(1.dp, Color(0xFFFFB300))
                                                    ) {
                                                        Text(
                                                            text = "👑 VIP प्रीमियम सदस्य",
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFFE65100),
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                } else {
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = OrangePrimary.copy(alpha = 0.12f)
                                                    ) {
                                                        Text(
                                                            text = "सक्रिय गूगल अकाउंट",
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = OrangeDark,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // View / Edit Profile Button
                                    Button(
                                        onClick = onOpenProfile,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(42.dp)
                                            .testTag("settings_open_profile_btn"),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary.copy(alpha = 0.12f))
                                    ) {
                                        Text(
                                            text = "✏️ प्रोफ़ाइल देखें एवं संपादित करें (View & Edit Profile)",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = OrangeDark
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Sync status & Sign Out Buttons
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.clickable(onClick = onSyncClick)
                                        ) {
                                            if (isSyncing) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(16.dp),
                                                    strokeWidth = 2.dp,
                                                    color = OrangePrimary
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Default.CloudDone,
                                                    contentDescription = "Synced",
                                                    tint = Color(0xFF2E7D32),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = if (isSyncing) "सिंक हो रहा है..." else "क्लाउड सिंक: सुरक्षित",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = if (isSyncing) OrangePrimary else Color(0xFF2E7D32)
                                            )
                                        }

                                        TextButton(
                                            onClick = { showSignOutDialog = true },
                                            modifier = Modifier.testTag("settings_signout_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Logout,
                                                contentDescription = "Sign Out",
                                                tint = CrimsonRed,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "साइन आउट",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = CrimsonRed
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 2. Cloud Sync Summary Dashboard
                    item {
                        Text(
                            text = "डेटा बैकअप एवं सिंक स्थिति (Cloud Sync Data)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sync_summary_card")
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "सिंक की गई मदें",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )

                                    OutlinedButton(
                                        onClick = onSyncClick,
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Refresh,
                                            contentDescription = "Sync",
                                            modifier = Modifier.size(14.dp),
                                            tint = OrangePrimary
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("सिंक करें", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OrangePrimary)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    SyncStatBadge(icon = Icons.Default.Bookmark, label = "पसंदीदा खबर", count = savedNewsCount, tint = OrangePrimary)
                                    SyncStatBadge(icon = Icons.Default.EditLocation, label = "पसंदीदा शहर", count = favoriteCitiesCount, tint = Color(0xFF1976D2))
                                    SyncStatBadge(icon = Icons.Default.VideoLibrary, label = "सेव्ड रील्स", count = savedReelsCount, tint = Color(0xFF8E24AA))
                                    SyncStatBadge(icon = Icons.Default.Palette, label = "बनाए पोस्टर्स", count = createdPostsHistory.size, tint = Color(0xFF2E7D32))
                                }
                            }
                        }
                    }

                    // 3. Premium VIP Benefits Card
                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (userAccount.isPremium) Color(0xFFFFF8E1) else MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(
                                1.5.dp,
                                if (userAccount.isPremium) Color(0xFFFFB300) else OrangePrimary.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("premium_card")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(Brush.linearGradient(listOf(Color(0xFFFFB300), Color(0xFFFF6F00)))),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.WorkspacePremium,
                                                contentDescription = "Premium",
                                                tint = Color.White,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "सिटी ख़बर प्रीमियम (VIP)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = Color(0xFFE65100)
                                            )
                                            Text(
                                                text = "विज्ञापन-मुक्त व एक्सक्लूसिव फीचर्स",
                                                fontSize = 11.sp,
                                                color = Color(0xFF6D4C41)
                                            )
                                        }
                                    }

                                    if (userAccount.isPremium) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFF2E7D32)
                                        ) {
                                            Text(
                                                text = "सक्रिय ✓",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = "• 100% विज्ञापन-मुक्त तेज़ अनुभव\n• अनलिमिटेड क्लाउड सिंक व रील्स बैकअप\n• एक्सक्लूसिव एचडी पोस्टर व रील टेम्पलेट्स",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 18.sp
                                )

                                if (!userAccount.isPremium) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(
                                        onClick = onActivatePremiumClick,
                                        modifier = Modifier.fillMaxWidth().height(42.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFFFF8F00),
                                            contentColor = Color.White
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("प्रीमियम अनलॉक करें (Unlock VIP)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }

                    // Section: Information & Support (सूचना एवं सहायता)
                    item {
                        Text(
                            text = "कानूनी एवं सहायता केंद्र (Information & Support)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(2.dp),
                            modifier = Modifier.fillMaxWidth().testTag("legal_support_card")
                        ) {
                            Column {
                                // 1. Privacy Policy (गोपनीयता नीति)
                                SettingsNavigationRow(
                                    icon = Icons.Default.Security,
                                    iconTint = OrangePrimary,
                                    title = "गोपनीयता नीति (Privacy Policy)",
                                    subtitle = "डेटा संकलन, News API व विज्ञापन नीतियां",
                                    testTag = "settings_privacy_policy_item",
                                    onClick = { activeSubScreen = SettingsSubScreen.PRIVACY_POLICY }
                                )

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                // 2. About Us (हमारे बारे में)
                                SettingsNavigationRow(
                                    icon = Icons.Default.Info,
                                    iconTint = Color(0xFF1976D2),
                                    title = "हमारे बारे में (About Us)",
                                    subtitle = "City Khabar • \"आपके शहर की हर खबर\"",
                                    testTag = "settings_about_us_item",
                                    onClick = { activeSubScreen = SettingsSubScreen.ABOUT_US }
                                )

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                // 3. Contact & Support (संपर्क एवं सहायता)
                                SettingsNavigationRow(
                                    icon = Icons.Default.HeadsetMic,
                                    iconTint = Color(0xFF2E7D32),
                                    title = "संपर्क एवं सहायता (Contact & Support)",
                                    subtitle = "सहायता ईमेल, फीडबैक फॉर्म व समस्या रिपोर्ट",
                                    testTag = "settings_contact_support_item",
                                    onClick = { activeSubScreen = SettingsSubScreen.CONTACT_SUPPORT }
                                )
                            }
                        }
                    }

                    // Section: Theme & Display (थीम और डिस्प्ले)
                    item {
                        Text(
                            text = "थीम और डिस्प्ले (Theme & Display)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth().testTag("theme_settings_card")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                ThemeMode.entries.forEachIndexed { index, mode ->
                                    val isSelected = mode == themeMode
                                    val modeBorderColor = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                    val modeBgColor = if (isSelected) {
                                        OrangePrimary.copy(alpha = 0.08f)
                                    } else {
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = modeBgColor,
                                        border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, modeBorderColor),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(14.dp))
                                            .clickable { onThemeModeChange(mode) }
                                            .padding(vertical = 4.dp)
                                            .testTag("theme_mode_${mode.id}")
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Surface(
                                                    shape = CircleShape,
                                                    color = when (mode) {
                                                        ThemeMode.LIGHT -> Color(0xFFFFF3E0)
                                                        ThemeMode.DARK -> Color(0xFF2C2422)
                                                        ThemeMode.SYSTEM -> OrangePrimary.copy(alpha = 0.15f)
                                                    },
                                                    modifier = Modifier.size(40.dp)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        when (mode) {
                                                            ThemeMode.LIGHT -> Icon(
                                                                imageVector = Icons.Filled.LightMode,
                                                                contentDescription = null,
                                                                tint = Color(0xFFF57C00),
                                                                modifier = Modifier.size(22.dp)
                                                            )
                                                            ThemeMode.DARK -> Icon(
                                                                imageVector = Icons.Filled.DarkMode,
                                                                contentDescription = null,
                                                                tint = OrangeLight,
                                                                modifier = Modifier.size(22.dp)
                                                            )
                                                            ThemeMode.SYSTEM -> Icon(
                                                                imageVector = Icons.Filled.BrightnessAuto,
                                                                contentDescription = null,
                                                                tint = OrangePrimary,
                                                                modifier = Modifier.size(22.dp)
                                                            )
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.width(12.dp))

                                                Column {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text(
                                                            text = mode.titleHindi,
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                                            fontSize = 14.sp,
                                                            color = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.onSurface
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text(
                                                            text = "(${mode.titleEnglish})",
                                                            fontSize = 11.sp,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.height(2.dp))
                                                    Text(
                                                        text = mode.descriptionHindi,
                                                        fontSize = 11.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.width(8.dp))

                                            Icon(
                                                imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                                                contentDescription = if (isSelected) "चयनित" else "चुनें",
                                                tint = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Section: Preferences (प्राथमिकताएं)
                    item {
                        Text(
                            text = "प्राथमिकताएं (Preferences)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                // Current City Selection
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(onClick = onChangeCityClick)
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.EditLocation,
                                            contentDescription = null,
                                            tint = OrangePrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text("चयनित मुख्य शहर", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                            Text(
                                                "${selectedCity.nameHindi} (${selectedCity.stateHindi})",
                                                fontSize = 12.sp,
                                                color = OrangePrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                                }

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                                // Bookmarks Count Info (Clickable)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { activeSubScreen = SettingsSubScreen.SAVED_NEWS }
                                        .padding(16.dp)
                                        .testTag("settings_saved_news_row"),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Bookmark,
                                            contentDescription = null,
                                            tint = OrangePrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text("सेव की गई खबरें", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                            Text("ऑफलाइन व बाद में पढ़ने हेतु • देखें व प्रबंधित करें", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("$savedNewsCount सेव्ड", fontWeight = FontWeight.Bold, color = OrangePrimary, fontSize = 13.sp)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                                    }
                                }
                            }
                        }
                    }

                    // Section: Offline & Storage Management (ऑफलाइन डेटा एवं स्टोरेज सेटिंग्स)
                    item {
                        Text(
                            text = "ऑफलाइन डेटा एवं स्टोरेज (Offline & Storage Management)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth().testTag("offline_storage_settings_card")
                        ) {
                            Column {
                                // 1. Offline Mode Simulation / Toggle
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CloudSync,
                                            contentDescription = null,
                                            tint = OrangePrimary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = "मैन्युअल ऑफलाइन मोड (Offline Mode)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            Text(
                                                text = "इंटरनेट बंद होने का अनुभव और कैश्ड खबरें पढ़ें",
                                                fontSize = 11.5.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Switch(
                                        checked = isManualOfflineMode,
                                        onCheckedChange = onToggleManualOfflineMode,
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = OrangePrimary,
                                            checkedTrackColor = OrangeLight.copy(alpha = 0.5f)
                                        ),
                                        modifier = Modifier.testTag("toggle_manual_offline_mode")
                                    )
                                }

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                // 2. Storage & Cache Statistics
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { activeSubScreen = SettingsSubScreen.SAVED_NEWS }
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CloudDone,
                                            contentDescription = null,
                                            tint = Color(0xFF2E7D32),
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = "ऑफलाइन सुरक्षित खबरें",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = "स्वचालित कैश्ड: $cachedArticlesCount • बुकमार्क: $savedNewsCount (कुल: $offlineArticlesCount)",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                                }

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                // 3. Clear Offline Buttons
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp)
                                ) {
                                    Text(
                                        text = "🗑️ ऑफलाइन डेटा प्रबंधन (Clear Offline Storage)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { showClearOfflineCacheDialog = true },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(36.dp)
                                                .testTag("clear_offline_cache_btn"),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 4.dp),
                                            border = BorderStroke(1.dp, OrangePrimary.copy(alpha = 0.5f))
                                        ) {
                                            Text("कैश साफ करें ($cachedArticlesCount)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OrangePrimary)
                                        }

                                        OutlinedButton(
                                            onClick = { showClearAllOfflineDialog = true },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(36.dp)
                                                .testTag("clear_all_offline_data_btn"),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 4.dp),
                                            border = BorderStroke(1.dp, CrimsonRed.copy(alpha = 0.5f))
                                        ) {
                                            Text("सभी डेटा हटाएं", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CrimsonRed)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Section: Notification System Settings (सूचनाएं एवं अलर्ट सेटिंग्स)
                    item {
                        Text(
                            text = "सूचनाएं एवं अलर्ट सेटिंग्स (Notification Settings)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                // 1. Master Toggle: Enable / Disable Notifications
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = if (notificationPreferences.notificationsEnabled) {
                                                Icons.Default.NotificationsActive
                                            } else {
                                                Icons.Default.NotificationsOff
                                            },
                                            contentDescription = null,
                                            tint = if (notificationPreferences.notificationsEnabled) OrangePrimary else Color.Gray,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = "नोटिफिकेशन्स (Enable/Disable)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            Text(
                                                text = if (notificationPreferences.notificationsEnabled) {
                                                    "सभी न्यूज़ अलर्ट्स और पुश नोटिफिकेशन चालू हैं"
                                                } else {
                                                    "सभी नोटिफिकेशन बंद हैं"
                                                },
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Switch(
                                        checked = notificationPreferences.notificationsEnabled,
                                        onCheckedChange = onToggleNotificationsEnabled,
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = OrangePrimary,
                                            checkedTrackColor = OrangeLight.copy(alpha = 0.5f)
                                        ),
                                        modifier = Modifier.testTag("toggle_notifications_master")
                                    )
                                }

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                // 2. Option: Breaking News (ब्रेकिंग न्यूज़)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ElectricBolt,
                                            contentDescription = null,
                                            tint = if (notificationPreferences.notificationsEnabled && notificationPreferences.breakingNewsEnabled) {
                                                CrimsonRed
                                            } else {
                                                Color.Gray
                                            },
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = "1. ब्रेकिंग न्यूज़ (Breaking News)",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp,
                                                color = if (notificationPreferences.notificationsEnabled) MaterialTheme.colorScheme.onSurface else Color.Gray
                                            )
                                            Text(
                                                text = "अति-महत्वपूर्ण व आपातकालीन राष्ट्रीय व क्षेत्रीय अलर्ट्स",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Switch(
                                        checked = notificationPreferences.breakingNewsEnabled,
                                        onCheckedChange = onToggleBreakingNews,
                                        enabled = notificationPreferences.notificationsEnabled,
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = CrimsonRed,
                                            checkedTrackColor = CrimsonRed.copy(alpha = 0.3f)
                                        ),
                                        modifier = Modifier.testTag("toggle_breaking_news")
                                    )
                                }

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                // 3. Option: Important News (महत्वपूर्ण समाचार)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = null,
                                            tint = if (notificationPreferences.notificationsEnabled && notificationPreferences.importantNewsEnabled) {
                                                Color(0xFFF57C00)
                                            } else {
                                                Color.Gray
                                            },
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = "2. महत्वपूर्ण समाचार (Important News)",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp,
                                                color = if (notificationPreferences.notificationsEnabled) MaterialTheme.colorScheme.onSurface else Color.Gray
                                            )
                                            Text(
                                                text = "राज्य व देश की शीर्ष सुर्खियां और विशेष रिपोर्ट",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Switch(
                                        checked = notificationPreferences.importantNewsEnabled,
                                        onCheckedChange = onToggleImportantNews,
                                        enabled = notificationPreferences.notificationsEnabled,
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color(0xFFF57C00),
                                            checkedTrackColor = Color(0xFFF57C00).copy(alpha = 0.3f)
                                        ),
                                        modifier = Modifier.testTag("toggle_important_news")
                                    )
                                }

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                // 4. Option: Selected City News (चयनित शहर की खबरें)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.LocationCity,
                                            contentDescription = null,
                                            tint = if (notificationPreferences.notificationsEnabled && notificationPreferences.cityNewsEnabled) {
                                                OrangePrimary
                                            } else {
                                                Color.Gray
                                            },
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = "3. चयनित शहर समाचार (${selectedCity.nameHindi})",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp,
                                                color = if (notificationPreferences.notificationsEnabled) MaterialTheme.colorScheme.onSurface else Color.Gray
                                            )
                                            Text(
                                                text = "${selectedCity.nameHindi} शहर के मुख्य घटनाक्रम और स्थानीय सूचनाएं",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Switch(
                                        checked = notificationPreferences.cityNewsEnabled,
                                        onCheckedChange = onToggleCityNews,
                                        enabled = notificationPreferences.notificationsEnabled,
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = OrangePrimary,
                                            checkedTrackColor = OrangeLight.copy(alpha = 0.5f)
                                        ),
                                        modifier = Modifier.testTag("toggle_city_news")
                                    )
                                }

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                // 5. Option: Daily News Updates (दैनिक समाचार अपडेट्स)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.WbSunny,
                                            contentDescription = null,
                                            tint = if (notificationPreferences.notificationsEnabled && notificationPreferences.dailyUpdatesEnabled) {
                                                Color(0xFF1976D2)
                                            } else {
                                                Color.Gray
                                            },
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = "4. दैनिक समाचार अपडेट्स (Daily News Updates)",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp,
                                                color = if (notificationPreferences.notificationsEnabled) MaterialTheme.colorScheme.onSurface else Color.Gray
                                            )
                                            Text(
                                                text = "सुबह-शाम का मुख्य समाचार बुलेटिन और ताज़ा सारांश",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Switch(
                                        checked = notificationPreferences.dailyUpdatesEnabled,
                                        onCheckedChange = onToggleDailyUpdates,
                                        enabled = notificationPreferences.notificationsEnabled,
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color(0xFF1976D2),
                                            checkedTrackColor = Color(0xFF1976D2).copy(alpha = 0.3f)
                                        ),
                                        modifier = Modifier.testTag("toggle_daily_updates")
                                    )
                                }

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                // 5. Direct Page Link: All Notifications Page
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(onClick = onOpenNotificationsPage)
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Notifications,
                                            contentDescription = null,
                                            tint = OrangePrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "सूचनाएं पेज खोलें (Notifications Page)",
                                                    fontWeight = FontWeight.SemiBold,
                                                    fontSize = 13.sp
                                                )
                                                if (unreadNotificationsCount > 0) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        color = CrimsonRed,
                                                        shape = RoundedCornerShape(10.dp)
                                                    ) {
                                                        Text(
                                                            text = "$unreadNotificationsCount नई",
                                                            color = Color.White,
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                            Text(
                                                text = "हाल ही में प्राप्त सभी अलर्ट्स व खबरें देखें",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                                }

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                // 6. Test Alert Buttons
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp)
                                ) {
                                    Text(
                                        text = "🔔 टेस्ट अलर्ट भेजें (Test Notification Alert)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { onSendTestNotification(NotificationType.BREAKING_NEWS) },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(34.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 2.dp),
                                            border = BorderStroke(1.dp, CrimsonRed.copy(alpha = 0.5f))
                                        ) {
                                            Text("🚨 ब्रेकिंग", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CrimsonRed)
                                        }

                                        OutlinedButton(
                                            onClick = { onSendTestNotification(NotificationType.CITY_IMPORTANT) },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(34.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 2.dp),
                                            border = BorderStroke(1.dp, OrangePrimary.copy(alpha = 0.5f))
                                        ) {
                                            Text("🏙️ शहर", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OrangePrimary)
                                        }

                                        OutlinedButton(
                                            onClick = { onSendTestNotification(NotificationType.DAILY_UPDATE) },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(34.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 2.dp),
                                            border = BorderStroke(1.dp, Color(0xFF1976D2).copy(alpha = 0.5f))
                                        ) {
                                            Text("📰 दैनिक", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1976D2))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Section: Created Posts History
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "बनाए गए पोस्टर्स का इतिहास (${createdPostsHistory.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    if (createdPostsHistory.isEmpty()) {
                        item {
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "अभी तक कोई पोस्टर नहीं बनाया गया है। 'पोस्ट बनाएं' टैब में जाकर अपनी पसंदीदा खबर का शानदार पोस्टर बनाएं!",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }
                        }
                    } else {
                        items(createdPostsHistory, key = { it.id }) { post ->
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(1.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (post.imageResId != 0) {
                                            Image(
                                                painter = painterResource(id = post.imageResId),
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier
                                                    .size(50.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                        }

                                        Column {
                                            Text(
                                                text = post.headline,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                maxLines = 1,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "📍 ${post.cityHindi} • टेम्पलेट: ${post.templateId}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Row {
                                        IconButton(
                                            onClick = {
                                                PostExportUtil.sharePost(
                                                    context,
                                                    com.example.model.PostCustomization(
                                                        headline = post.headline,
                                                        summary = post.summary,
                                                        cityHindi = post.cityHindi,
                                                        reporterName = post.reporterName,
                                                        imageResId = post.imageResId
                                                    )
                                                )
                                            }
                                        ) {
                                            Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = OrangePrimary)
                                        }

                                        IconButton(
                                            onClick = { onDeleteCreatedPost(post.id) }
                                        ) {
                                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SyncStatBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    count: Int,
    tint: Color
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = tint.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "$count",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = tint
            )
            Text(
                text = label,
                fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SettingsNavigationRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp)
            .testTag(testTag),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Surface(
                shape = CircleShape,
                color = iconTint.copy(alpha = 0.12f),
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(20.dp)
        )
    }
}
