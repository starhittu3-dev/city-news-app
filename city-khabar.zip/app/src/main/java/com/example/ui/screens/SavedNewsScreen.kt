package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkRemove
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NewsCategory
import com.example.model.NewsItem
import com.example.model.PostCustomization
import com.example.model.UserAccount
import com.example.ui.components.NewsCard
import com.example.ui.theme.BreakingNewsRed
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary
import com.example.util.PostExportUtil

/**
 * Dedicated Saved News Screen (सेव की गई खबरें).
 * Displays all bookmarked news stories with complete metadata:
 * title, summary, image, source, publication date, category, and city.
 * Fully supports local persistence via Room DB and cloud sync with Google Account.
 */
@Composable
fun SavedNewsScreen(
    savedNewsList: List<NewsItem>,
    cachedNewsList: List<NewsItem> = emptyList(),
    likedArticleIds: Set<String>,
    userAccount: UserAccount = UserAccount.GUEST_DEFAULT,
    isArticleBookmarked: (String) -> Boolean = { id -> savedNewsList.any { it.id == id } },
    onBackClick: () -> Unit,
    onArticleClick: (NewsItem) -> Unit,
    onBookmarkClick: (NewsItem) -> Unit,
    onLikeClick: (String) -> Unit,
    onCreatePostClick: (NewsItem) -> Unit,
    onClearAllSavedNews: () -> Unit = {},
    onClearCachedNews: () -> Unit = {},
    onClearAllOfflineData: () -> Unit = {},
    onSignInClick: () -> Unit = {},
    onExploreNewsClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTabIdx by remember { androidx.compose.runtime.mutableIntStateOf(0) } // 0: Bookmarks, 1: Cached, 2: All Offline
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf<NewsCategory?>(null) }
    var showClearAllConfirmDialog by remember { mutableStateOf(false) }

    // Combined unique offline articles
    val allOfflineArticles = remember(savedNewsList, cachedNewsList) {
        val list = mutableListOf<NewsItem>()
        val seen = mutableSetOf<String>()
        savedNewsList.forEach {
            if (seen.add(it.id)) list.add(it)
        }
        cachedNewsList.forEach {
            if (seen.add(it.id)) list.add(it)
        }
        list
    }

    val currentTabList = when (selectedTabIdx) {
        0 -> savedNewsList
        1 -> cachedNewsList
        else -> allOfflineArticles
    }

    // Filtered bookmarks / offline list
    val filteredList = remember(currentTabList, searchQuery, selectedCategoryFilter) {
        currentTabList.filter { item ->
            val matchesSearch = if (searchQuery.isBlank()) {
                true
            } else {
                item.title.contains(searchQuery, ignoreCase = true) ||
                        item.summary.contains(searchQuery, ignoreCase = true) ||
                        item.cityHindi.contains(searchQuery, ignoreCase = true) ||
                        item.source.contains(searchQuery, ignoreCase = true) ||
                        item.reporterName.contains(searchQuery, ignoreCase = true)
            }
            val matchesCategory = selectedCategoryFilter == null || item.category == selectedCategoryFilter
            matchesSearch && matchesCategory
        }
    }

    // Clear All Confirmation Dialog
    if (showClearAllConfirmDialog) {
        val clearTitle = when (selectedTabIdx) {
            0 -> "सभी सेव खबरें हटाएं?"
            1 -> "कैश्ड ऑफलाइन खबरें हटाएं?"
            else -> "सभी ऑफलाइन डेटा हटाएं?"
        }
        val clearMsg = when (selectedTabIdx) {
            0 -> "क्या आप अपनी सभी ${savedNewsList.size} सेव की गई खबरों को हटाना चाहते हैं?"
            1 -> "क्या आप हाल ही में खोली गई सभी ${cachedNewsList.size} कैश्ड खबरों को हटाना चाहते हैं?"
            else -> "क्या आप सभी ${allOfflineArticles.size} ऑफलाइन व सेव्ड खबरों का डेटा हटाना चाहते हैं?"
        }

        AlertDialog(
            onDismissRequest = { showClearAllConfirmDialog = false },
            icon = {
                Surface(
                    shape = CircleShape,
                    color = BreakingNewsRed.copy(alpha = 0.12f),
                    modifier = Modifier.size(52.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            tint = BreakingNewsRed,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            },
            title = {
                Text(
                    text = clearTitle,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = clearMsg,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showClearAllConfirmDialog = false
                        when (selectedTabIdx) {
                            0 -> {
                                onClearAllSavedNews()
                                Toast.makeText(context, "सभी सेव की गई खबरें हटा दी गईं", Toast.LENGTH_SHORT).show()
                            }
                            1 -> {
                                onClearCachedNews()
                                Toast.makeText(context, "कैश की गई खबरें हटा दी गईं", Toast.LENGTH_SHORT).show()
                            }
                            else -> {
                                onClearAllOfflineData()
                                Toast.makeText(context, "सभी ऑफलाइन डेटा हटा दिया गया", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BreakingNewsRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("confirm_clear_all_saved_btn")
                ) {
                    Text("सभी हटाएं", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearAllConfirmDialog = false }) {
                    Text("रद्द करें", color = MaterialTheme.colorScheme.onSurface)
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("saved_news_screen")
    ) {
        // Top App Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("saved_news_back_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "पीछे जाएं",
                                tint = OrangePrimary
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(listOf(OrangePrimary, Color(0xFFD84315)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Bookmark,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = when (selectedTabIdx) {
                                        0 -> "सेव की गई खबरें"
                                        1 -> "कैश्ड ऑफलाइन खबरें"
                                        else -> "सभी ऑफलाइन खबरें"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = OrangePrimary.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "${currentTabList.size}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = OrangePrimary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "ऑफलाइन व बाद में पढ़ने हेतु सुरक्षित",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Clear All Action Button (if not empty)
                    if (currentTabList.isNotEmpty()) {
                        IconButton(
                            onClick = { showClearAllConfirmDialog = true },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("clear_all_saved_news_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteOutline,
                                contentDescription = "सभी हटाएं",
                                tint = BreakingNewsRed,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Section Tabs: Bookmarks vs Cached vs All Offline
                Spacer(modifier = Modifier.height(6.dp))
                androidx.compose.material3.TabRow(
                    selectedTabIndex = selectedTabIdx,
                    containerColor = Color.Transparent,
                    contentColor = OrangePrimary,
                    indicator = { tabPositions ->
                        androidx.compose.material3.TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIdx]),
                            color = OrangePrimary
                        )
                    }
                ) {
                    androidx.compose.material3.Tab(
                        selected = selectedTabIdx == 0,
                        onClick = { selectedTabIdx = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Filled.Bookmark, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("सेव्ड (${savedNewsList.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    )
                    androidx.compose.material3.Tab(
                        selected = selectedTabIdx == 1,
                        onClick = { selectedTabIdx = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.CloudDone, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("कैश (${cachedNewsList.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    )
                    androidx.compose.material3.Tab(
                        selected = selectedTabIdx == 2,
                        onClick = { selectedTabIdx = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Storage, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("सभी (${allOfflineArticles.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    )
                }

                // Search Bar within Bookmarks / Offline
                if (currentTabList.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("सेव की गई खबरों में खोजें...", fontSize = 13.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "खोजें",
                                tint = OrangePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "साफ करें",
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OrangePrimary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("saved_news_search_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Category Filter Pills for Bookmarks / Offline
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 2.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = selectedCategoryFilter == null,
                                onClick = { selectedCategoryFilter = null },
                                label = { Text("सभी (${currentTabList.size})", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = OrangePrimary,
                                    selectedLabelColor = Color.White
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }

                        val availableCategories = NewsCategory.entries
                            .filter { it != NewsCategory.ALL }
                            .filter { cat -> currentTabList.any { it.category == cat } }

                        items(availableCategories) { category ->
                            val isSelected = selectedCategoryFilter == category
                            val count = currentTabList.count { it.category == category }
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedCategoryFilter = if (isSelected) null else category
                                },
                                label = {
                                    Text(
                                        text = "${category.titleHindi} ($count)",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = OrangePrimary,
                                    selectedLabelColor = Color.White
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }
            }
        }

        // Account / Guest Sync Status Card
        Surface(
            color = if (userAccount.isGuest) Color(0xFFFFF3E0) else Color(0xFFE8F5E9),
            border = BorderStroke(1.dp, if (userAccount.isGuest) Color(0xFFFFE0B2) else Color(0xFFC8E6C9)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (userAccount.isGuest) Icons.Default.Storage else Icons.Default.CloudDone,
                        contentDescription = null,
                        tint = if (userAccount.isGuest) Color(0xFFE65100) else Color(0xFF2E7D32),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (userAccount.isGuest) "💾 स्थानीय मेमोरी (Offline Ready)" else "☁️ गूगल अकाउंट व ऑफलाइन सिंक",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (userAccount.isGuest) Color(0xFFBF360C) else Color(0xFF1B5E20)
                        )
                        Text(
                            text = if (userAccount.isGuest) {
                                "इंटरनेट न होने पर भी खबरें पढ़ सकते हैं"
                            } else {
                                "${userAccount.email} • सुरक्षित बैकअप"
                            },
                            fontSize = 10.5.sp,
                            color = if (userAccount.isGuest) Color(0xFFE65100) else Color(0xFF2E7D32)
                        )
                    }
                }

                if (userAccount.isGuest) {
                    TextButton(
                        onClick = onSignInClick,
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(
                            text = "सिंक करें",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = OrangePrimary
                        )
                    }
                }
            }
        }

        // Main Content: Empty State vs News List
        if (currentTabList.isEmpty()) {
            // EMPTY STATE
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.testTag("saved_news_empty_state")
                ) {
                    Surface(
                        shape = CircleShape,
                        color = OrangePrimary.copy(alpha = 0.1f),
                        modifier = Modifier.size(84.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = when (selectedTabIdx) {
                                    0 -> Icons.Outlined.BookmarkBorder
                                    1 -> Icons.Default.CloudDone
                                    else -> Icons.Default.Storage
                                },
                                contentDescription = null,
                                tint = OrangePrimary,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = when (selectedTabIdx) {
                            0 -> "कोई सेव की गई खबर नहीं है।"
                            1 -> "कोई कैश्ड ऑफलाइन खबर नहीं है।"
                            else -> "कोई ऑफलाइन खबर उपलब्ध नहीं है।"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = when (selectedTabIdx) {
                            0 -> "अपनी पसंदीदा खबरों को बाद में पढ़ने के लिए बुकमार्क करें। वे यहां ऑफलाइन भी उपलब्ध रहेंगी।"
                            1 -> "आप जो भी खबरें ऐप में पढ़ते हैं, वे अपने आप ऑफलाइन पढ़ने के लिए यहां सुरक्षित हो जाती हैं।"
                            else -> "खबरें पढ़ें या सेव करें, इंटरनेट न होने पर भी वे यहां उपलब्ध रहेंगी।"
                        },
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    Spacer(modifier = Modifier.height(22.dp))

                    Button(
                        onClick = onExploreNewsClick,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                        modifier = Modifier.testTag("explore_news_from_empty_saved_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Newspaper,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ताज़ा खबरें देखें (Browse News)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        } else if (filteredList.isEmpty()) {
            // Search or Filter produced no results
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "कोई खबर नहीं मिली",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) {
                            "\"$searchQuery\" से संबंधित कोई खबर नहीं है।"
                        } else {
                            "चुने गए फिल्टर के अनुसार कोई खबर नहीं है।"
                        },
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedButton(
                        onClick = {
                            searchQuery = ""
                            selectedCategoryFilter = null
                        }
                    ) {
                        Text("फिल्टर हटाएं (Reset)")
                    }
                }
            }
        } else {
            // Saved & Offline News List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 80.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(filteredList, key = { it.id }) { news ->
                    val isBookmarked = isArticleBookmarked(news.id)
                    NewsCard(
                        news = news,
                        isLiked = likedArticleIds.contains(news.id),
                        isBookmarked = isBookmarked,
                        isOfflineAvailable = true,
                        onCardClick = { onArticleClick(news) },
                        onLikeClick = { onLikeClick(news.id) },
                        onBookmarkClick = {
                            onBookmarkClick(news)
                            val msg = if (isBookmarked) "बुकमार्क से हटा दिया गया" else "खबर बुकमार्क कर ली गई"
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        },
                        onShareClick = {
                            PostExportUtil.sharePost(
                                context,
                                PostCustomization(
                                    headline = news.title,
                                    summary = news.summary,
                                    cityHindi = news.cityHindi,
                                    reporterName = news.reporterName,
                                    imageResId = news.imageResId
                                )
                            )
                        },
                        onCreatePostClick = { onCreatePostClick(news) }
                    )
                }
            }
        }
    }
}
