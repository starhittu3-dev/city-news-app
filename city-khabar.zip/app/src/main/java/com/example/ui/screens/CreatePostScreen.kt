package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.NewsItem
import com.example.model.PostColorTheme
import com.example.model.PostCustomization
import com.example.model.PostTemplateType
import com.example.model.ReelColorTheme
import com.example.model.ReelCustomization
import com.example.model.ReelTemplateType
import com.example.ui.components.PostTemplateRenderer
import com.example.ui.components.ReelTemplateRenderer
import com.example.ui.theme.BreakingNewsRed
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary
import com.example.viewmodel.CreationStudioMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePostScreen(
    creationMode: CreationStudioMode,
    onModeChange: (CreationStudioMode) -> Unit,
    // Live News items for selection
    liveNewsList: List<NewsItem>,
    onSelectLiveArticle: (NewsItem) -> Unit,
    // Reel Props
    reelCustomization: ReelCustomization,
    onReelTemplateSelect: (ReelTemplateType) -> Unit,
    onReelThemeSelect: (ReelColorTheme) -> Unit,
    onReelHeadlineChange: (String) -> Unit,
    onReelSummaryChange: (String) -> Unit,
    onReelCityChange: (String) -> Unit,
    onReelCategoryChange: (String) -> Unit,
    onReelReporterChange: (String) -> Unit,
    onReelImageSelect: (Int) -> Unit,
    onToggleReelCity: (Boolean) -> Unit,
    onToggleReelCategory: (Boolean) -> Unit,
    onToggleReelReporter: (Boolean) -> Unit,
    onToggleReelWatermark: (Boolean) -> Unit,
    onOpenReelPreview: () -> Unit,
    onDownloadReelClick: () -> Unit,
    onShareReelClick: () -> Unit,
    isReelGenerating: Boolean = false,
    reelGenerationProgress: Float = 0f,
    onGenerateAndPlayReelClick: (() -> Unit)? = null,
    // Post Props
    postCustomization: PostCustomization,
    onPostCustomizationChange: (PostCustomization) -> Unit,
    onPostTemplateSelect: (PostTemplateType) -> Unit,
    onPostColorThemeSelect: (PostColorTheme) -> Unit,
    onPostHeadlineChange: (String) -> Unit,
    onPostSummaryChange: (String) -> Unit,
    onPostCityChange: (String) -> Unit,
    onPostReporterChange: (String) -> Unit,
    onPostImageSelect: (Int) -> Unit,
    onTogglePostReporter: (Boolean) -> Unit,
    onTogglePostCity: (Boolean) -> Unit,
    onTogglePostWatermark: (Boolean) -> Unit,
    onTogglePostBreaking: (Boolean) -> Unit,
    onDownloadPostClick: () -> Unit,
    onSharePostClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var showArticlePickerSheet by remember { mutableStateOf(false) }

    val availableImages = listOf(
        R.drawable.img_delhi_news to "दिल्ली मेट्रो",
        R.drawable.img_mumbai_news to "मुंबई सी लिंक",
        R.drawable.img_sports_news to "क्रिकेट स्टेडियम",
        R.drawable.img_business_news to "व्यापार व टेक",
        R.drawable.img_weather_news to "मानसून मौसम",
        R.drawable.img_entertainment_news to "मनोरंजन शो",
        R.drawable.img_jaipur_news to "जयपुर हवा महल"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Studio Header
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 3.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = OrangePrimary.copy(alpha = 0.15f)
                        ) {
                            Icon(
                                imageVector = if (creationMode == CreationStudioMode.REEL_9_16) Icons.Default.Videocam else Icons.Outlined.AutoAwesome,
                                contentDescription = null,
                                tint = OrangePrimary,
                                modifier = Modifier
                                    .padding(8.dp)
                                    .size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (creationMode == CreationStudioMode.REEL_9_16) "9:16 रील स्टूडियो" else "न्यूज़ पोस्टर क्रिएटर",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = OrangePrimary
                            )
                            Text(
                                text = if (creationMode == CreationStudioMode.REEL_9_16) "सोशल मीडिया रील्स व शॉर्ट्स बनाएं" else "आकर्षक न्यूज़ ग्राफिक पोस्टर बनाएं",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Live News Switcher Button
                    Button(
                        onClick = { showArticlePickerSheet = true },
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurface
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("change_live_article_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = OrangePrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "लाइव खबर बदलें",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Mode Tabs (9:16 Reel vs 4:5 Poster)
                TabRow(
                    selectedTabIndex = if (creationMode == CreationStudioMode.REEL_9_16) 0 else 1,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = OrangePrimary,
                    indicator = { tabPositions ->
                        val index = if (creationMode == CreationStudioMode.REEL_9_16) 0 else 1
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[index]),
                            color = OrangePrimary,
                            height = 3.dp
                        )
                    }
                ) {
                    Tab(
                        selected = creationMode == CreationStudioMode.REEL_9_16,
                        onClick = { onModeChange(CreationStudioMode.REEL_9_16) },
                        modifier = Modifier.testTag("tab_reel_mode")
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.VideoLibrary,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "🎬 9:16 वर्टिकल रील",
                                fontWeight = if (creationMode == CreationStudioMode.REEL_9_16) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Tab(
                        selected = creationMode == CreationStudioMode.POST_4_5,
                        onClick = { onModeChange(CreationStudioMode.POST_4_5) },
                        modifier = Modifier.testTag("tab_post_mode")
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Layers,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "🎨 सोशल मीडिया पोस्टर",
                                fontWeight = if (creationMode == CreationStudioMode.POST_4_5) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // Main Studio Scrollable Body
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. Live Article Source Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF6F3)),
                border = BorderStroke(1.dp, Color(0xFFFFD5C7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Thumbnail
                    val currentImg = if (creationMode == CreationStudioMode.REEL_9_16) reelCustomization.imageResId else postCustomization.imageResId
                    if (currentImg != 0) {
                        Image(
                            painter = painterResource(id = currentImg),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(52.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = BreakingNewsRed
                            ) {
                                Text(
                                    text = "🔴 चयनित लाइव खबर",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (creationMode == CreationStudioMode.REEL_9_16) reelCustomization.cityHindi else postCustomization.cityHindi,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = OrangePrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (creationMode == CreationStudioMode.REEL_9_16) reelCustomization.headline else postCustomization.headline,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    IconButton(
                        onClick = { showArticlePickerSheet = true },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = "Change Article",
                            tint = OrangePrimary
                        )
                    }
                }
            }

            // 2. LIVE CANVAS PREVIEW
            if (creationMode == CreationStudioMode.REEL_9_16) {
                // 9:16 Reel Preview Box
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "9:16 रील कैनवास प्रीव्यू",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = OrangePrimary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "1080 x 1920 HD रील",
                                color = OrangePrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // 9:16 Interactive Live Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(440.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        ReelTemplateRenderer(
                            reel = reelCustomization,
                            isPlaying = true,
                            modifier = Modifier.fillMaxHeight()
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Generate & Play Video Reel Primary Button
                    Button(
                        onClick = { onGenerateAndPlayReelClick?.invoke() },
                        enabled = !isReelGenerating,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("generate_and_play_reel_btn")
                    ) {
                        if (isReelGenerating) {
                            androidx.compose.material3.CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "वीडियो रील तैयार हो रही है... ${(reelGenerationProgress * 100).toInt()}%",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "🎬 रील वीडियो जनरेट करें व चलाएं",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Fullscreen Preview & Instant Export Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Fullscreen Preview Button
                        OutlinedButton(
                            onClick = onOpenReelPreview,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.5.dp, OrangePrimary),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("open_reel_fullscreen_preview_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Visibility,
                                contentDescription = null,
                                tint = OrangePrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "पूर्ण स्क्रीन प्रीव्यू",
                                color = OrangePrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Download Reel Button
                        Button(
                            onClick = onDownloadReelClick,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("download_reel_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "रील डाउनलोड",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Share Reel Button
                        Button(
                            onClick = onShareReelClick,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("share_reel_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "शेयर करें",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            } else {
                // 4:5 Poster Preview Box
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "पोस्टर कैनवास प्रीव्यू",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = OrangePrimary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "1080 x 1350 HD पोस्टर",
                                color = OrangePrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Poster Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(380.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        PostTemplateRenderer(
                            post = postCustomization,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onDownloadPostClick,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("download_post_btn")
                        ) {
                            Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("डाउनलोड करें", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onSharePostClick,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("share_post_btn")
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("शेयर करें", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 3. TEMPLATES SELECTION
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FormatPaint,
                        contentDescription = null,
                        tint = OrangePrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (creationMode == CreationStudioMode.REEL_9_16) "1. रील टेम्पलेट चुनें (5 स्टाइल्स)" else "1. पोस्टर लेआउट टेम्पलेट चुनें",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (creationMode == CreationStudioMode.REEL_9_16) {
                    // Reel Templates Row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        items(ReelTemplateType.values()) { template ->
                            val isSelected = reelCustomization.templateType == template
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.surface
                                ),
                                border = BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                ),
                                modifier = Modifier
                                    .clickable { onReelTemplateSelect(template) }
                                    .testTag("reel_template_${template.id}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = template.nameHindi,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = template.subtitleHindi,
                                        fontSize = 10.sp,
                                        color = if (isSelected) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // Post Templates Row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        items(PostTemplateType.values()) { template ->
                            val isSelected = postCustomization.templateType == template
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.surface
                                ),
                                border = BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                ),
                                modifier = Modifier
                                    .clickable { onPostTemplateSelect(template) }
                                    .testTag("post_template_${template.id}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = template.nameHindi,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = template.descriptionHindi,
                                        fontSize = 10.sp,
                                        color = if (isSelected) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 4. COLOR THEME SELECTION
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Palette,
                        contentDescription = null,
                        tint = OrangePrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "2. कलर थीम व ग्रेडिएंट",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (creationMode == CreationStudioMode.REEL_9_16) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        items(ReelColorTheme.values()) { theme ->
                            val isSelected = reelCustomization.colorTheme == theme
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) theme.primaryColor else Color.Transparent
                                ),
                                shadowElevation = if (isSelected) 3.dp else 1.dp,
                                modifier = Modifier
                                    .clickable { onReelThemeSelect(theme) }
                                    .testTag("reel_theme_${theme.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .background(
                                                Brush.linearGradient(
                                                    colors = listOf(theme.primaryColor, theme.accentColor)
                                                )
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = theme.nameHindi,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    if (isSelected) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = theme.primaryColor,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        items(PostColorTheme.values()) { theme ->
                            val isSelected = postCustomization.colorTheme == theme
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) theme.primaryColor else Color.Transparent
                                ),
                                shadowElevation = if (isSelected) 3.dp else 1.dp,
                                modifier = Modifier
                                    .clickable { onPostColorThemeSelect(theme) }
                                    .testTag("post_theme_${theme.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .background(
                                                Brush.linearGradient(
                                                    colors = listOf(theme.primaryColor, theme.secondaryColor)
                                                )
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = theme.nameHindi,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 5. IMAGE / VISUAL BACKGROUND SELECTION
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = null,
                        tint = OrangePrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "3. बैकग्राउंड फोटो / विजुअल",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                val currentSelectedImage = if (creationMode == CreationStudioMode.REEL_9_16) reelCustomization.imageResId else postCustomization.imageResId

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp)
                ) {
                    items(availableImages) { (resId, label) ->
                        val isSelected = currentSelectedImage == resId
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(
                                width = if (isSelected) 3.dp else 1.dp,
                                color = if (isSelected) OrangePrimary else Color.Transparent
                            ),
                            modifier = Modifier
                                .size(width = 80.dp, height = 75.dp)
                                .clickable {
                                    if (creationMode == CreationStudioMode.REEL_9_16) {
                                        onReelImageSelect(resId)
                                    } else {
                                        onPostImageSelect(resId)
                                    }
                                }
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                Image(
                                    painter = painterResource(id = resId),
                                    contentDescription = label,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(OrangePrimary.copy(alpha = 0.45f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = Color.White,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 6. EDIT HEADLINE & SUMMARY (Requirement: "Allow user to edit headline and summary before creating the reel")
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.TextFields,
                        contentDescription = null,
                        tint = OrangePrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "4. शीर्षक व विवरण एडिट करें (Edit Headline & Summary)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (creationMode == CreationStudioMode.REEL_9_16) {
                    // Reel Headline
                    OutlinedTextField(
                        value = reelCustomization.headline,
                        onValueChange = onReelHeadlineChange,
                        label = { Text("मुख्य रील शीर्षक (Headline)") },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = OrangePrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reel_headline_input")
                    )

                    // Reel Summary
                    OutlinedTextField(
                        value = reelCustomization.summary,
                        onValueChange = onReelSummaryChange,
                        label = { Text("रील संक्षिप्त विवरण (Summary / Bullet Details)") },
                        shape = RoundedCornerShape(14.dp),
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = OrangePrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reel_summary_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = reelCustomization.cityHindi,
                            onValueChange = onReelCityChange,
                            label = { Text("शहर (City)") },
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = OrangePrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("reel_city_input")
                        )

                        OutlinedTextField(
                            value = reelCustomization.categoryHindi,
                            onValueChange = onReelCategoryChange,
                            label = { Text("कैटेगरी (Category)") },
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = OrangePrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("reel_category_input")
                        )
                    }

                    OutlinedTextField(
                        value = reelCustomization.reporterName,
                        onValueChange = onReelReporterChange,
                        label = { Text("रिपोर्टर/ब्यूरो नाम (Reporter)") },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = OrangePrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reel_reporter_input")
                    )
                } else {
                    // Post Headline
                    OutlinedTextField(
                        value = postCustomization.headline,
                        onValueChange = onPostHeadlineChange,
                        label = { Text("मुख्य पोस्टर शीर्षक (Headline)") },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = OrangePrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("post_headline_input")
                    )

                    // Post Summary
                    OutlinedTextField(
                        value = postCustomization.summary,
                        onValueChange = onPostSummaryChange,
                        label = { Text("संक्षिप्त विवरण (Summary)") },
                        shape = RoundedCornerShape(14.dp),
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = OrangePrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("post_summary_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = postCustomization.cityHindi,
                            onValueChange = onPostCityChange,
                            label = { Text("शहर (City)") },
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = OrangePrimary),
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = postCustomization.reporterName,
                            onValueChange = onPostReporterChange,
                            label = { Text("रिपोर्टर नाम") },
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = OrangePrimary),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // 7. BRANDING & ELEMENT TOGGLES
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "5. ब्रांडिंग व बैज नियंत्रण (City Khabar Branding & Badges)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    if (creationMode == CreationStudioMode.REEL_9_16) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("📍 शहर बैज दिखाएं", fontSize = 13.sp)
                            Switch(
                                checked = reelCustomization.showCityBadge,
                                onCheckedChange = onToggleReelCity,
                                colors = SwitchDefaults.colors(checkedThumbColor = OrangePrimary, checkedTrackColor = OrangeLight.copy(alpha = 0.5f))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("📂 कैटेगरी बैज दिखाएं", fontSize = 13.sp)
                            Switch(
                                checked = reelCustomization.showCategoryBadge,
                                onCheckedChange = onToggleReelCategory,
                                colors = SwitchDefaults.colors(checkedThumbColor = OrangePrimary, checkedTrackColor = OrangeLight.copy(alpha = 0.5f))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("✍️ रिपोर्टर नाम दिखाएं", fontSize = 13.sp)
                            Switch(
                                checked = reelCustomization.showReporter,
                                onCheckedChange = onToggleReelReporter,
                                colors = SwitchDefaults.colors(checkedThumbColor = OrangePrimary, checkedTrackColor = OrangeLight.copy(alpha = 0.5f))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🏷️ सिटी खबर वॉटरमार्क दिखाएं", fontSize = 13.sp)
                            Switch(
                                checked = reelCustomization.showWatermark,
                                onCheckedChange = onToggleReelWatermark,
                                colors = SwitchDefaults.colors(checkedThumbColor = OrangePrimary, checkedTrackColor = OrangeLight.copy(alpha = 0.5f))
                            )
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🔴 ब्रेकिंग न्यूज़ टैग दिखाएं", fontSize = 13.sp)
                            Switch(
                                checked = postCustomization.showBreakingTag,
                                onCheckedChange = onTogglePostBreaking,
                                colors = SwitchDefaults.colors(checkedThumbColor = OrangePrimary, checkedTrackColor = OrangeLight.copy(alpha = 0.5f))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("📍 शहर बैज दिखाएं", fontSize = 13.sp)
                            Switch(
                                checked = postCustomization.showCityBadge,
                                onCheckedChange = onTogglePostCity,
                                colors = SwitchDefaults.colors(checkedThumbColor = OrangePrimary, checkedTrackColor = OrangeLight.copy(alpha = 0.5f))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("✍️ रिपोर्टर हस्ताक्षर दिखाएं", fontSize = 13.sp)
                            Switch(
                                checked = postCustomization.showReporter,
                                onCheckedChange = onTogglePostReporter,
                                colors = SwitchDefaults.colors(checkedThumbColor = OrangePrimary, checkedTrackColor = OrangeLight.copy(alpha = 0.5f))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🏷️ सिटी खबर वॉटरमार्क दिखाएं", fontSize = 13.sp)
                            Switch(
                                checked = postCustomization.showWatermark,
                                onCheckedChange = onTogglePostWatermark,
                                colors = SwitchDefaults.colors(checkedThumbColor = OrangePrimary, checkedTrackColor = OrangeLight.copy(alpha = 0.5f))
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Modal Sheet for choosing live news article
    if (showArticlePickerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showArticlePickerSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "लाइव खबर चुनें (Select Live News)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${liveNewsList.size} खबरें उपलब्ध",
                        fontSize = 12.sp,
                        color = OrangePrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(liveNewsList) { article ->
                        val isSelected = article.id == reelCustomization.selectedArticleId
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) OrangePrimary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            ),
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 0.5.dp,
                                color = if (isSelected) OrangePrimary else Color.Transparent
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectLiveArticle(article)
                                    showArticlePickerSheet = false
                                }
                                .testTag("article_picker_item_${article.id}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (article.imageResId != 0) {
                                    Image(
                                        painter = painterResource(id = article.imageResId),
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(50.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = OrangePrimary
                                        ) {
                                            Text(
                                                text = article.cityHindi,
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = article.category.titleHindi,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = article.title,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = OrangePrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
