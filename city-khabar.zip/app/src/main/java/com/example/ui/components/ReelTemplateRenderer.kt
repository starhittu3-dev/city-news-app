package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ReelCustomization
import com.example.model.ReelTemplateType
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary

@Composable
fun ReelTemplateRenderer(
    reel: ReelCustomization,
    modifier: Modifier = Modifier,
    isPlaying: Boolean = true
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(9f / 16f)
            .clip(RoundedCornerShape(20.dp))
            .border(2.dp, reel.colorTheme.primaryColor.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
            .testTag("reel_template_canvas"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = reel.colorTheme.backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            when (reel.templateType) {
                ReelTemplateType.CINEMATIC_OVERLAY -> CinematicReelView(reel)
                ReelTemplateType.STUDIO_BULLETIN -> StudioBulletinReelView(reel)
                ReelTemplateType.MAGAZINE_HIGHLIGHT -> MagazineHighlightReelView(reel)
                ReelTemplateType.MIDNIGHT_NEON -> MidnightNeonReelView(reel)
                ReelTemplateType.BREAKING_FLASH -> BreakingFlashReelView(reel)
            }

            // Optional Top Reel Status Progress Bar (Simulating Story/Reel playback)
            if (isPlaying) {
                ReelPlaybackProgressBar(
                    color = reel.colorTheme.primaryColor,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun ReelPlaybackProgressBar(
    color: Color,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "reel_progress")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "reel_anim"
    )

    LinearProgressIndicator(
        progress = { progress },
        modifier = modifier
            .fillMaxWidth()
            .height(3.dp)
            .clip(RoundedCornerShape(2.dp)),
        color = Color.White,
        trackColor = Color.White.copy(alpha = 0.3f)
    )
}

@Composable
private fun BreakingFlashReelView(reel: ReelCustomization) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(reel.colorTheme.backgroundColor)
    ) {
        // Top Header
        ReelHeaderBar(reel)

        Spacer(modifier = Modifier.height(6.dp))

        // Center Big Photo with Breaking Badge
        Box(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
                .clip(RoundedCornerShape(14.dp))
                .border(2.dp, reel.colorTheme.primaryColor, RoundedCornerShape(14.dp))
        ) {
            if (reel.imageResId != 0) {
                Image(
                    painter = painterResource(id = reel.imageResId),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF1E0D06)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("📷 न्यूज़ फोटो", color = Color.White.copy(alpha = 0.6f))
                }
            }

            // Overlay Breaking Pulse Banner
            Surface(
                shape = RoundedCornerShape(topStart = 8.dp, bottomEnd = 8.dp),
                color = CrimsonRed,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Campaign,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "🔴 ब्रेकिंग न्यूज़ रील • ${reel.categoryHindi}",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Lower Content Card
        Card(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = reel.colorTheme.cardBackground),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, reel.colorTheme.primaryColor.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                // Badges
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (reel.showCategoryBadge) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = reel.colorTheme.primaryColor
                        ) {
                            Text(
                                text = reel.categoryHindi,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (reel.showCityBadge && reel.cityHindi.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.White.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "📍 ${reel.cityHindi}",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Headline
                Text(
                    text = reel.headline.ifBlank { "यहाँ खबर का मुख्य शीर्षक आएगा..." },
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    lineHeight = 20.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )

                if (reel.summary.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = reel.summary,
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Audio Wave Visual Simulation
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = reel.colorTheme.accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "ऑडियो रिपोर्ट लाइव",
                            color = reel.colorTheme.accentColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Text(
                        text = "📱 9:16 HD",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Footer Bar
        ReelFooterBar(reel)
    }
}

@Composable
private fun CinematicReelView(reel: ReelCustomization) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Fullscreen background photo
        if (reel.imageResId != 0) {
            Image(
                painter = painterResource(id = reel.imageResId),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Heavy Cinematic Vertical Vignette / Gradient
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.8f),
                            Color.Black.copy(alpha = 0.25f),
                            Color.Black.copy(alpha = 0.85f),
                            Color.Black.copy(alpha = 0.98f)
                        ),
                        startY = 0f
                    )
                )
        )

        // Top Branding
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
        ) {
            ReelHeaderBar(reel)
        }

        // Bottom Frosted Dark Glass Content
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 8.dp)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xDD121620)),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, reel.colorTheme.primaryColor.copy(alpha = 0.7f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = reel.colorTheme.primaryColor
                        ) {
                            Text(
                                text = "🎬 ${reel.categoryHindi}",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        if (reel.cityHindi.isNotBlank()) {
                            Text(
                                text = "📍 ${reel.cityHindi}",
                                color = reel.colorTheme.accentColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = reel.headline.ifBlank { "यहाँ खबर का मुख्य शीर्षक आएगा..." },
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        lineHeight = 21.sp,
                        maxLines = 3
                    )

                    if (reel.summary.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = reel.summary,
                            color = Color(0xFFECEFF1),
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            maxLines = 3
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            ReelFooterBar(reel)
        }
    }
}

@Composable
private fun StudioBulletinReelView(reel: ReelCustomization) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F141C))
    ) {
        ReelHeaderBar(reel)

        Spacer(modifier = Modifier.height(4.dp))

        // Center Broadcast Image
        Box(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(2.dp, Color(0xFFFDD835), RoundedCornerShape(12.dp))
        ) {
            if (reel.imageResId != 0) {
                Image(
                    painter = painterResource(id = reel.imageResId),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Top Live badge
            Surface(
                shape = RoundedCornerShape(bottomEnd = 8.dp),
                color = Color.Red,
                modifier = Modifier.align(Alignment.TopStart)
            ) {
                Text(
                    text = "🔴 LIVE BULLETIN",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Yellow Broadcast Lower-Third
        Card(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDE7))
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Yellow Bar
                Surface(
                    color = Color(0xFFFDD835),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⚡ शहर की बड़ी खबर: ${reel.cityHindi}",
                            color = Color(0xFF1B1B1B),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Text(
                            text = reel.categoryHindi,
                            color = Color(0xFFB71C1C),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp)
                ) {
                    Text(
                        text = reel.headline.ifBlank { "यहाँ खबर का मुख्य शीर्षक आएगा..." },
                        color = Color(0xFF1A1A1A),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        lineHeight = 19.sp,
                        maxLines = 3
                    )

                    if (reel.summary.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = reel.summary,
                            color = Color(0xFF424242),
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            maxLines = 3
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        ReelFooterBar(reel)
    }
}

@Composable
private fun MagazineHighlightReelView(reel: ReelCustomization) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFFDF9))
            .border(4.dp, reel.colorTheme.primaryColor)
    ) {
        // Top Header
        ReelHeaderBar(reel, onLight = false)

        Spacer(modifier = Modifier.height(4.dp))

        // Center Hero Photo
        Box(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
                .clip(RoundedCornerShape(10.dp))
        ) {
            if (reel.imageResId != 0) {
                Image(
                    painter = painterResource(id = reel.imageResId),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Magazine Editorial Body
        Column(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = reel.colorTheme.primaryColor
                ) {
                    Text(
                        text = "📖 ${reel.categoryHindi}",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Text(
                    text = "📍 ${reel.cityHindi}",
                    color = reel.colorTheme.primaryColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = reel.headline.ifBlank { "यहाँ खबर का मुख्य शीर्षक आएगा..." },
                color = Color(0xFF1B1B1B),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                lineHeight = 19.sp,
                maxLines = 3
            )

            Spacer(modifier = Modifier.height(4.dp))
            Divider(color = reel.colorTheme.primaryColor.copy(alpha = 0.4f), thickness = 1.5.dp)
            Spacer(modifier = Modifier.height(4.dp))

            if (reel.summary.isNotBlank()) {
                Text(
                    text = reel.summary,
                    color = Color(0xFF4A4A4A),
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    maxLines = 3
                )
            }
        }

        ReelFooterBar(reel, onLight = false)
    }
}

@Composable
private fun MidnightNeonReelView(reel: ReelCustomization) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
    ) {
        ReelHeaderBar(reel)

        Spacer(modifier = Modifier.height(4.dp))

        // Neon Framed Photo
        Box(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
                .clip(RoundedCornerShape(14.dp))
                .border(2.dp, Color(0xFF00E5FF), RoundedCornerShape(14.dp))
        ) {
            if (reel.imageResId != 0) {
                Image(
                    painter = painterResource(id = reel.imageResId),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Dark Neon Info Card
        Card(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF121B2A)),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFFF5722))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "⚡ ${reel.categoryHindi.uppercase()}",
                        color = Color(0xFF00E5FF),
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "📍 ${reel.cityHindi}",
                        color = Color(0xFFFFAB91),
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = reel.headline.ifBlank { "यहाँ खबर का मुख्य शीर्षक आएगा..." },
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    lineHeight = 19.sp,
                    maxLines = 3
                )

                if (reel.summary.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = reel.summary,
                        color = Color(0xFFB0BEC5),
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        maxLines = 3
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        ReelFooterBar(reel)
    }
}

@Composable
private fun ReelHeaderBar(
    reel: ReelCustomization,
    onLight: Boolean = false
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = if (onLight) reel.colorTheme.primaryColor else Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            reel.colorTheme.primaryColor,
                            reel.colorTheme.secondaryColor
                        )
                    )
                )
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(Color.White, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("ख़", color = OrangePrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "सिटी ख़बर",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "CITY KHABAR • REEL",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.Black.copy(alpha = 0.35f)
                ) {
                    Text(
                        text = "📱 9:16 रील",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ReelFooterBar(
    reel: ReelCustomization,
    onLight: Boolean = false
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF090D14)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = null,
                    tint = OrangePrimary,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (reel.showReporter && reel.reporterName.isNotBlank()) reel.reporterName else "सिटी खबर स्पेशल",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (reel.showWatermark) {
                Text(
                    text = "citykhabar.in",
                    color = reel.colorTheme.primaryColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
