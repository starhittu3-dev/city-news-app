package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PostColorTheme
import com.example.model.PostCustomization
import com.example.model.PostTemplateType
import com.example.ui.theme.BreakingNewsRed
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.VerifiedBadgeBlue

@Composable
fun PostTemplateRenderer(
    post: PostCustomization,
    modifier: Modifier = Modifier
) {
    val aspectRatio = when (post.templateType) {
        PostTemplateType.STORY_9_16 -> 9f / 16f
        PostTemplateType.SQUARE_SOCIAL -> 1f
        else -> 4f / 5f
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(aspectRatio)
            .clip(RoundedCornerShape(18.dp))
            .border(2.dp, OrangePrimary.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
            .testTag("post_template_canvas"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = post.colorTheme.backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        when (post.templateType) {
            PostTemplateType.BREAKING_NEWS -> BreakingNewsTemplate(post)
            PostTemplateType.EDITORIAL_MINIMAL -> EditorialTemplate(post)
            PostTemplateType.STORY_9_16 -> StoryTemplate(post)
            PostTemplateType.NEWSPAPER_FRONT -> NewspaperTemplate(post)
            PostTemplateType.SQUARE_SOCIAL -> SquareSocialTemplate(post)
        }
    }
}

@Composable
private fun BreakingNewsTemplate(post: PostCustomization) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(post.colorTheme.backgroundColor)
    ) {
        // Header Banner with Brand Name & City
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(post.colorTheme.primaryColor, post.colorTheme.secondaryColor)
                    )
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(Color.White, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("ख़", color = OrangePrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "सिटी ख़बर",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                if (post.showCityBadge && post.cityHindi.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.Black.copy(alpha = 0.35f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = post.cityHindi,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Breaking News Tag
        if (post.showBreakingTag) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BreakingNewsRed)
                    .padding(vertical = 3.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "⚡ ब्रेकिंग न्यूज़ ⚡",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp
                )
            }
        }

        // Image Section
        if (post.imageResId != 0) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.1f)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(12.dp))
            ) {
                Image(
                    painter = painterResource(id = post.imageResId),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Headline & Summary Body
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = post.headline.ifBlank { "यहाँ अपनी ब्रेकिंग हेडलाइन लिखें..." },
                color = post.colorTheme.textColor,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                lineHeight = 20.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            if (post.summary.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = post.summary,
                    color = post.colorTheme.textColor.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Footer Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(post.colorTheme.primaryColor.copy(alpha = 0.12f))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (post.showReporter) {
                    Text(
                        text = "✍️ ${post.reporterName}",
                        color = post.colorTheme.textColor,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 10.sp
                    )
                }

                if (post.showWatermark) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = VerifiedBadgeBlue,
                            modifier = Modifier.size(11.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "citykhabar.in",
                            color = OrangePrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorialTemplate(post: PostCustomization) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(post.colorTheme.backgroundColor)
            .padding(14.dp)
    ) {
        // Minimal Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CITY KHABAR • संपादकीय",
                    color = OrangePrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.sp
                )
                if (post.showDate && post.dateText.isNotBlank()) {
                    Text(
                        text = post.dateText,
                        color = post.colorTheme.textColor.copy(alpha = 0.6f),
                        fontSize = 9.sp
                    )
                }
            }

            if (post.showCityBadge && post.cityHindi.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = OrangePrimary.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "📍 ${post.cityHindi}",
                        color = OrangePrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Large Editorial Image
        if (post.imageResId != 0) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.2f)
                    .clip(RoundedCornerShape(10.dp))
            ) {
                Image(
                    painter = painterResource(id = post.imageResId),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Headline & Summary with Quote Styling
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Text(
                text = post.headline.ifBlank { "यहाँ संपादकीय मुख्य शीर्षक दर्ज करें..." },
                color = post.colorTheme.textColor,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                lineHeight = 21.sp,
                maxLines = 3
            )

            if (post.summary.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row {
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height(30.dp)
                            .background(OrangePrimary)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = post.summary,
                        color = post.colorTheme.textColor.copy(alpha = 0.75f),
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        maxLines = 2
                    )
                }
            }
        }

        // Clean Bottom
        Divider(color = post.colorTheme.textColor.copy(alpha = 0.15f))
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "विशेष रिपोर्ट: ${post.reporterName}",
                color = post.colorTheme.textColor.copy(alpha = 0.8f),
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "सिटी खबर डिजिटल",
                color = OrangePrimary,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun StoryTemplate(post: PostCustomization) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Background Image
        if (post.imageResId != 0) {
            Image(
                painter = painterResource(id = post.imageResId),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Dark Gradient from top and bottom
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.7f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.9f)
                        )
                    )
                )
        )

        // Top Brand & City Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = OrangePrimary
            ) {
                Text(
                    text = "CITY KHABAR",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }

            if (post.cityHindi.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "📍 ${post.cityHindi}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }
        }

        // Bottom Content
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomStart)
                .padding(14.dp)
        ) {
            if (post.showBreakingTag) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = BreakingNewsRed
                ) {
                    Text(
                        text = "🔴 ब्रेकिंग न्यूज़",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            Text(
                text = post.headline.ifBlank { "स्टोरी हेडलाइन यहाँ..." },
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                lineHeight = 20.sp,
                maxLines = 3
            )

            if (post.summary.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = post.summary,
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("✍️ ${post.reporterName}", color = Color.White.copy(alpha = 0.7f), fontSize = 9.sp)
                Text("#CityKhabar", color = OrangeLight, fontWeight = FontWeight.Bold, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun NewspaperTemplate(post: PostCustomization) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF9F7F1))
            .padding(12.dp)
    ) {
        // Newspaper Masthead
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "दैनिक सिटी ख़बर",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color(0xFF1B1B1B)
            )
            Divider(color = Color.Black, thickness = 1.5.dp, modifier = Modifier.padding(vertical = 2.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "संस्करण: ${post.cityHindi.ifBlank { "मुख्य" }}", fontSize = 8.sp, color = Color.DarkGray)
                Text(text = "दिनांक: ${post.dateText.ifBlank { "आज" }}", fontSize = 8.sp, color = Color.DarkGray)
                Text(text = "मूल्य: विशेष डिजिटल", fontSize = 8.sp, color = Color.DarkGray)
            }
            Divider(color = Color.Black, thickness = 1.dp, modifier = Modifier.padding(top = 2.dp, bottom = 6.dp))
        }

        // Image Section
        if (post.imageResId != 0) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.1f)
                    .clip(RoundedCornerShape(4.dp))
                    .border(1.dp, Color.Black, RoundedCornerShape(4.dp))
            ) {
                Image(
                    painter = painterResource(id = post.imageResId),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        // Newspaper Headline
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Text(
                text = post.headline.ifBlank { "अखबार का मुख्य समाचार शीर्षक..." },
                color = Color.Black,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                lineHeight = 18.sp,
                maxLines = 3
            )

            if (post.summary.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = post.summary,
                    color = Color(0xFF2C2C2C),
                    fontSize = 10.sp,
                    lineHeight = 14.sp,
                    maxLines = 2
                )
            }
        }

        // Footer
        Divider(color = Color.Gray, thickness = 0.5.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 3.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("ब्यूरो: ${post.reporterName}", fontSize = 8.sp, color = Color.Black)
            Text("सिटी खबर डिजिटल प्रेस", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

@Composable
private fun SquareSocialTemplate(post: PostCustomization) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(post.colorTheme.backgroundColor)
            .padding(10.dp)
    ) {
        // Square Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = post.colorTheme.primaryColor,
                    modifier = Modifier.size(20.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("CK", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 8.sp)
                    }
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "सिटी खबर",
                    color = post.colorTheme.textColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            if (post.cityHindi.isNotBlank()) {
                Text(
                    text = "📍 ${post.cityHindi}",
                    color = OrangePrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Center Image
        if (post.imageResId != 0) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.2f)
                    .clip(RoundedCornerShape(10.dp))
            ) {
                Image(
                    painter = painterResource(id = post.imageResId),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        // Headline
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Text(
                text = post.headline.ifBlank { "सोशल मीडिया पोस्ट हेडलाइन..." },
                color = post.colorTheme.textColor,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                lineHeight = 17.sp,
                maxLines = 2
            )

            if (post.summary.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = post.summary,
                    color = post.colorTheme.textColor.copy(alpha = 0.7f),
                    fontSize = 10.sp,
                    maxLines = 2
                )
            }
        }

        // Minimal Footer
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("✍️ ${post.reporterName}", color = post.colorTheme.textColor.copy(alpha = 0.7f), fontSize = 8.sp)
            Text("www.citykhabar.in", color = OrangePrimary, fontWeight = FontWeight.Bold, fontSize = 8.sp)
        }
    }
}
