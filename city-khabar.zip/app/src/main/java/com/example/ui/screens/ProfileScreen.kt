package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.CityInfo
import com.example.model.ThemeMode
import com.example.model.UserAccount
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.OrangeDark
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.VerifiedBadgeBlue

// Avatar options for profile customization
data class AvatarOption(
    val id: String,
    val emoji: String,
    val titleHindi: String,
    val backgroundColors: List<Color>
)

val AVATAR_PRESETS = listOf(
    AvatarOption("avatar_1", "👨‍💼", "संपादक (Editor)", listOf(Color(0xFFFF9800), Color(0xFFE65100))),
    AvatarOption("avatar_2", "👩‍💼", "पत्रकार (Journalist)", listOf(Color(0xFFE91E63), Color(0xFF880E4F))),
    AvatarOption("avatar_3", "🧑‍💻", "डिजिटल पाठक", listOf(Color(0xFF2196F3), Color(0xFF0D47A1))),
    AvatarOption("avatar_4", "👨‍🎓", "युवा क्रिएटर", listOf(Color(0xFF4CAF50), Color(0xFF1B5E20))),
    AvatarOption("avatar_5", "👩‍🎨", "डिज़ाइनर", listOf(Color(0xFF9C27B0), Color(0xFF4A148C))),
    AvatarOption("avatar_6", "🕵️‍♂️", "विशेष संवाददाता", listOf(Color(0xFF607D8B), Color(0xFF263238)))
)

@Composable
fun ProfileScreen(
    userAccount: UserAccount,
    savedNewsCount: Int = 0,
    favoriteCitiesCount: Int = 0,
    createdPostsCount: Int = 0,
    savedReelsCount: Int = 0,
    isSyncing: Boolean = false,
    selectedCity: CityInfo,
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    onBackClick: () -> Unit,
    onSignInWithGoogle: () -> Unit,
    onSignInCustom: (name: String, email: String, phone: String?, city: String?, bio: String?, avatarId: String) -> Unit,
    onUpdateProfile: (name: String, email: String, phone: String?, bio: String?, city: String?, avatarId: String, photoUrl: String?) -> Unit,
    onSignOut: () -> Unit,
    onSyncClick: () -> Unit = {},
    onOpenBookmarks: () -> Unit = {},
    onOpenNotifications: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showSignOutConfirmDialog by remember { mutableStateOf(false) }
    var showSignInModal by remember { mutableStateOf(false) }

    // Intercept hardware/gesture back press
    BackHandler {
        if (showEditProfileDialog) {
            showEditProfileDialog = false
        } else if (showSignInModal) {
            showSignInModal = false
        } else {
            onBackClick()
        }
    }

    // Sign Out Confirmation Dialog
    if (showSignOutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showSignOutConfirmDialog = false },
            icon = {
                Surface(
                    shape = CircleShape,
                    color = CrimsonRed.copy(alpha = 0.12f),
                    modifier = Modifier.size(50.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = null,
                            tint = CrimsonRed,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            },
            title = {
                Text(
                    text = "लॉगआउट की पुष्टि",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "क्या आप अपने अकाउंट से लॉगआउट करना चाहते हैं? आपका स्थानीय डेटा सुरक्षित रहेगा और आप किसी भी समय पुनः साइन इन कर सकते हैं।",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSignOutConfirmDialog = false
                        onSignOut()
                        Toast.makeText(context, "सफलतापूर्वक लॉगआउट किया गया", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("confirm_signout_button")
                ) {
                    Text("लॉगआउट करें", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutConfirmDialog = false }) {
                    Text("रद्द करें", color = MaterialTheme.colorScheme.onSurface)
                }
            }
        )
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        EditProfileDialog(
            currentAccount = userAccount,
            selectedCity = selectedCity,
            onDismiss = { showEditProfileDialog = false },
            onSave = { name, email, phone, bio, city, avatarId ->
                onUpdateProfile(name, email, phone, bio, city, avatarId, null)
                showEditProfileDialog = false
                Toast.makeText(context, "प्रोफ़ाइल सफलतापूर्वक अपडेट हो गई!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Sign In / Create Account Dialog
    if (showSignInModal) {
        SignInCreateAccountDialog(
            defaultCity = selectedCity.nameHindi,
            onDismiss = { showSignInModal = false },
            onGoogleSignIn = {
                showSignInModal = false
                onSignInWithGoogle()
                Toast.makeText(context, "गूगल से सफलतापूर्वक साइन इन किया गया!", Toast.LENGTH_SHORT).show()
            },
            onCreateAccount = { name, email, phone, city ->
                showSignInModal = false
                onSignInCustom(name, email, phone, city, "सिटी खबर का सक्रिय पाठक 📰", "avatar_1")
                Toast.makeText(context, "स्वागत है, $name! आपका अकाउंट बन गया।", Toast.LENGTH_SHORT).show()
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("profile_screen")
    ) {
        // TOP APP BAR
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 3.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("profile_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "वापस जाएं (Back)",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "मेरी प्रोफ़ाइल (My Profile)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = OrangePrimary
                    )
                    Text(
                        text = if (userAccount.isGuest) "अतिथि मोड • साइन इन उपलब्ध" else "सत्यापित पाठक • अकाउंट प्रबंधन",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (!userAccount.isGuest) {
                    // Quick Edit Profile Icon Button in Header
                    IconButton(
                        onClick = { showEditProfileDialog = true },
                        modifier = Modifier.testTag("profile_header_edit_btn")
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = OrangePrimary.copy(alpha = 0.12f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "प्रोफ़ाइल संपादित करें (Edit Profile)",
                                    tint = OrangePrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // MAIN CONTENT
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 16.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 80.dp
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (userAccount.isGuest) {
                // ==========================================
                // 1. GUEST USER VIEW (NOT LOGGED IN)
                // ==========================================
                item {
                    GuestProfileHeroCard(
                        onGoogleSignIn = onSignInWithGoogle,
                        onCreateAccountClick = { showSignInModal = true }
                    )
                }

                item {
                    WhySignInBenefitsCard()
                }

                item {
                    QuickDemoLoginCard(
                        onSelectProfile = { name, email, city ->
                            onSignInCustom(name, email, "+91 98765 43210", city, "दैनिक ताज़ा खबरों का नियमित पाठक 📰", "avatar_1")
                            Toast.makeText(context, "लॉगिन सफल: $name", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            } else {
                // ==========================================
                // 2. LOGGED IN USER VIEW
                // ==========================================
                item {
                    LoggedInProfileHeroCard(
                        userAccount = userAccount,
                        isSyncing = isSyncing,
                        onEditProfileClick = { showEditProfileDialog = true },
                        onSyncClick = onSyncClick
                    )
                }

                // Activity & Stats Dashboard
                item {
                    Text(
                        text = "गतिविधि एवं सामग्री सारांश (My Activity)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                item {
                    UserActivityGrid(
                        savedNewsCount = savedNewsCount,
                        favoriteCitiesCount = favoriteCitiesCount,
                        createdPostsCount = createdPostsCount,
                        savedReelsCount = savedReelsCount,
                        onOpenBookmarks = onOpenBookmarks
                    )
                }

                // Personal Details Card
                item {
                    Text(
                        text = "व्यक्तिगत विवरण (Personal Details)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                item {
                    PersonalDetailsCard(
                        userAccount = userAccount,
                        onEditClick = { showEditProfileDialog = true }
                    )
                }

                // Quick Navigation Shortcuts
                item {
                    Text(
                        text = "प्राथमिकताएं एवं सेटिंग्स (Preferences)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                item {
                    ProfilePreferencesCard(
                        themeMode = themeMode,
                        onOpenNotifications = onOpenNotifications,
                        onOpenSettings = onOpenSettings
                    )
                }

                // LOGOUT BUTTON
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_logout_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, CrimsonRed.copy(alpha = 0.25f)),
                        elevation = CardDefaults.cardElevation(1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showSignOutConfirmDialog = true }
                                .padding(16.dp)
                                .testTag("profile_logout_button"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = CrimsonRed.copy(alpha = 0.12f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Logout,
                                        contentDescription = "लॉगआउट",
                                        tint = CrimsonRed,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "लॉगआउट / साइन आउट (Logout)",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CrimsonRed
                                )
                                Text(
                                    text = "अकाउंट से सुरक्षित रूप से बाहर निकलें",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// LOGGED IN HERO CARD
// =========================================================================
@Composable
fun LoggedInProfileHeroCard(
    userAccount: UserAccount,
    isSyncing: Boolean,
    onEditProfileClick: () -> Unit,
    onSyncClick: () -> Unit
) {
    val avatarOption = AVATAR_PRESETS.find { it.id == userAccount.avatarId } ?: AVATAR_PRESETS[0]

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("logged_in_hero_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Profile Photo / Avatar with Edit Badge
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clickable { onEditProfileClick() },
                contentAlignment = Alignment.Center
            ) {
                // Outer ring
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(avatarOption.backgroundColors))
                        .padding(3.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(Brush.linearGradient(avatarOption.backgroundColors)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = avatarOption.emoji,
                            fontSize = 40.sp
                        )
                    }
                }

                // Camera / Edit badge on bottom right of avatar
                Surface(
                    shape = CircleShape,
                    color = OrangePrimary,
                    border = BorderStroke(2.dp, MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Photo",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // User Name + Verified Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = userAccount.displayName,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = "सत्यापित पाठक",
                    tint = VerifiedBadgeBlue,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Email Address
            Text(
                text = userAccount.email.ifBlank { "reader@citykhabar.in" },
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Bio / Status if available
            if (!userAccount.bio.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "“${userAccount.bio}”",
                    fontSize = 12.sp,
                    color = OrangeDark,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Badges Row: Membership & City
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (userAccount.isPremium) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFFD54F).copy(alpha = 0.25f),
                        border = BorderStroke(1.dp, Color(0xFFFFB300))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("👑", fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "VIP प्रीमियम पाठक",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE65100)
                            )
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = OrangePrimary.copy(alpha = 0.12f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = OrangePrimary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "सत्यापित पाठक (Verified)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = OrangeDark
                            )
                        }
                    }
                }

                if (!userAccount.city.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = OrangePrimary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = userAccount.city,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons: Edit Profile & Cloud Sync
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onEditProfileClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("profile_edit_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = OrangePrimary,
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "प्रोफ़ाइल संपादित करें",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                OutlinedButton(
                    onClick = onSyncClick,
                    modifier = Modifier
                        .height(44.dp)
                        .testTag("profile_sync_btn"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.2.dp, OrangePrimary)
                ) {
                    if (isSyncing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = OrangePrimary
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.CloudSync,
                            contentDescription = "सिंक",
                            tint = OrangePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isSyncing) "सिंक..." else "सिंक",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = OrangePrimary
                    )
                }
            }
        }
    }
}

// =========================================================================
// GUEST PROFILE HERO CARD
// =========================================================================
@Composable
fun GuestProfileHeroCard(
    onGoogleSignIn: () -> Unit,
    onCreateAccountClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("guest_hero_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Guest Avatar
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.size(80.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = "Guest",
                        tint = Color.Gray,
                        modifier = Modifier.size(56.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "अतिथि पाठक (Guest User)",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Gray.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "ऑफलाइन मोड",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "आप वर्तमान में बिना साइन इन किए 'सिटी खबर' का उपयोग कर रहे हैं। क्लाउड बैकअप और विशेष सुविधाओं के लिए साइन इन करें।",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Primary Google Sign In Button
            Button(
                onClick = onGoogleSignIn,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("profile_google_signin_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("G", fontSize = 15.sp, fontWeight = FontWeight.Black, color = VerifiedBadgeBlue)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Google से साइन इन करें",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Secondary Create Account / Email Sign In Button
            Button(
                onClick = onCreateAccountClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("profile_create_account_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = OrangePrimary,
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "नया अकाउंट बनाएं / ईमेल से लॉगिन",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// =========================================================================
// WHY SIGN IN BENEFITS CARD
// =========================================================================
@Composable
fun WhySignInBenefitsCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "✨ साइन इन करने के मुख्य फ़ायदे",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = OrangePrimary
            )

            Spacer(modifier = Modifier.height(12.dp))

            BenefitRow(
                emoji = "☁️",
                title = "सुरक्षित क्लाउड बैकअप",
                desc = "सेव की गई खबरें और पसंदीदा शहर हमेशा सुरक्षित रहेंगे।"
            )
            Spacer(modifier = Modifier.height(8.dp))
            BenefitRow(
                emoji = "🎨",
                title = "क्रिएटर प्रोजेक्ट्स बैकअप",
                desc = "आपके बनाए गए कस्टम पोस्टर्स और रील्स कभी डिलीट नहीं होंगे।"
            )
            Spacer(modifier = Modifier.height(8.dp))
            BenefitRow(
                emoji = "⚡",
                title = "पर्सनलाइज्ड समाचार अलर्ट्स",
                desc = "आपके शहर व पसंदीदा विषयों की ताज़ा सूचनाएं सीधे मिलेंगी।"
            )
        }
    }
}

@Composable
fun BenefitRow(emoji: String, title: String, desc: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Text(text = emoji, fontSize = 16.sp)
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = desc,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp
            )
        }
    }
}

// =========================================================================
// QUICK DEMO LOGIN CARD (FOR SEAMLESS TESTING)
// =========================================================================
@Composable
fun QuickDemoLoginCard(
    onSelectProfile: (name: String, email: String, city: String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "⚡ त्वरित 1-टैप लॉगिन (Quick Sign-In)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "डेमो प्रोफाइल",
                    fontSize = 10.sp,
                    color = OrangePrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            val demoProfiles = listOf(
                Triple("रोहित शर्मा (Rohit Sharma)", "rohit.sharma@gmail.com", "भोपाल"),
                Triple("प्रिया पटेल (Priya Patel)", "priya.patel@gmail.com", "इंदौर"),
                Triple("अमित वर्मा (Amit Verma)", "amit.verma@citykhabar.in", "जयपुर")
            )

            demoProfiles.forEach { (name, email, city) ->
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onSelectProfile(name, email, city) }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = OrangePrimary,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = name.take(1),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = name,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "$email • 📍 $city",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Login",
                            tint = OrangePrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

// =========================================================================
// USER ACTIVITY GRID
// =========================================================================
@Composable
fun UserActivityGrid(
    savedNewsCount: Int,
    favoriteCitiesCount: Int,
    createdPostsCount: Int,
    savedReelsCount: Int,
    onOpenBookmarks: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ActivityStatCard(
            title = "सेव खबरें",
            count = savedNewsCount.toString(),
            emoji = "🔖",
            subtitle = "बुकमार्क",
            onClick = onOpenBookmarks,
            modifier = Modifier.weight(1f)
        )
        ActivityStatCard(
            title = "पसंदीदा शहर",
            count = favoriteCitiesCount.toString(),
            emoji = "🏙️",
            subtitle = "फ़ेवरेट",
            modifier = Modifier.weight(1f)
        )
        ActivityStatCard(
            title = "बनाए पोस्ट",
            count = createdPostsCount.toString(),
            emoji = "🎨",
            subtitle = "क्रिएटर",
            modifier = Modifier.weight(1f)
        )
        ActivityStatCard(
            title = "सेव रील्स",
            count = savedReelsCount.toString(),
            emoji = "🎬",
            subtitle = "वीडियो",
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun ActivityStatCard(
    title: String,
    count: String,
    emoji: String,
    subtitle: String,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.5.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = emoji, fontSize = 20.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = count,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = OrangePrimary
            )
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
            Text(
                text = subtitle,
                fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// =========================================================================
// PERSONAL DETAILS CARD
// =========================================================================
@Composable
fun PersonalDetailsCard(
    userAccount: UserAccount,
    onEditClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("personal_details_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.5.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "खाता जानकारी (Account Info)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                TextButton(onClick = onEditClick) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        tint = OrangePrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "संपादित करें",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = OrangePrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            DetailItemRow(
                icon = Icons.Default.Person,
                label = "पूरा नाम",
                value = userAccount.displayName
            )
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 8.dp))

            DetailItemRow(
                icon = Icons.Default.Email,
                label = "ईमेल पता",
                value = userAccount.email.ifBlank { "उपलब्ध नहीं" }
            )
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 8.dp))

            DetailItemRow(
                icon = Icons.Default.Phone,
                label = "फ़ोन नंबर",
                value = userAccount.phone ?: "+91 98765 43210"
            )
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 8.dp))

            DetailItemRow(
                icon = Icons.Default.LocationOn,
                label = "गृह नगर / स्थान",
                value = userAccount.city ?: "भोपाल, मध्य प्रदेश"
            )
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 8.dp))

            DetailItemRow(
                icon = Icons.Default.CloudDone,
                label = "क्लाउड सिंक स्थिति",
                value = if (userAccount.syncEnabled) "सक्रिय एवं सुरक्षित ✅" else "निष्क्रिय"
            )
        }
    }
}

@Composable
fun DetailItemRow(
    icon: ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier.size(32.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = OrangePrimary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

// =========================================================================
// PROFILE PREFERENCES CARD
// =========================================================================
@Composable
fun ProfilePreferencesCard(
    themeMode: ThemeMode,
    onOpenNotifications: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.5.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            PreferenceRow(
                icon = Icons.Default.Notifications,
                title = "सूचनाएं एवं समाचार अलर्ट्स",
                subtitle = "ब्रेकिंग व शहर अलर्ट्स प्रबंधित करें",
                onClick = onOpenNotifications
            )
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 8.dp))

            PreferenceRow(
                icon = when (themeMode) {
                    ThemeMode.DARK -> Icons.Default.DarkMode
                    ThemeMode.LIGHT -> Icons.Default.LightMode
                    ThemeMode.SYSTEM -> Icons.Default.DarkMode
                },
                title = "ऐप सेटिंग्स एवं थीम",
                subtitle = "डार्क मोड, भाषा व फ़ॉन्ट सेटिंग्स",
                onClick = onOpenSettings
            )
        }
    }
}

@Composable
fun PreferenceRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = OrangePrimary.copy(alpha = 0.12f),
            modifier = Modifier.size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = OrangePrimary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(
            text = "›",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// =========================================================================
// EDIT PROFILE DIALOG
// =========================================================================
@Composable
fun EditProfileDialog(
    currentAccount: UserAccount,
    selectedCity: CityInfo,
    onDismiss: () -> Unit,
    onSave: (name: String, email: String, phone: String?, bio: String?, city: String?, avatarId: String) -> Unit
) {
    var name by remember { mutableStateOf(currentAccount.displayName) }
    var email by remember { mutableStateOf(currentAccount.email) }
    var phone by remember { mutableStateOf(currentAccount.phone ?: "+91 98765 43210") }
    var bio by remember { mutableStateOf(currentAccount.bio ?: "दैनिक ताज़ा खबरों और स्थानीय रिपोर्टिंग का पाठक 📰") }
    var city by remember { mutableStateOf(currentAccount.city ?: selectedCity.nameHindi) }
    var selectedAvatarId by remember { mutableStateOf(currentAccount.avatarId) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("edit_profile_dialog")
        ) {
            LazyColumn(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "✏️ प्रोफ़ाइल संपादित करें",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = OrangePrimary
                        )
                        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                            Text("✕", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Avatar Selection Row
                item {
                    Text(
                        text = "अवतार चुनें (Choose Avatar):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(AVATAR_PRESETS) { option ->
                            val isSelected = option.id == selectedAvatarId
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(option.backgroundColors))
                                    .then(
                                        if (isSelected) Modifier.border(3.dp, Color.White, CircleShape)
                                        else Modifier
                                    )
                                    .clickable { selectedAvatarId = option.id }
                                    .padding(4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = option.emoji, fontSize = 24.sp)
                            }
                        }
                    }
                }

                // Input: Full Name
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("पूरा नाम (Full Name)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_profile_name_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OrangePrimary,
                            focusedLabelColor = OrangePrimary
                        )
                    )
                }

                // Input: Email
                item {
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("ईमेल पता (Email)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_profile_email_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OrangePrimary,
                            focusedLabelColor = OrangePrimary
                        )
                    )
                }

                // Input: Phone
                item {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("फ़ोन नंबर (Phone Number)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_profile_phone_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OrangePrimary,
                            focusedLabelColor = OrangePrimary
                        )
                    )
                }

                // Input: City
                item {
                    OutlinedTextField(
                        value = city,
                        onValueChange = { city = it },
                        label = { Text("गृह नगर / शहर (City)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_profile_city_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OrangePrimary,
                            focusedLabelColor = OrangePrimary
                        )
                    )
                }

                // Input: Bio
                item {
                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text("बायो / स्टेटस (Bio)") },
                        maxLines = 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_profile_bio_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OrangePrimary,
                            focusedLabelColor = OrangePrimary
                        )
                    )
                }

                // Save & Cancel Buttons
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("cancel_profile_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("रद्द करें")
                        }

                        Button(
                            onClick = {
                                if (name.isNotBlank()) {
                                    onSave(name.trim(), email.trim(), phone.trim(), bio.trim(), city.trim(), selectedAvatarId)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("save_profile_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)
                        ) {
                            Text("सेव करें", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// SIGN IN / CREATE ACCOUNT MODAL DIALOG
// =========================================================================
@Composable
fun SignInCreateAccountDialog(
    defaultCity: String,
    onDismiss: () -> Unit,
    onGoogleSignIn: () -> Unit,
    onCreateAccount: (name: String, email: String, phone: String?, city: String?) -> Unit
) {
    var isCreateAccountMode by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var city by remember { mutableStateOf(if (defaultCity == "सभी शहर") "भोपाल" else defaultCity) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("signin_create_account_dialog")
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isCreateAccountMode) "✨ नया अकाउंट बनाएं" else "🔐 साइन इन करें",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = OrangePrimary
                        )
                        Text(
                            text = "सिटी खबर पाठक समुदाय से जुड़ें",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Text("✕", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Google 1-Tap Sign In
                Button(
                    onClick = onGoogleSignIn,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("dialog_google_signin_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("G", fontSize = 14.sp, fontWeight = FontWeight.Black, color = VerifiedBadgeBlue)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Google से 1-टैप साइन इन",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Divider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.outlineVariant)
                    Text(
                        text = "  या ईमेल द्वारा  ",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Divider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.outlineVariant)
                }

                if (isCreateAccountMode) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("पूरा नाम (Full Name)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OrangePrimary,
                            focusedLabelColor = OrangePrimary
                        )
                    )
                }

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("ईमेल पता (Email)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = OrangePrimary,
                        focusedLabelColor = OrangePrimary
                    )
                )

                if (isCreateAccountMode) {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("फ़ोन नंबर (वैकल्पिक)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OrangePrimary,
                            focusedLabelColor = OrangePrimary
                        )
                    )

                    OutlinedTextField(
                        value = city,
                        onValueChange = { city = it },
                        label = { Text("आपका शहर") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OrangePrimary,
                            focusedLabelColor = OrangePrimary
                        )
                    )
                }

                Button(
                    onClick = {
                        val inputName = if (name.isNotBlank()) name.trim() else "सिटी पाठक"
                        val inputEmail = if (email.isNotBlank()) email.trim() else "reader@citykhabar.in"
                        onCreateAccount(inputName, inputEmail, phone.ifBlank { null }, city.ifBlank { "भोपाल" })
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("dialog_submit_account_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)
                ) {
                    Text(
                        text = if (isCreateAccountMode) "अकाउंट बनाएं व साइन इन करें" else "ईमेल से साइन इन करें",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                TextButton(
                    onClick = { isCreateAccountMode = !isCreateAccountMode },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text(
                        text = if (isCreateAccountMode) "पहले से अकाउंट है? साइन इन करें" else "नया अकाउंट बनाना चाहते हैं? यहां क्लिक करें",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = OrangePrimary
                    )
                }
            }
        }
    }
}
