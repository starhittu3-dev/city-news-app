package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.LivePulseGreen
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.WarmAmber
import com.example.util.VoiceSearchHelper
import com.example.util.VoiceSearchUiState

/**
 * Hindi Voice Search Modal Bottom Sheet with animated sound wave visuals,
 * dynamic runtime microphone permission handling, and Hindi error reporting.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceSearchModal(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    onSearchTextRecognized: (String) -> Unit,
    sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
) {
    if (!isOpen) return

    val context = LocalContext.current
    val voiceHelper = remember(context) { VoiceSearchHelper(context) }
    val voiceState by voiceHelper.uiState.collectAsState()

    var recognizedQuery by remember { mutableStateOf("") }
    var permissionDeniedError by remember { mutableStateOf<String?>(null) }

    // Permission launcher for RECORD_AUDIO
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            permissionDeniedError = null
            voiceHelper.startListening(
                onResult = { spokenText ->
                    recognizedQuery = spokenText
                }
            )
        } else {
            permissionDeniedError = "वॉइस सर्च के लिए माइक (Microphone) की अनुमति आवश्यक है। कृपया अनुमति दें।"
        }
    }

    // Function to check permission and trigger listening
    fun requestAndStartListening() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            permissionDeniedError = null
            voiceHelper.startListening(
                onResult = { spokenText ->
                    recognizedQuery = spokenText
                }
            )
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Automatically trigger voice search when modal opens
    LaunchedEffect(isOpen) {
        if (isOpen) {
            recognizedQuery = ""
            permissionDeniedError = null
            requestAndStartListening()
        }
    }

    // Clean up when leaving composable
    DisposableEffect(Unit) {
        onDispose {
            voiceHelper.stopListening()
        }
    }

    // Pulsating animation for listening mic
    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )
    val ringAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ring_alpha"
    )

    ModalBottomSheet(
        onDismissRequest = {
            voiceHelper.stopListening()
            onDismiss()
        },
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar: Title & Close Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(OrangePrimary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = OrangePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "हिंदी वॉइस सर्च",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "अपनी आवाज़ में समाचार खोजें",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = {
                        voiceHelper.stopListening()
                        onDismiss()
                    },
                    modifier = Modifier.testTag("voice_search_close_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "बंद करें (Close)",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Animated Mic Center Stage
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .testTag("voice_search_mic_stage"),
                contentAlignment = Alignment.Center
            ) {
                val isListening = voiceState is VoiceSearchUiState.Listening || voiceState is VoiceSearchUiState.Initializing

                // Outer Glowing Ripple Rings
                if (isListening && permissionDeniedError == null) {
                    Box(
                        modifier = Modifier
                            .size(140.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(OrangePrimary.copy(alpha = ringAlpha * 0.4f))
                    )
                    Box(
                        modifier = Modifier
                            .size(110.dp)
                            .scale(pulseScale * 0.95f)
                            .clip(CircleShape)
                            .background(OrangePrimary.copy(alpha = ringAlpha * 0.7f))
                    )
                }

                // Inner Main Mic Button
                val micColor = when {
                    permissionDeniedError != null -> CrimsonRed
                    voiceState is VoiceSearchUiState.Error -> CrimsonRed
                    voiceState is VoiceSearchUiState.Success -> LivePulseGreen
                    isListening -> OrangePrimary
                    else -> OrangePrimary
                }

                Surface(
                    shape = CircleShape,
                    color = micColor,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .size(80.dp)
                        .clickable {
                            requestAndStartListening()
                        }
                        .testTag("voice_search_mic_button")
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = when {
                                permissionDeniedError != null || voiceState is VoiceSearchUiState.Error -> Icons.Default.Mic
                                voiceState is VoiceSearchUiState.Success -> Icons.Default.Check
                                else -> Icons.Default.Mic
                            },
                            contentDescription = "माइक (Microphone)",
                            tint = Color.White,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Status Headline & Prompts
            val (statusText, statusColor) = when {
                permissionDeniedError != null -> {
                    "माइक की अनुमति नहीं मिली" to CrimsonRed
                }
                voiceState is VoiceSearchUiState.Initializing -> {
                    "माइक तैयार हो रहा है..." to OrangePrimary
                }
                voiceState is VoiceSearchUiState.Listening -> {
                    "सुन रहे हैं... कृपया हिंदी में बोलें" to OrangePrimary
                }
                voiceState is VoiceSearchUiState.Processing -> {
                    "पहचान रहे हैं..." to WarmAmber
                }
                voiceState is VoiceSearchUiState.Success -> {
                    "सफलतापूर्वक पहचाना गया!" to LivePulseGreen
                }
                voiceState is VoiceSearchUiState.Error -> {
                    "पहचानने में असमर्थ" to CrimsonRed
                }
                else -> {
                    "माइक पर टैप करके बोलें" to MaterialTheme.colorScheme.onSurface
                }
            }

            Text(
                text = statusText,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = statusColor,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Error Message Banner (if any error)
            val activeError = permissionDeniedError ?: (voiceState as? VoiceSearchUiState.Error)?.errorMessageHindi
            if (activeError != null) {
                Surface(
                    color = CrimsonRed.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRed.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = CrimsonRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = activeError,
                            fontSize = 13.sp,
                            color = CrimsonRed,
                            lineHeight = 18.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Recognized Query Card or Sample Hindi Suggestions
            if (recognizedQuery.isNotBlank() || voiceState is VoiceSearchUiState.Success) {
                val displayText = recognizedQuery.ifBlank {
                    (voiceState as? VoiceSearchUiState.Success)?.spokenText ?: ""
                }
                Surface(
                    color = LivePulseGreen.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LivePulseGreen.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "पहचाने गए शब्द:",
                            fontSize = 12.sp,
                            color = LivePulseGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "\"$displayText\"",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions: Submit Search or Try Again
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            recognizedQuery = ""
                            requestAndStartListening()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("voice_search_retry_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("दोबारा बोलें", fontSize = 14.sp)
                    }

                    Button(
                        onClick = {
                            voiceHelper.stopListening()
                            onSearchTextRecognized(displayText)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .height(48.dp)
                            .testTag("voice_search_confirm_btn")
                    ) {
                        Text("यह खोजें (Search)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                // Sample Prompts to help the user
                Text(
                    text = "उदाहरण बोलें: \"जयपुर मौसम\", \"क्रिकेट स्कोर\", \"नौकरी समाचार\", \"अपराध समाचार\", \"व्यापार\"",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    lineHeight = 17.sp,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Quick Hindi Topic Suggestion Chips
                Text(
                    text = "या इनमें से चुनें:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(6.dp))

                val quickVoiceTopics = listOf("जयपुर समाचार", "इंदौर अपराध", "मध्य प्रदेश मौसम", "क्रिकेट अपडेट", "सोने का भाव")
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(quickVoiceTopics) { topic ->
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable {
                                    voiceHelper.stopListening()
                                    onSearchTextRecognized(topic)
                                    onDismiss()
                                }
                        ) {
                            Text(
                                text = topic,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (voiceState is VoiceSearchUiState.Error || permissionDeniedError != null) {
                    Button(
                        onClick = {
                            requestAndStartListening()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("voice_search_try_again_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("पुनः प्रयास करें (Try Again)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
