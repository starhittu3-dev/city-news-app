package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.outlined.RateReview
import androidx.compose.material.icons.outlined.ReportProblem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.OrangeDark
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary
import kotlin.random.Random

enum class SupportSubTab(val titleHindi: String, val titleEnglish: String) {
    FEEDBACK("प्रतिक्रिया (Feedback)", "Feedback"),
    REPORT_PROBLEM("समस्या रिपोर्ट करें (Report Issue)", "Report Problem")
}

/**
 * Contact and Support Screen for City Khabar.
 * Includes:
 * 1. Support email placeholder card with one-click intent/copy
 * 2. Interactive Feedback form
 * 3. Dedicated "Report a Problem" option (Fake News, Crash, Playback, Content issue)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactSupportScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val supportEmail = "support@citykhabar.in"
    val editorialEmail = "editor@citykhabar.in"

    var selectedTab by remember { mutableStateOf(SupportSubTab.FEEDBACK) }

    // Feedback Form States
    var feedbackName by remember { mutableStateOf("") }
    var feedbackEmail by remember { mutableStateOf("") }
    var selectedFeedbackCategory by remember { mutableStateOf("💡 नया सुझाव (Suggestion)") }
    var feedbackMessage by remember { mutableStateOf("") }
    var feedbackSubmittedMessage by remember { mutableStateOf<String?>(null) }

    // Report Problem States
    var reportProblemType by remember { mutableStateOf("गलत या भ्रामक समाचार (Fake / Misleading News)") }
    var reportNewsHeadline by remember { mutableStateOf("") }
    var reportDetails by remember { mutableStateOf("") }
    var reportEmail by remember { mutableStateOf("") }
    var reportSubmittedTicketId by remember { mutableStateOf<String?>(null) }

    val feedbackCategories = listOf(
        "💡 नया सुझाव (Suggestion)",
        "📰 समाचार सामग्री (News Content)",
        "🎬 रील / वीडियो अनुभव (Reels)",
        "🎨 पोस्टर क्रिएटर (Post Studio)",
        "⭐ सामान्य प्रतिक्रिया (General)"
    )

    val problemCategories = listOf(
        "गलत या भ्रामक समाचार (Fake / Misleading News)",
        "वीडियो रील प्लेबैक समस्या (Reel Playback Issue)",
        "ऐप क्रैश या धीमापन (App Crash / Lag)",
        "कॉपीराइट या इमेज आपत्ति (Copyright / Image)",
        "अन्य तकनीकी समस्या (Other Technical Issue)"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("contact_support_screen")
    ) {
        // Top App Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 3.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("support_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "वापस जाएं",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                Column {
                    Text(
                        text = "संपर्क एवं सहायता (Contact & Support)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "सहायता ईमेल, प्रतिक्रिया व समस्या निवारण",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 14.dp, 16.dp, 40.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Support Email Placeholder Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(2.dp),
                    border = BorderStroke(1.dp, OrangePrimary.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth().testTag("support_email_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = OrangePrimary.copy(alpha = 0.12f),
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.HeadsetMic,
                                        contentDescription = null,
                                        tint = OrangePrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = "आधिकारिक सहायता डेस्क (Helpdesk)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "24x7 त्वरित सहायता एवं संपादकीय संपर्क",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Email Placeholder Box: support@citykhabar.in
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(
                                        imageVector = Icons.Default.MailOutline,
                                        contentDescription = null,
                                        tint = OrangePrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "सहायता ईमेल (Support Email):",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = supportEmail,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = OrangePrimary
                                        )
                                    }
                                }

                                Row {
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("City Khabar Support Email", supportEmail)
                                            clipboard.setPrimaryClip(clip)
                                            Toast.makeText(context, "ईमेल कॉपी हो गया: $supportEmail", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(36.dp).testTag("copy_support_email_btn")
                                    ) {
                                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy Email", tint = OrangePrimary, modifier = Modifier.size(18.dp))
                                    }

                                    IconButton(
                                        onClick = {
                                            try {
                                                val intent = Intent(Intent.ACTION_SENDTO).apply {
                                                    data = Uri.parse("mailto:$supportEmail")
                                                    putExtra(Intent.EXTRA_SUBJECT, "City Khabar Support Request")
                                                }
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "ईमेल ऐप नहीं मिला", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.size(36.dp).testTag("mail_support_email_btn")
                                    ) {
                                        Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "Send Email", tint = OrangePrimary, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Tab Selector: Feedback vs. Report a Problem
            item {
                TabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = OrangePrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                            color = OrangePrimary
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .testTag("support_sub_tabs")
                ) {
                    SupportSubTab.entries.forEach { tab ->
                        val isSelected = selectedTab == tab
                        Tab(
                            selected = isSelected,
                            onClick = { selectedTab = tab },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (tab == SupportSubTab.FEEDBACK) Icons.Outlined.RateReview else Icons.Outlined.ReportProblem,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = tab.titleHindi,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        )
                    }
                }
            }

            // SECTION A: FEEDBACK FORM
            if (selectedTab == SupportSubTab.FEEDBACK) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier.fillMaxWidth().testTag("feedback_form_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Feedback, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "प्रतिक्रिया व सुझाव फॉर्म (Feedback Form)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "आपकी प्रतिक्रिया से हम सिटी खबर को और बेहतर बनाते हैं।",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Feedback Category Chips
                            Text("श्रेणी चुनें (Select Category):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(6.dp))

                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(feedbackCategories) { cat ->
                                    val isCatSelected = selectedFeedbackCategory == cat
                                    FilterChip(
                                        selected = isCatSelected,
                                        onClick = { selectedFeedbackCategory = cat },
                                        label = { Text(cat, fontSize = 11.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = OrangePrimary.copy(alpha = 0.15f),
                                            selectedLabelColor = OrangePrimary
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Name Field
                            OutlinedTextField(
                                value = feedbackName,
                                onValueChange = { feedbackName = it },
                                label = { Text("आपका नाम (Name)") },
                                placeholder = { Text("उदा. अमित शर्मा") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OrangePrimary,
                                    focusedLabelColor = OrangePrimary
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("feedback_name_input")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Email/Phone Field
                            OutlinedTextField(
                                value = feedbackEmail,
                                onValueChange = { feedbackEmail = it },
                                label = { Text("ईमेल या मोबाइल नंबर (Email / Phone)") },
                                placeholder = { Text("उदा. rahul@example.com") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OrangePrimary,
                                    focusedLabelColor = OrangePrimary
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("feedback_email_input")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Message Field
                            OutlinedTextField(
                                value = feedbackMessage,
                                onValueChange = { feedbackMessage = it },
                                label = { Text("आपका संदेश / सुझाव (Your Message) *") },
                                placeholder = { Text("ऐप के बारे में अपना सुझाव या अनुभव यहां लिखें...") },
                                minLines = 4,
                                maxLines = 6,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OrangePrimary,
                                    focusedLabelColor = OrangePrimary
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("feedback_message_input")
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Submit Feedback Button
                            Button(
                                onClick = {
                                    if (feedbackMessage.trim().isEmpty()) {
                                        Toast.makeText(context, "कृपया संदेश दर्ज करें", Toast.LENGTH_SHORT).show()
                                    } else {
                                        feedbackSubmittedMessage = "धन्यवाद ${feedbackName.ifBlank { "प्रिय पाठक" }}! आपकी प्रतिक्रिया सफलतापूर्वक दर्ज कर ली गई है।"
                                        feedbackMessage = ""
                                        Toast.makeText(context, "प्रतिक्रिया सबमिट हो गई!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("submit_feedback_btn")
                            ) {
                                Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("प्रतिक्रिया भेजें (Submit Feedback)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            // Success Banner
                            AnimatedVisibility(visible = feedbackSubmittedMessage != null) {
                                feedbackSubmittedMessage?.let { msg ->
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color(0xFFE8F5E9),
                                        border = BorderStroke(1.dp, Color(0xFF81C784)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(msg, fontSize = 12.sp, color = Color(0xFF1B5E20), fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // SECTION B: REPORT A PROBLEM OPTION
            if (selectedTab == SupportSubTab.REPORT_PROBLEM) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(2.dp),
                        border = BorderStroke(1.dp, CrimsonRed.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth().testTag("report_problem_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.BugReport, contentDescription = null, tint = CrimsonRed, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "समस्या रिपोर्ट करें (Report a Problem)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = CrimsonRed
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "यदि आपको कोई फेक न्यूज़, वीडियो प्ले समस्या या ऐप में कोई बग दिखाई दे, तो तुरंत हमें सूचित करें।",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Problem Type Selection
                            Text("समस्या का प्रकार चुनें (Select Issue Type):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(6.dp))

                            problemCategories.forEach { probType ->
                                val isTypeSelected = reportProblemType == probType
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isTypeSelected) CrimsonRed.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                    border = BorderStroke(1.dp, if (isTypeSelected) CrimsonRed else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { reportProblemType = probType }
                                        .padding(vertical = 3.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (isTypeSelected) "🔘" else "⚪",
                                            fontSize = 12.sp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = probType,
                                            fontSize = 12.sp,
                                            fontWeight = if (isTypeSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isTypeSelected) CrimsonRed else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Reference News / Reel Headline (Optional)
                            OutlinedTextField(
                                value = reportNewsHeadline,
                                onValueChange = { reportNewsHeadline = it },
                                label = { Text("खबर या रील का शीर्षक (News/Reel Headline - Optional)") },
                                placeholder = { Text("उदा. दिल्ली मौसम अलर्ट...") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CrimsonRed,
                                    focusedLabelColor = CrimsonRed
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("report_headline_input")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Problem Details Field
                            OutlinedTextField(
                                value = reportDetails,
                                onValueChange = { reportDetails = it },
                                label = { Text("समस्या का विस्तृत विवरण (Problem Description) *") },
                                placeholder = { Text("समस्या क्या है, कब हुई और क्या एरर आया...") },
                                minLines = 3,
                                maxLines = 5,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CrimsonRed,
                                    focusedLabelColor = CrimsonRed
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("report_details_input")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Email for Follow-up (Optional)
                            OutlinedTextField(
                                value = reportEmail,
                                onValueChange = { reportEmail = it },
                                label = { Text("आपका संपर्क ईमेल (Contact Email for Updates)") },
                                placeholder = { Text("उदा. user@example.com") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CrimsonRed,
                                    focusedLabelColor = CrimsonRed
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("report_email_input")
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Submit Report Button
                            Button(
                                onClick = {
                                    if (reportDetails.trim().isEmpty()) {
                                        Toast.makeText(context, "कृपया समस्या का विवरण लिखें", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val ticketId = "CK-REP-${Random.nextInt(100000, 999999)}"
                                        reportSubmittedTicketId = ticketId
                                        reportDetails = ""
                                        Toast.makeText(context, "शिकायत दर्ज हो गई! टिकट: $ticketId", Toast.LENGTH_LONG).show()
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("submit_report_btn")
                            ) {
                                Icon(imageVector = Icons.Default.ReportProblem, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("समस्या रिपोर्ट सबमिट करें", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            // Report Success Banner
                            AnimatedVisibility(visible = reportSubmittedTicketId != null) {
                                reportSubmittedTicketId?.let { ticket ->
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color(0xFFFFF3E0),
                                        border = BorderStroke(1.dp, OrangePrimary),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(20.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "शिकायत सफलतापूर्वक पंजीकृत (Ticket: $ticket)",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = Color(0xFFE65100)
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "हमारी तकनीकी और संपादकीय टीम 24 घंटों के भीतर इस समस्या की जांच करेगी।",
                                                fontSize = 11.sp,
                                                color = Color(0xFF5D4037)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
