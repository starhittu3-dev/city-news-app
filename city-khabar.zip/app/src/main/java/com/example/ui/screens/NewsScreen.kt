package com.example.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CityInfo
import com.example.model.NewsCategory
import com.example.model.NewsItem
import com.example.ui.components.BreakingNewsTicker
import com.example.ui.components.CategoryPillRow
import com.example.ui.components.EmptyNewsView
import com.example.ui.components.NewsCard
import com.example.ui.components.RefreshErrorBanner
import com.example.ui.components.SearchHistoryView
import com.example.ui.components.VoiceSearchModal
import com.example.ui.theme.BreakingNewsRed
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary
import com.example.util.PostExportUtil

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsScreen(
    newsList: List<NewsItem>,
    savedNewsList: List<NewsItem>,
    cachedNewsList: List<NewsItem> = emptyList(),
    breakingNewsList: List<NewsItem> = emptyList(),
    selectedCity: CityInfo? = null,
    selectedCategory: NewsCategory,
    searchQuery: String,
    searchHistory: List<String> = emptyList(),
    likedArticleIds: Set<String>,
    offlineArticleIds: Set<String> = emptySet(),
    isOfflineActive: Boolean = false,
    isRefreshing: Boolean = false,
    refreshError: String? = null,
    onRefresh: () -> Unit = {},
    onDismissError: () -> Unit = {},
    onCityPickerClick: () -> Unit = {},
    isArticleBookmarked: (String) -> Boolean,
    onCategorySelected: (NewsCategory) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onSubmitSearch: (String) -> Unit = {},
    onDeleteHistoryItem: (String) -> Unit = {},
    onClearAllHistory: () -> Unit = {},
    onArticleClick: (NewsItem) -> Unit,
    onLikeClick: (String) -> Unit,
    onBookmarkClick: (NewsItem) -> Unit,
    onCreatePostClick: (NewsItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var selectedTabIdx by remember { mutableIntStateOf(0) }
    var isVoiceSearchOpen by remember { mutableStateOf(false) }
    var isSearchHistoryExpanded by remember { mutableStateOf(false) }

    // Combined unique offline list (Saved + Cached)
    val offlineCombinedList = remember(savedNewsList, cachedNewsList) {
        (savedNewsList + cachedNewsList).distinctBy { it.id }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "newsRefreshSpin")
    val spinRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "newsRotation"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Search & Title Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "खबरें व समाचार खोजें",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = OrangePrimary
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Synchronized Selected City Chip
                        if (selectedCity != null) {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = OrangePrimary.copy(alpha = 0.1f),
                                border = BorderStroke(1.dp, OrangePrimary.copy(alpha = 0.35f)),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable { onCityPickerClick() }
                                    .testTag("news_screen_city_badge")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = OrangePrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = selectedCity.nameHindi,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = OrangePrimary
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                        }

                        // Refresh Button
                        IconButton(
                            onClick = onRefresh,
                            enabled = !isRefreshing,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("news_refresh_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "ताज़ा खबरें लोड करें (Refresh)",
                                tint = OrangePrimary,
                                modifier = Modifier
                                    .size(22.dp)
                                    .rotate(if (isRefreshing) spinRotation else 0f)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Search Input Field with Voice Search & History Dropdown Support
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        onSearchQueryChange(it)
                        if (it.isBlank()) {
                            isSearchHistoryExpanded = true
                        }
                    },
                    placeholder = { Text("शीर्षक, शहर, विषय या कीवर्ड खोजें...") },
                    leadingIcon = {
                        IconButton(
                            onClick = {
                                if (searchQuery.isNotBlank()) {
                                    onSubmitSearch(searchQuery)
                                    isSearchHistoryExpanded = false
                                    keyboardController?.hide()
                                } else {
                                    isSearchHistoryExpanded = !isSearchHistoryExpanded
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = OrangePrimary
                            )
                        }
                    },
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(
                                    onClick = {
                                        onSearchQueryChange("")
                                        isSearchHistoryExpanded = true
                                    },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "साफ करें (Clear)",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Voice Search Button (Microphone with Hindi recognition)
                            IconButton(
                                onClick = { isVoiceSearchOpen = true },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("news_voice_search_btn")
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = OrangePrimary.copy(alpha = 0.12f),
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Mic,
                                            contentDescription = "आवाज से खोजें (Voice Search)",
                                            tint = OrangePrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(4.dp))
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            if (searchQuery.isNotBlank()) {
                                onSubmitSearch(searchQuery)
                            }
                            isSearchHistoryExpanded = false
                            keyboardController?.hide()
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = OrangePrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .onFocusChanged { focusState ->
                            if (focusState.isFocused && searchQuery.isBlank()) {
                                isSearchHistoryExpanded = true
                            }
                        }
                        .testTag("news_search_input")
                )

                // Search History & Trending Suggestions Toggle / View
                if (isSearchHistoryExpanded && searchQuery.isBlank()) {
                    SearchHistoryView(
                        searchHistory = searchHistory,
                        onSelectQuery = { selectedQuery ->
                            onSearchQueryChange(selectedQuery)
                            onSubmitSearch(selectedQuery)
                            isSearchHistoryExpanded = false
                            keyboardController?.hide()
                        },
                        onDeleteHistoryItem = onDeleteHistoryItem,
                        onClearAllHistory = onClearAllHistory
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Tab Row for "All News" vs "Breaking News" vs "Bookmarks / Saved"
                TabRow(
                    selectedTabIndex = selectedTabIdx,
                    containerColor = Color.Transparent,
                    contentColor = OrangePrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIdx]),
                            color = if (selectedTabIdx == 1) BreakingNewsRed else OrangePrimary
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTabIdx == 0,
                        onClick = { selectedTabIdx = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Newspaper, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("सभी (${newsList.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTabIdx == 1,
                        onClick = { selectedTabIdx = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = BreakingNewsRed
                                ) {
                                    Text(
                                        text = "LIVE",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "ब्रेकिंग (${breakingNewsList.size})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (selectedTabIdx == 1) BreakingNewsRed else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    )
                    Tab(
                        selected = selectedTabIdx == 2,
                        onClick = { selectedTabIdx = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Filled.Bookmark, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("सेव (${savedNewsList.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTabIdx == 3,
                        onClick = { selectedTabIdx = 3 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Filled.CloudDone, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ऑफलाइन (${offlineCombinedList.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    )
                }
            }
        }

        // Top Loading Indicator Bar when refreshing
        if (isRefreshing) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .testTag("news_refresh_progress"),
                color = OrangePrimary,
                trackColor = OrangeLight.copy(alpha = 0.3f)
            )
        }

        // Offline Notification Banner
        if (isOfflineActive) {
            Surface(
                color = Color(0xFFFFF3E0),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("news_offline_warning_banner"),
                border = BorderStroke(1.dp, Color(0xFFFFCC80))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Bookmark,
                        contentDescription = null,
                        tint = Color(0xFFE65100),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "इंटरनेट उपलब्ध नहीं है। सेव की गई खबरें दिखाई जा रही हैं।",
                        color = Color(0xFFBF360C),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Refresh Error Banner (with retry button)
        if (refreshError != null && selectedTabIdx != 2 && selectedTabIdx != 3 && !isOfflineActive) {
            RefreshErrorBanner(
                errorMessage = refreshError,
                onRetry = onRefresh,
                onDismiss = onDismissError
            )
        }

        // Category Pills (only if in All News tab)
        if (selectedTabIdx == 0) {
            CategoryPillRow(
                selectedCategory = selectedCategory,
                onCategorySelected = onCategorySelected,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        val displayedList = when (selectedTabIdx) {
            0 -> newsList
            1 -> breakingNewsList
            2 -> savedNewsList
            else -> offlineCombinedList
        }

        if (displayedList.isEmpty()) {
            if (selectedTabIdx == 0) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyNewsView(
                        title = "कोई खबर नहीं मिली",
                        subtitle = if (searchQuery.isNotBlank()) "खोजे गए शब्द \"$searchQuery\" के लिए कोई खबर नहीं मिली।" else "चुने गए फिल्टर के अनुसार अभी कोई खबर उपलब्ध नहीं है।",
                        onRetry = onRefresh,
                        onResetCategory = if (selectedCategory != NewsCategory.ALL) {
                            { onCategorySelected(NewsCategory.ALL) }
                        } else null
                    )
                }
            } else if (selectedTabIdx == 1) {
                // Empty Breaking News State
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = BreakingNewsRed.copy(alpha = 0.1f),
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.ElectricBolt,
                                    contentDescription = null,
                                    tint = BreakingNewsRed,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "अभी कोई ब्रेकिंग न्यूज़ नहीं है",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "नई ब्रेकिंग खबरों के लिए ताज़ा (Refresh) करें।",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else if (selectedTabIdx == 2) {
                // Empty Bookmarks State
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.BookmarkBorder,
                            contentDescription = null,
                            tint = OrangeLight.copy(alpha = 0.6f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "आपने अभी कोई खबर सेव नहीं की है।",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "अपनी पसंदीदा खबरों को बाद में पढ़ने के लिए बुकमार्क करें।",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                // Empty Offline State
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = OrangePrimary.copy(alpha = 0.1f),
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.CloudOff,
                                    contentDescription = null,
                                    tint = OrangePrimary,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "कोई ऑफलाइन खबर उपलब्ध नहीं है",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "इंटरनेट होने पर खोली गई या सेव की गई खबरें यहां बिना इंटरनेट के पढ़ी जा सकती हैं।",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 80.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(displayedList, key = { it.id }) { news ->
                    val isBookmarked = isArticleBookmarked(news.id)
                    val isOffline = offlineArticleIds.contains(news.id) || isBookmarked
                    NewsCard(
                        news = news,
                        isLiked = likedArticleIds.contains(news.id),
                        isBookmarked = isBookmarked,
                        isOfflineAvailable = isOffline,
                        onCardClick = { onArticleClick(news) },
                        onLikeClick = { onLikeClick(news.id) },
                        onBookmarkClick = { onBookmarkClick(news) },
                        onShareClick = {
                            PostExportUtil.sharePost(
                                context,
                                com.example.model.PostCustomization(
                                    headline = news.title,
                                    summary = news.summary,
                                    cityHindi = news.cityHindi,
                                    reporterName = news.reporterName,
                                    imageResId = news.imageResId
                                )
                            )
                        },
                        onCreatePostClick = { onCreatePostClick(news) }
                    )
                }
            }
        }

        // Voice Search Modal Bottom Sheet
        VoiceSearchModal(
            isOpen = isVoiceSearchOpen,
            onDismiss = { isVoiceSearchOpen = false },
            onSearchTextRecognized = { recognizedText ->
                onSearchQueryChange(recognizedText)
                onSubmitSearch(recognizedText)
                isSearchHistoryExpanded = false
            }
        )
    }
}
