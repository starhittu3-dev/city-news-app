package com.example.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BookmarkBorder
import com.example.model.UserAccount
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CityInfo
import com.example.model.NewsCategory
import com.example.model.NewsItem
import com.example.model.ThemeMode
import com.example.ui.components.BreakingNewsSection
import com.example.ui.components.BreakingNewsTicker
import com.example.ui.components.CategoryPillRow
import com.example.ui.components.EmptyNewsView
import com.example.ui.components.NewsCard
import com.example.ui.components.RefreshErrorBanner
import com.example.ui.components.VoiceSearchModal
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary
import com.example.util.PostExportUtil
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.filled.LocationCity

enum class HomeFeedScope {
    CURRENT_CITY,
    MY_CITIES
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    selectedCity: CityInfo,
    selectedCategory: NewsCategory,
    newsList: List<NewsItem>,
    breakingNews: List<NewsItem>,
    trendingNews: List<NewsItem>,
    likedArticleIds: Set<String>,
    followedCities: List<CityInfo> = emptyList(),
    primaryCityId: String? = null,
    myCitiesNews: List<NewsItem> = emptyList(),
    onSelectCity: (CityInfo) -> Unit = {},
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    onToggleTheme: () -> Unit = {},
    isRefreshing: Boolean = false,
    refreshError: String? = null,
    onRefresh: () -> Unit = {},
    onDismissError: () -> Unit = {},
    isArticleBookmarked: (String) -> Boolean,
    isOfflineActive: Boolean = false,
    offlineArticleIds: Set<String> = emptySet(),
    onCityClick: () -> Unit,
    onSearchClick: () -> Unit = {},
    onVoiceSearchResult: (String) -> Unit = {},
    onCategorySelected: (NewsCategory) -> Unit,
    onArticleClick: (NewsItem) -> Unit,
    onLikeClick: (String) -> Unit,
    onBookmarkClick: (NewsItem) -> Unit,
    onCreatePostClick: (NewsItem) -> Unit,
    unreadNotificationsCount: Int = 0,
    onNotificationsClick: () -> Unit = {},
    userAccount: UserAccount = UserAccount.GUEST_DEFAULT,
    onProfileClick: () -> Unit = {},
    onViewAllTrendingClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isVoiceSearchOpen by remember { mutableStateOf(false) }
    var feedScope by remember { mutableStateOf(HomeFeedScope.CURRENT_CITY) }

    val infiniteTransition = rememberInfiniteTransition(label = "refreshSpin")
    val spinRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Sleek Curved Top Header
        Surface(
            color = OrangePrimary,
            shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp),
            shadowElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                // Top Row: Brand & Action Icons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Logo & Brand Name
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ElectricBolt,
                                contentDescription = null,
                                tint = OrangePrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = "सिटी खबर",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = Color.White,
                                letterSpacing = (-0.5).sp
                            )
                            Text(
                                text = "डिजिटल हिंदी समाचार एवं क्रिएटर",
                                fontSize = 10.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }

                    // Top Action Icons (Refresh, Search, Notifications)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        // Refresh Button
                        IconButton(
                            onClick = onRefresh,
                            enabled = !isRefreshing,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("home_refresh_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "ताज़ा खबरें लोड करें (Refresh)",
                                tint = Color.White,
                                modifier = Modifier
                                    .size(22.dp)
                                    .rotate(if (isRefreshing) spinRotation else 0f)
                            )
                        }

                        // Quick Theme Toggle Button
                        IconButton(
                            onClick = onToggleTheme,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("home_quick_theme_btn")
                        ) {
                            Icon(
                                imageVector = when (themeMode) {
                                    ThemeMode.DARK -> Icons.Default.LightMode
                                    ThemeMode.LIGHT -> Icons.Default.DarkMode
                                    ThemeMode.SYSTEM -> Icons.Default.DarkMode
                                },
                                contentDescription = when (themeMode) {
                                    ThemeMode.DARK -> "लाइट मोड चालू करें"
                                    ThemeMode.LIGHT -> "डार्क मोड चालू करें"
                                    ThemeMode.SYSTEM -> "डार्क मोड स्विच करें"
                                },
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        IconButton(
                            onClick = onSearchClick,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("home_top_search_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "सर्च करें (Search)",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        IconButton(
                            onClick = onNotificationsClick,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("home_notifications_btn")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (unreadNotificationsCount > 0) {
                                        Badge(
                                            containerColor = CrimsonRed,
                                            contentColor = Color.White
                                        ) {
                                            Text(
                                                text = if (unreadNotificationsCount > 99) "99+" else unreadNotificationsCount.toString(),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "सूचनाएं (Notifications)",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        IconButton(
                            onClick = onProfileClick,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("home_profile_btn")
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.25f),
                                modifier = Modifier.size(30.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    if (userAccount.isGuest) {
                                        Icon(
                                            imageVector = Icons.Default.AccountCircle,
                                            contentDescription = "मेरी प्रोफ़ाइल (My Profile)",
                                            tint = Color.White,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    } else {
                                        Text(
                                            text = userAccount.displayName.take(1).ifBlank { "👤" },
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Translucent City Selector Bar
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White.copy(alpha = 0.22f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .clickable(onClick = onCityClick)
                        .testTag("home_city_selector_btn")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = selectedCity.nameHindi,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                color = Color.White
                            )
                            Text(
                                text = " • ${selectedCity.tempCelsius} (${selectedCity.weatherCondition})",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "बदलें",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Home Search Bar with Voice Search Mic
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(onClick = onSearchClick)
                        .testTag("home_search_bar")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "सर्च",
                                tint = OrangePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "खबरें, शहर, विषय या कीवर्ड खोजें...",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }

                        Surface(
                            shape = CircleShape,
                            color = OrangePrimary.copy(alpha = 0.12f),
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .clickable { isVoiceSearchOpen = true }
                                .testTag("home_voice_mic_btn")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "वॉइस सर्च (Voice Search)",
                                    tint = OrangePrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Top Loading Indicator Bar when refreshing
        if (isRefreshing) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .testTag("home_refresh_progress"),
                color = OrangePrimary,
                trackColor = OrangeLight.copy(alpha = 0.3f)
            )
        }

        // Compute active feed list based on feedScope
        val activeNewsList = remember(feedScope, newsList, myCitiesNews, selectedCategory) {
            if (feedScope == HomeFeedScope.MY_CITIES) {
                if (selectedCategory == NewsCategory.ALL) myCitiesNews
                else myCitiesNews.filter { it.category == selectedCategory }
            } else {
                newsList
            }
        }

        // News Feed List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Offline Warning / Information Banner
            if (isOfflineActive) {
                item {
                    Surface(
                        color = Color(0xFFFFF3E0),
                        border = BorderStroke(1.dp, Color(0xFFFFB74D)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 2.dp)
                            .testTag("offline_warning_banner")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFE65100),
                                modifier = Modifier.size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.CloudOff,
                                        contentDescription = "ऑफलाइन",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "इंटरनेट उपलब्ध नहीं है। सेव की गई खबरें दिखाई जा रही हैं।",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFBF360C),
                                    lineHeight = 18.sp
                                )
                                Text(
                                    text = "ऑफलाइन मोड में पहले से लोड या सेव की गई खबरें पढ़ी जा सकती हैं।",
                                    fontSize = 11.sp,
                                    color = Color(0xFFE65100).copy(alpha = 0.85f)
                                )
                            }
                        }
                    }
                }
            }

            // Refresh Error Banner (with retry button)
            if (refreshError != null) {
                item {
                    RefreshErrorBanner(
                        errorMessage = refreshError,
                        onRetry = onRefresh,
                        onDismiss = onDismissError
                    )
                }
            }

            // Category Filter Pills
            item {
                Spacer(modifier = Modifier.height(2.dp))
                CategoryPillRow(
                    selectedCategory = selectedCategory,
                    onCategorySelected = onCategorySelected
                )
            }

            // "My Cities" / "मेरे शहर" Quick Followed Bar & Section
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    // Header with feed switcher tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Primary City Feed Tab
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (feedScope == HomeFeedScope.CURRENT_CITY) OrangePrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { feedScope = HomeFeedScope.CURRENT_CITY }
                                    .testTag("feed_tab_current_city")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = if (feedScope == HomeFeedScope.CURRENT_CITY) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = selectedCity.nameHindi,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (feedScope == HomeFeedScope.CURRENT_CITY) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // "⭐ मेरे शहर" (My Cities Feed) Tab
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (feedScope == HomeFeedScope.MY_CITIES) Color(0xFFE65100) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { feedScope = HomeFeedScope.MY_CITIES }
                                    .testTag("feed_tab_my_cities")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Star,
                                        contentDescription = null,
                                        tint = if (feedScope == HomeFeedScope.MY_CITIES) Color(0xFFFFD54F) else Color(0xFFFFB300),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "मेरे शहर (${followedCities.size})",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (feedScope == HomeFeedScope.MY_CITIES) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        // "+ फॉलो करें" / Manage Cities Button
                        TextButton(
                            onClick = onCityClick,
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.testTag("home_manage_cities_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = OrangePrimary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "शहर जोड़ें",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = OrangePrimary
                            )
                        }
                    }

                    // Followed Cities Carousel
                    if (followedCities.isNotEmpty()) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(followedCities) { city ->
                                val isSelected = city.id == selectedCity.id
                                val isPrimary = city.id == primaryCityId

                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (isSelected) Color(0xFFFFEBE5) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                    ),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable {
                                            onSelectCity(city)
                                            feedScope = HomeFeedScope.CURRENT_CITY
                                        }
                                        .testTag("followed_city_chip_${city.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (isPrimary) {
                                            Icon(
                                                imageVector = Icons.Filled.Star,
                                                contentDescription = "मुख्य शहर",
                                                tint = Color(0xFFFFB300),
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                        }
                                        Text(
                                            text = city.nameHindi,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = city.tempCelsius,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Weather & Air Quality Strip for Selected City
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, Color(0xFFFFEBE5)),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.WbSunny,
                                contentDescription = null,
                                tint = OrangeLight,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "${selectedCity.nameHindi}: ${selectedCity.tempCelsius}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = selectedCity.weatherCondition,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (selectedCity.aqi < 100) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Air,
                                    contentDescription = null,
                                    tint = if (selectedCity.aqi < 100) Color(0xFF2E7D32) else Color(0xFFEF6C00),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "AQI ${selectedCity.aqi} • ${selectedCity.aqiStatus}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (selectedCity.aqi < 100) Color(0xFF2E7D32) else Color(0xFFEF6C00)
                                )
                            }
                        }
                    }
                }
            }

            // Prominent Breaking News Section
            if (breakingNews.isNotEmpty()) {
                item {
                    BreakingNewsSection(
                        breakingNewsList = breakingNews,
                        onArticleClick = onArticleClick,
                        onCreatePostClick = onCreatePostClick,
                        isArticleBookmarked = isArticleBookmarked,
                        onBookmarkClick = onBookmarkClick
                    )
                }
            }

            // Sleek Creative Mode Promo Card (from Design HTML: bg-gradient-to-br from-[#FFAB91] to-[#E64A19])
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .clickable {
                            if (newsList.isNotEmpty()) {
                                onCreatePostClick(newsList.first())
                            }
                        }
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color(0xFFFFAB91), OrangePrimary)
                                )
                            )
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "क्रिएटिव मोड ✨",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "सोशल मीडिया कार्ड बनाएं",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "WhatsApp व Instagram हेतु पोस्टर तैयार करें",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                            }

                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.25f),
                                modifier = Modifier.size(48.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Outlined.AutoAwesome,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Trending Stories Carousel (if category is ALL and trendingNews is available)
            if (selectedCategory == NewsCategory.ALL && trendingNews.isNotEmpty()) {
                item {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(
                                                listOf(CrimsonRed, OrangePrimary)
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocalFireDepartment,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ट्रेंडिंग बड़ी खबरें",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = CrimsonRed.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "TOP",
                                        color = CrimsonRed,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                    )
                                }
                            }

                            // "सभी देखें" Action with chevron
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onViewAllTrendingClick() }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                                    .testTag("home_view_all_trending_btn")
                            ) {
                                Text(
                                    text = "सभी देखें",
                                    color = OrangePrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(
                                    imageVector = Icons.Default.ChevronRight,
                                    contentDescription = "सभी देखें",
                                    tint = OrangePrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
                        ) {
                            itemsIndexed(trendingNews) { index, article ->
                                val rank = index + 1
                                val rankBadgeBg = when (rank) {
                                    1 -> Color(0xFFFFB300) // Gold
                                    2 -> Color(0xFFE0E0E0) // Silver
                                    3 -> Color(0xFFFFCC80) // Bronze
                                    else -> Color.Black.copy(alpha = 0.65f)
                                }
                                val rankBadgeTextColor = when (rank) {
                                    1 -> Color.Black
                                    2 -> Color.Black
                                    3 -> Color(0xFFBF360C)
                                    else -> Color.White
                                }

                                Card(
                                    modifier = Modifier
                                        .width(260.dp)
                                        .height(175.dp)
                                        .clip(RoundedCornerShape(20.dp))
                                        .clickable { onArticleClick(article) }
                                        .testTag("home_trending_card_$rank"),
                                    shape = RoundedCornerShape(20.dp),
                                    elevation = CardDefaults.cardElevation(4.dp)
                                ) {
                                    Box(modifier = Modifier.fillMaxSize()) {
                                        Image(
                                            painter = painterResource(id = article.imageResId),
                                            contentDescription = article.title,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(
                                                    Brush.verticalGradient(
                                                        listOf(
                                                            Color.Black.copy(alpha = 0.35f),
                                                            Color.Transparent,
                                                            Color.Black.copy(alpha = 0.9f)
                                                        )
                                                    )
                                                )
                                        )

                                        // Rank Badge (Top-Left)
                                        Surface(
                                            shape = RoundedCornerShape(bottomEnd = 12.dp, topStart = 20.dp),
                                            color = rankBadgeBg,
                                            shadowElevation = 2.dp,
                                            modifier = Modifier.align(Alignment.TopStart)
                                        ) {
                                            Text(
                                                text = when (rank) {
                                                    1 -> "👑 #1"
                                                    2 -> "⚡ #2"
                                                    3 -> "🌟 #3"
                                                    else -> "#$rank"
                                                },
                                                color = rankBadgeTextColor,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Black,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                            )
                                        }

                                        // Bookmark Button (Top Right)
                                        val isSaved = isArticleBookmarked(article.id)
                                        Surface(
                                            shape = CircleShape,
                                            color = Color.Black.copy(alpha = 0.6f),
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(8.dp)
                                                .size(30.dp)
                                                .clip(CircleShape)
                                                .clickable { onBookmarkClick(article) }
                                                .testTag("trending_bookmark_btn_${article.id}")
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                                    contentDescription = if (isSaved) "सेव से हटाएं" else "सेव करें",
                                                    tint = if (isSaved) OrangePrimary else Color.White,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }

                                        // Bottom Content: City & Views Badges + Headline
                                        Column(
                                            modifier = Modifier
                                                .align(Alignment.BottomStart)
                                                .padding(12.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = OrangePrimary
                                                ) {
                                                    Text(
                                                        text = article.cityHindi,
                                                        color = Color.White,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = Color.Black.copy(alpha = 0.6f)
                                                ) {
                                                    Text(
                                                        text = "${article.viewsCount} व्यूज",
                                                        color = Color(0xFFFFD54F),
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = article.title,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                lineHeight = 17.sp,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Feed Section Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (feedScope == HomeFeedScope.MY_CITIES) "मेरे शहरों की खबरें (${activeNewsList.size})" else "ताज़ा खबरें (${newsList.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (selectedCategory != NewsCategory.ALL) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = OrangeLight.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = selectedCategory.titleHindi,
                                    color = OrangePrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = if (feedScope == HomeFeedScope.MY_CITIES) "फॉलो: ${followedCities.size} शहर" else "शहर: ${selectedCity.nameHindi}",
                        fontSize = 12.sp,
                        color = OrangePrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (feedScope == HomeFeedScope.MY_CITIES && followedCities.isEmpty()) {
                // Exact required Hindi empty state for Followed Cities
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .testTag("my_cities_empty_state"),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = OrangePrimary.copy(alpha = 0.12f),
                                modifier = Modifier.size(60.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.LocationCity,
                                        contentDescription = null,
                                        tint = OrangePrimary,
                                        modifier = Modifier.size(30.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "आपने अभी कोई शहर फॉलो नहीं किया है।",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "अपने पसंदीदा शहरों की खबरें एक साथ देखने और उनकी सूचनाएं पाने के लिए शहरों को फॉलो करें।",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                lineHeight = 18.sp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            androidx.compose.material3.Button(
                                onClick = onCityClick,
                                shape = RoundedCornerShape(12.dp),
                                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                                modifier = Modifier.testTag("empty_state_follow_cities_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "शहर फॉलो करें",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            } else if (activeNewsList.isEmpty()) {
                item {
                    EmptyNewsView(
                        title = "कोई खबर नहीं मिली",
                        subtitle = if (feedScope == HomeFeedScope.MY_CITIES) "आपके फॉलो किए शहरों में चुनी गई श्रेणी (${selectedCategory.titleHindi}) में अभी कोई खबर उपलब्ध नहीं है।"
                        else "चुने गए शहर (${selectedCity.nameHindi}) और श्रेणी (${selectedCategory.titleHindi}) में अभी कोई खबर उपलब्ध नहीं है।",
                        onRetry = onRefresh,
                        onResetCategory = { onCategorySelected(NewsCategory.ALL) }
                    )
                }
            } else {
                // News Cards
                items(activeNewsList, key = { it.id }) { news ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        NewsCard(
                            news = news,
                            isLiked = likedArticleIds.contains(news.id),
                            isBookmarked = isArticleBookmarked(news.id),
                            isOfflineAvailable = offlineArticleIds.contains(news.id),
                            onCardClick = { onArticleClick(news) },
                            onLikeClick = { onLikeClick(news.id) },
                            onBookmarkClick = { onBookmarkClick(news) },
                            onShareClick = {
                                PostExportUtil.sharePost(
                                    context,
                                    com.example.model.PostCustomization(
                                        headline = news.title,
                                        summary = news.summary,
                                        cityHindi = news.cityHindi,
                                        reporterName = news.reporterName,
                                        imageResId = news.imageResId
                                    )
                                )
                            },
                            onCreatePostClick = { onCreatePostClick(news) }
                        )
                    }
                }
            }
        }

        // Voice Search Modal for Home Screen
        VoiceSearchModal(
            isOpen = isVoiceSearchOpen,
            onDismiss = { isVoiceSearchOpen = false },
            onSearchTextRecognized = { recognizedText ->
                onVoiceSearchResult(recognizedText)
            }
        )
    }
}
