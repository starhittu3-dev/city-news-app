package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdsClick
import androidx.compose.material.icons.filled.Api
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.OrangeDark
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary

/**
 * Privacy Policy Screen for City Khabar.
 * Explains data collection, News API usage, advertising policies, and includes a full policy link.
 */
@Composable
fun PrivacyPolicyScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val privacyPolicyUrl = "https://citykhabar.in/privacy-policy"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("privacy_policy_screen")
    ) {
        // Top App Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 3.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("privacy_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "वापस जाएं",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                Column {
                    Text(
                        text = "गोपनीयता नीति (Privacy Policy)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "डेटा सुरक्षा, News API एवं गोपनीयता नियम",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 40.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Intro Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, OrangePrimary.copy(alpha = 0.25f)),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = OrangePrimary.copy(alpha = 0.12f),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = OrangePrimary,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Text(
                                text = "आपकी गोपनीयता हमारी सर्वोच्च प्राथमिकता है",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "अंतिम अपडेट: 2026 • सिटी खबर (City Khabar)",
                                fontSize = 11.sp,
                                color = OrangeDark,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // 1. Data Collection
            item {
                PolicySectionCard(
                    icon = Icons.Default.Storage,
                    iconTint = OrangePrimary,
                    title = "1. ऐप क्या डेटा एकत्र करता है? (Data Collection)",
                    content = """
                        सिटी खबर (City Khabar) आपके व्यक्तिगत डेटा की सुरक्षा के प्रति पूरी तरह प्रतिबद्ध है:
                        
                        • स्थानीय प्राथमिकताएं (Local Preferences): ऐप आपके द्वारा चुने गए मुख्य शहर (जैसे दिल्ली, मुंबई, जयपुर आदि), पसंदीदा थीम (डार्क/लाइट), और नोटिफिकेशन सेटिंग्स को केवल आपके फोन की लोकल मेमोरी में सहेजता है।
                        
                        • बुकमार्क व बनाए गए पोस्टर्स: आपकी सेव की गई खबरें और पोस्टर हिस्ट्री आपके डिवाइस में सुरक्षित रहती हैं।
                        
                        • तकनीकी व विश्लेषणात्मक डेटा: ऐप के प्रदर्शन और क्रैश सुधार के लिए अज्ञात तकनीकी डेटा (डिवाइस मॉडल, OS वर्जन) का विश्लेषण किया जा सकता है।
                        
                        • हम कोई भी संवेदनशील व्यक्तिगत डेटा (जैसे पासवर्ड, बैंक विवरण या निजी संपर्क) एकत्र या विक्रय नहीं करते हैं।
                    """.trimIndent()
                )
            }

            // 2. News API Data Usage
            item {
                PolicySectionCard(
                    icon = Icons.Default.Api,
                    iconTint = Color(0xFF1976D2),
                    title = "2. News API डेटा का उपयोग (News API Usage)",
                    content = """
                        सिटी खबर ऐप विभिन्न अधिकृत न्यूज़ API और क्षेत्रीय संवाददाताओं से वास्तविक समय में समाचार एकत्र करता है:
                        
                        • समाचार वितरण: न्यूज़ API डेटा का उपयोग उपयोगकर्ताओं को उनके शहर की ताज़ा, सत्यापित एवं निष्पक्ष खबरें प्रदान करने हेतु किया जाता है।
                        
                        • रील और पोस्टर निर्माण: उपयोगकर्ता जब किसी समाचार से 9:16 वीडियो रील या सोशल पोस्टर बनाते हैं, तो समाचार का शीर्षक, शहर का नाम और अधिकृत चित्र का उपयोग ऑन-डिवाइस ग्राफ़िक रेंडरिंग के लिए किया जाता है।
                        
                        • कोई अनधिकृत हेरफेर नहीं: सभी खबरें समाचार स्रोतों के अनुसार प्रामाणिक रूप से प्रदर्शित की जाती हैं।
                    """.trimIndent()
                )
            }

            // 3. Advertising Services Data Collection
            item {
                PolicySectionCard(
                    icon = Icons.Default.AdsClick,
                    iconTint = CrimsonRed,
                    title = "3. विज्ञापन सेवाएं एवं तृतीय-पक्ष नीतियां (Advertising Services)",
                    content = """
                        ऐप को निशुल्क बनाए रखने हेतु हम तृतीय-पक्ष विज्ञापन प्रदाताओं (जैसे Google AdMob या संबद्ध नेटवर्क) का उपयोग कर सकते हैं:
                        
                        • विज्ञापन डेटा: विज्ञापन सेवाएं अपनी स्वतंत्र गोपनीयता नीतियों के अनुसार प्रासंगिक विज्ञापन दिखाने के लिए गैर-व्यक्तिगत पहचानकर्ता (Advertising ID), आईपी पता और सामान्य स्थान डेटा एकत्र कर सकती हैं।
                        
                        • तृतीय-पक्ष नीतियां: इन विज्ञापन प्रदाताओं का डेटा संग्रह उनकी अपनी प्राइवेसी पॉलिसी द्वारा नियंत्रित होता है। आप अपने डिवाइस की Android सेटिंग्स से पर्सनलाइज्ड ऐड्स को कभी भी रीसेट या बंद कर सकते हैं।
                    """.trimIndent()
                )
            }

            // 4. Full Privacy Policy Link Placeholder
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("privacy_link_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = null,
                                tint = OrangePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "पूर्ण गोपनीयता नीति लिंक (Full Privacy Policy)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "हमारे विस्तृत कानूनी नियमों एवं प्राइवेसी पॉलिसी को ऑनलाइन पढ़ने के लिए नीचे दिए गए लिंक पर जाएं:",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // URL Box
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = privacyPolicyUrl,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = OrangePrimary,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("City Khabar Privacy Policy", privacyPolicyUrl)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "लिंक कॉपी हो गया!", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f).testTag("copy_privacy_link_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("लिंक कॉपी करें", fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    try {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(privacyPolicyUrl))
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "ब्राउज़र नहीं मिला: $privacyPolicyUrl", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                                modifier = Modifier.weight(1f).testTag("open_privacy_link_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.OpenInBrowser,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ब्राउज़र में खोलें", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // 5. Contact Info Footer
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = OrangePrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "गोपनीयता अधिकारी (Grievance Officer)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "यदि आपके पास हमारे डेटा प्रथाओं या गोपनीयता नीति के संबंध में कोई प्रश्न हैं, तो आप privacy@citykhabar.in पर संपर्क कर सकते हैं।",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PolicySectionCard(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    content: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = iconTint.copy(alpha = 0.12f),
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = iconTint,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = content,
                fontSize = 12.sp,
                lineHeight = 18.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
