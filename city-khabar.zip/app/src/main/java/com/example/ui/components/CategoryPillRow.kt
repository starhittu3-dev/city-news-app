package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NewsCategory
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary

/**
 * Horizontal scrollable category pill row for Hindi news filtering.
 * Highlights active category with primary orange theme and icon.
 */
@Composable
fun CategoryPillRow(
    selectedCategory: NewsCategory,
    onCategorySelected: (NewsCategory) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("category_pill_row"),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NewsCategory.entries.forEach { category ->
            val isSelected = category == selectedCategory
            val bgColor by animateColorAsState(
                targetValue = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.surface,
                label = "pillBg"
            )
            val textColor by animateColorAsState(
                targetValue = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                label = "pillText"
            )
            val iconTint by animateColorAsState(
                targetValue = if (isSelected) Color.White else OrangePrimary,
                label = "pillIconTint"
            )

            Surface(
                shape = RoundedCornerShape(24.dp),
                color = bgColor,
                shadowElevation = if (isSelected) 4.dp else 1.dp,
                border = if (isSelected) {
                    BorderStroke(1.5.dp, OrangePrimary)
                } else {
                    BorderStroke(1.dp, OrangeLight.copy(alpha = 0.4f))
                },
                modifier = Modifier
                    .heightIn(min = 44.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .clickable { onCategorySelected(category) }
                    .testTag("category_pill_${category.id}")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = getCategoryVectorIcon(category),
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = category.titleHindi,
                        color = textColor,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

private fun getCategoryVectorIcon(category: NewsCategory): ImageVector {
    return when (category) {
        NewsCategory.ALL -> Icons.Default.Explore
        NewsCategory.POLITICS -> Icons.Default.Policy
        NewsCategory.SPORTS -> Icons.Default.SportsCricket
        NewsCategory.BUSINESS -> Icons.Default.BusinessCenter
        NewsCategory.WEATHER -> Icons.Default.WbSunny
        NewsCategory.ENTERTAINMENT -> Icons.Default.Movie
        NewsCategory.LOCAL -> Icons.Default.LocationCity
        NewsCategory.CRIME -> Icons.Default.Gavel
        NewsCategory.TECH -> Icons.Default.Devices
    }
}
