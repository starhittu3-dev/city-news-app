package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// City Khabar Brand Palette - Sleek Interface Theme
val OrangePrimary = Color(0xFFE64A19)       // Deep Flame Orange
val OrangeLight = Color(0xFFFF5722)         // Bright Crimson Orange
val OrangePeach = Color(0xFFFFAB91)         // Sleek Peach Accent
val OrangeDark = Color(0xFFBF360C)          // Rich Burnt Orange
val CrimsonRed = Color(0xFFD32F2F)          // Headline Crimson
val SaffronGold = Color(0xFFFF9800)         // Saffron Accent
val WarmAmber = Color(0xFFFFB300)           // Amber Warm

// Surfaces & Backgrounds (Light - Sleek Theme)
val LightBg = Color(0xFFFDF8F6)             // Sleek Warm Off-White / Peach Cream
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFFFF3E0)
val LightBorder = Color(0xFFFFEBE5)         // Sleek Soft Orange-100 Border

// Text Colors (Light)
val TextPrimary = Color(0xFF1C1B1F)         // High contrast sleek dark
val TextSecondary = Color(0xFF49454F)       // Sleek neutral
val TextMuted = Color(0xFF79747E)

// Dark Theme Palette
val DarkBg = Color(0xFF161312)
val DarkSurface = Color(0xFF201A18)
val DarkSurfaceVariant = Color(0xFF2C2422)
val DarkBorder = Color(0xFF3E3330)
val DarkTextPrimary = Color(0xFFF7F1EE)
val DarkTextSecondary = Color(0xFFCAC4D0)
val DarkTextMuted = Color(0xFF938F96)

// Semantic Accents
val BreakingNewsRed = Color(0xFFE64A19)
val VerifiedBadgeBlue = Color(0xFF1E88E5)
val LivePulseGreen = Color(0xFF43A047)
val TrendingPurple = Color(0xFF8E24AA)
val CardShimmer = Color(0xFFFFF3E0)
