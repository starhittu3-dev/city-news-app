package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material.icons.outlined.Air
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CityInfo
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangePrimary

enum class CityZoneFilter(val titleHindi: String, val icon: String) {
    ALL("सभी शहर", "all"),
    FOLLOWED("⭐ मेरे शहर", "followed"),
    RECENT("🕒 हालिया", "recent"),
    POPULAR("🔥 प्रमुख", "popular"),
    NORTH("उत्तर भारत", "north"),
    WEST("पश्चिम भारत", "west"),
    SOUTH("दक्षिण भारत", "south"),
    EAST_CENTRAL("पूर्व / मध्य", "east")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CitySelectorSheet(
    cities: List<CityInfo>,
    selectedCity: CityInfo,
    primaryCityId: String? = null,
    favoriteCityIds: Set<String> = emptySet(),
    followedCityIds: Set<String> = favoriteCityIds,
    recentCityIds: List<String> = emptyList(),
    onCitySelected: (CityInfo) -> Unit,
    onToggleFavorite: (String) -> Unit = {},
    onToggleFollow: (String) -> Unit = onToggleFavorite,
    onSetPrimaryCity: (String) -> Unit = {},
    onClearRecent: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var searchQuery by remember { mutableStateOf("") }
    var selectedZoneFilter by remember { mutableStateOf(CityZoneFilter.ALL) }

    // Map recent city IDs to CityInfo objects
    val recentCities = remember(recentCityIds, cities) {
        recentCityIds.mapNotNull { id -> cities.find { it.id == id } }
            .distinctBy { it.id }
    }

    // Map followed city IDs to CityInfo objects
    val effectiveFollowedIds = remember(followedCityIds, favoriteCityIds) {
        if (followedCityIds.isNotEmpty()) followedCityIds else favoriteCityIds
    }
    val followedCities = remember(effectiveFollowedIds, cities) {
        cities.filter { effectiveFollowedIds.contains(it.id) }
    }

    val popularCities = remember(cities) {
        cities.filter { it.isPopular }
    }

    // Filter cities based on search and selected tab
    val filteredCities = remember(searchQuery, selectedZoneFilter, cities, effectiveFollowedIds, recentCityIds) {
        var list = cities

        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.nameHindi.lowercase().contains(q) ||
                it.nameEnglish.lowercase().contains(q) ||
                it.stateHindi.lowercase().contains(q)
            }
        } else {
            list = when (selectedZoneFilter) {
                CityZoneFilter.ALL -> list
                CityZoneFilter.FOLLOWED -> followedCities
                CityZoneFilter.RECENT -> recentCities
                CityZoneFilter.POPULAR -> popularCities
                CityZoneFilter.NORTH -> list.filter {
                    it.stateHindi.contains("दिल्ली") || it.stateHindi.contains("उत्तर प्रदेश") ||
                    it.stateHindi.contains("पंजाब") || it.stateHindi.contains("हरियाणा") ||
                    it.stateHindi.contains("उत्तराखंड") || it.stateHindi.contains("हिमाचल") ||
                    it.stateHindi.contains("जम्मू") || it.stateHindi.contains("राजस्थान")
                }
                CityZoneFilter.WEST -> list.filter {
                    it.stateHindi.contains("महाराष्ट्र") || it.stateHindi.contains("गुजरात")
                }
                CityZoneFilter.SOUTH -> list.filter {
                    it.stateHindi.contains("कर्नाटक") || it.stateHindi.contains("तेलंगाना") ||
                    it.stateHindi.contains("तमिलनाडु") || it.stateHindi.contains("केरल")
                }
                CityZoneFilter.EAST_CENTRAL -> list.filter {
                    it.stateHindi.contains("बिहार") || it.stateHindi.contains("पश्चिम बंगाल") ||
                    it.stateHindi.contains("मध्य प्रदेश") || it.stateHindi.contains("झारखंड") ||
                    it.stateHindi.contains("छत्तीसगढ़") || it.stateHindi.contains("असम")
                }
            }
        }
        list
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(44.dp)
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .padding(horizontal = 16.dp)
        ) {
            // Header Title & Close Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "अपना शहर चुनें",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = OrangePrimary
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = OrangePrimary.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "${cities.size} भारतीय शहर",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = OrangePrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "स्थानीय ताज़ा खबरें, मौसम, AQI और वीडियो रील्स",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_city_sheet_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "बंद करें",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 1. Search Bar for Indian Cities
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("भारतीय शहर या राज्य खोजें... (जैसे: मुंबई, Jaipur, दिल्ली)") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search City",
                        tint = OrangePrimary
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OrangePrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("city_search_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Tabs Row (When not actively typing search)
            if (searchQuery.isBlank()) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(CityZoneFilter.entries.toTypedArray()) { filter ->
                        val isSelected = selectedZoneFilter == filter
                        val countLabel = when (filter) {
                            CityZoneFilter.FOLLOWED -> if (followedCities.isNotEmpty()) " (${followedCities.size})" else ""
                            CityZoneFilter.RECENT -> if (recentCities.isNotEmpty()) " (${recentCities.size})" else ""
                            CityZoneFilter.POPULAR -> " (${popularCities.size})"
                            CityZoneFilter.ALL -> " (${cities.size})"
                            else -> ""
                        }
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedZoneFilter = filter },
                            label = {
                                Text(
                                    text = "${filter.titleHindi}$countLabel",
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = OrangePrimary,
                                selectedLabelColor = Color.White,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                labelColor = MaterialTheme.colorScheme.onSurface
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = Color.Transparent,
                                selectedBorderColor = OrangePrimary
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {

                // 2. CLEARLY SHOW THE CURRENTLY SELECTED CITY (Prominent Hero Card)
                item {
                    val isFav = favoriteCityIds.contains(selectedCity.id)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("currently_selected_city_card"),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFFFFF3EE)
                        ),
                        border = androidx.compose.foundation.BorderStroke(2.dp, OrangePrimary)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            // Top Row: Active Tag & Favorite Toggle
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = OrangePrimary,
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.FiberManualRecord,
                                            contentDescription = null,
                                            tint = Color(0xFF76FF03),
                                            modifier = Modifier.size(10.dp)
                                        )
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(
                                            text = "वर्तमान चयनित शहर (Active)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { onToggleFavorite(selectedCity.id) },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isFav) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                            contentDescription = "पसंदीदा बनाएं",
                                            tint = if (isFav) Color(0xFFFFB300) else OrangePrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // City Details Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = OrangePrimary,
                                        modifier = Modifier.size(46.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.LocationCity,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = selectedCity.nameHindi,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 19.sp,
                                                color = OrangePrimary
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "(${selectedCity.nameEnglish})",
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Text(
                                            text = "${selectedCity.stateHindi} • ${selectedCity.weatherCondition}",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                // Weather & AQI Box
                                Column(horizontalAlignment = Alignment.End) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Outlined.Cloud,
                                            contentDescription = null,
                                            tint = OrangePrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = selectedCity.tempCelsius,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (selectedCity.aqi < 100) Color(0xFFE8F5E9) else Color(0xFFFFF3E0),
                                        modifier = Modifier.padding(top = 2.dp)
                                    ) {
                                        Text(
                                            text = "AQI ${selectedCity.aqi} • ${selectedCity.aqiStatus}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (selectedCity.aqi < 100) Color(0xFF2E7D32) else Color(0xFFE65100),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. SHOW RECENTLY SELECTED CITIES (जब सर्च न हो और हालिया शहर उपलब्ध हों)
                if (searchQuery.isBlank() && (selectedZoneFilter == CityZoneFilter.ALL || selectedZoneFilter == CityZoneFilter.RECENT)) {
                    if (recentCities.isNotEmpty()) {
                        item {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.History,
                                            contentDescription = null,
                                            tint = OrangePrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "हाल ही में चुने गए शहर",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    TextButton(
                                        onClick = onClearRecent,
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteSweep,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "साफ़ करें",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    contentPadding = PaddingValues(vertical = 4.dp)
                                ) {
                                    items(recentCities) { city ->
                                        val isCurrent = city.id == selectedCity.id
                                        Surface(
                                            shape = RoundedCornerShape(14.dp),
                                            color = if (isCurrent) Color(0xFFFFEBE5) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                            border = if (isCurrent) androidx.compose.foundation.BorderStroke(1.5.dp, OrangePrimary) else null,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(14.dp))
                                                .clickable { onCitySelected(city) }
                                                .testTag("recent_city_${city.id}")
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.LocationOn,
                                                    contentDescription = null,
                                                    tint = if (isCurrent) OrangePrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Column {
                                                    Text(
                                                        text = city.nameHindi,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        color = if (isCurrent) OrangePrimary else MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Text(
                                                        text = "${city.tempCelsius} • AQI ${city.aqi}",
                                                        fontSize = 10.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                if (isCurrent) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Icon(
                                                        imageVector = Icons.Filled.Check,
                                                        contentDescription = "Selected",
                                                        tint = OrangePrimary,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 4. SHOW FOLLOWED CITIES SECTION (मेरे फॉलो किए गए शहर)
                if (searchQuery.isBlank() && (selectedZoneFilter == CityZoneFilter.ALL || selectedZoneFilter == CityZoneFilter.FOLLOWED)) {
                    if (followedCities.isNotEmpty()) {
                        item {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Filled.Star,
                                            contentDescription = null,
                                            tint = Color(0xFFFFB300),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "मेरे फॉलो किए गए शहर (${followedCities.size})",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }

                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    contentPadding = PaddingValues(vertical = 4.dp)
                                ) {
                                    items(followedCities) { city ->
                                        val isCurrent = city.id == selectedCity.id
                                        val isPrimary = city.id == primaryCityId
                                        Card(
                                            modifier = Modifier
                                                .width(155.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .clickable { onCitySelected(city) }
                                                .testTag("followed_city_${city.id}"),
                                            shape = RoundedCornerShape(14.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isCurrent) Color(0xFFFFEBE5) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                            ),
                                            border = if (isCurrent) androidx.compose.foundation.BorderStroke(1.5.dp, OrangePrimary) else null
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = city.nameHindi,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 14.sp,
                                                        color = if (isCurrent) OrangePrimary else MaterialTheme.colorScheme.onSurface
                                                    )
                                                    if (isPrimary) {
                                                        Surface(
                                                            shape = RoundedCornerShape(4.dp),
                                                            color = Color(0xFFFFB300)
                                                        ) {
                                                            Text(
                                                                text = "⭐ मुख्य",
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color.Black,
                                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = city.stateHindi,
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = city.tempCelsius,
                                                        fontWeight = FontWeight.SemiBold,
                                                        fontSize = 11.sp,
                                                        color = OrangePrimary
                                                    )
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = Color(0xFFE8F5E9),
                                                        modifier = Modifier.clickable { onToggleFollow(city.id) }
                                                    ) {
                                                        Text(
                                                            text = "✓ फॉलो",
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFF2E7D32),
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else if (selectedZoneFilter == CityZoneFilter.FOLLOWED) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.StarBorder,
                                        contentDescription = null,
                                        tint = Color(0xFFFFB300),
                                        modifier = Modifier.size(40.dp)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "आपने अभी कोई शहर फॉलो नहीं किया है।",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.5.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "अपने पसंदीदा शहरों को फॉलो करें ताकि उनकी सभी मुख्य खबरें एक ही जगह मिल सकें।",
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(
                                        onClick = { selectedZoneFilter = CityZoneFilter.ALL },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)
                                    ) {
                                        Text("शहर फॉलो करें", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // 5. POPULAR CITIES CARDS (When on ALL or POPULAR tab)
                if (searchQuery.isBlank() && (selectedZoneFilter == CityZoneFilter.ALL || selectedZoneFilter == CityZoneFilter.POPULAR)) {
                    item {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Whatshot,
                                    contentDescription = null,
                                    tint = OrangePrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "प्रमुख लोकप्रिय महानगर",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                contentPadding = PaddingValues(vertical = 4.dp)
                            ) {
                                items(popularCities) { city ->
                                    val isSelected = city.id == selectedCity.id
                                    val isFav = favoriteCityIds.contains(city.id)
                                    Card(
                                        modifier = Modifier
                                            .width(135.dp)
                                            .height(115.dp)
                                            .clip(RoundedCornerShape(16.dp))
                                            .clickable { onCitySelected(city) }
                                            .then(
                                                if (isSelected) Modifier.border(2.dp, OrangePrimary, RoundedCornerShape(16.dp))
                                                else Modifier
                                            ),
                                        shape = RoundedCornerShape(16.dp),
                                        elevation = CardDefaults.cardElevation(2.dp)
                                    ) {
                                        Box(modifier = Modifier.fillMaxWidth()) {
                                            Image(
                                                painter = painterResource(id = city.imageResId),
                                                contentDescription = city.nameHindi,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.matchParentSize()
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .matchParentSize()
                                                    .background(
                                                        Brush.verticalGradient(
                                                            listOf(
                                                                Color.Black.copy(alpha = 0.35f),
                                                                Color.Black.copy(alpha = 0.85f)
                                                            )
                                                        )
                                                    )
                                            )

                                            // Top Right Badges (Selected Check & Fav Star)
                                            Row(
                                                modifier = Modifier
                                                    .align(Alignment.TopEnd)
                                                    .padding(6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                if (isFav) {
                                                    Icon(
                                                        imageVector = Icons.Filled.Star,
                                                        contentDescription = "Favorite",
                                                        tint = Color(0xFFFFB300),
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                }
                                                if (isSelected) {
                                                    Spacer(modifier = Modifier.width(3.dp))
                                                    Icon(
                                                        imageVector = Icons.Filled.CheckCircle,
                                                        contentDescription = "Selected",
                                                        tint = OrangeLight,
                                                        modifier = Modifier.size(17.dp)
                                                    )
                                                }
                                            }

                                            Column(
                                                modifier = Modifier
                                                    .align(Alignment.BottomStart)
                                                    .padding(8.dp)
                                            ) {
                                                Text(
                                                    text = city.nameHindi,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp
                                                )
                                                Text(
                                                    text = "${city.tempCelsius} • ${city.stateHindi}",
                                                    color = OrangeLight,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 6. ALL FILTERED CITIES LIST (सभी शहर सूची)
                item {
                    val title = when {
                        searchQuery.isNotBlank() -> "सर्च परिणाम (${filteredCities.size})"
                        selectedZoneFilter != CityZoneFilter.ALL -> "${selectedZoneFilter.titleHindi} (${filteredCities.size})"
                        else -> "सभी भारतीय शहर (${filteredCities.size})"
                    }
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                // Empty State when search query yields no result
                if (filteredCities.isEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = OrangePrimary,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "\"$searchQuery\" के लिए कोई शहर नहीं मिला",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "कृपया स्पेलिंग जांचें या नीचे दिए गए प्रमुख शहरों में से चुनें।",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedButton(
                                    onClick = { searchQuery = "" },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("सर्च हटाएं")
                                }
                            }
                        }
                    }
                }

                items(filteredCities) { city ->
                    val isSelected = city.id == selectedCity.id
                    val isFollowed = effectiveFollowedIds.contains(city.id)
                    val isPrimary = city.id == primaryCityId

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onCitySelected(city) }
                            .then(
                                if (isSelected) Modifier.border(1.5.dp, OrangePrimary, RoundedCornerShape(14.dp))
                                else Modifier
                            )
                            .testTag("city_item_${city.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0xFFFFEBE5) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.surface,
                                        modifier = Modifier.size(38.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Filled.LocationCity,
                                                contentDescription = null,
                                                tint = if (isSelected) Color.White else OrangePrimary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = city.nameHindi,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = if (isSelected) OrangePrimary else MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "(${city.nameEnglish})",
                                                fontSize = 11.5.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            if (isPrimary) {
                                                Spacer(modifier = Modifier.width(5.dp))
                                                Surface(
                                                    color = Color(0xFFFFB300),
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = "⭐ मुख्य शहर",
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.Black,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                            } else if (isSelected) {
                                                Spacer(modifier = Modifier.width(5.dp))
                                                Surface(
                                                    color = OrangePrimary,
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = "सक्रिय",
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.White,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = "${city.stateHindi} • ${city.newsCount} नई खबरें",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                // Weather / AQI info
                                Column(
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Outlined.Cloud,
                                            contentDescription = null,
                                            tint = OrangePrimary,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            text = city.tempCelsius,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Outlined.Air,
                                            contentDescription = null,
                                            tint = if (city.aqi < 100) Color(0xFF2E7D32) else Color(0xFFEF6C00),
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            text = "AQI ${city.aqi}",
                                            fontSize = 11.sp,
                                            color = if (city.aqi < 100) Color(0xFF2E7D32) else Color(0xFFEF6C00),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Bottom Actions Row: Follow/Unfollow Button & Set Primary Action
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Follow / Unfollow Button
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isFollowed) Color(0xFFE8F5E9) else OrangePrimary.copy(alpha = 0.12f),
                                    border = if (isFollowed) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF81C784)) else null,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { onToggleFollow(city.id) }
                                        .testTag("follow_btn_${city.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (isFollowed) Icons.Default.Check else Icons.Default.Add,
                                            contentDescription = null,
                                            tint = if (isFollowed) Color(0xFF2E7D32) else OrangePrimary,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isFollowed) "फॉलो किया (Unfollow)" else "फॉलो करें",
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isFollowed) Color(0xFF2E7D32) else OrangePrimary
                                        )
                                    }
                                }

                                // Set as Primary City Action
                                if (!isPrimary) {
                                    TextButton(
                                        onClick = { onSetPrimaryCity(city.id) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.testTag("set_primary_btn_${city.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.StarBorder,
                                            contentDescription = null,
                                            tint = Color(0xFFFF8F00),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "प्राथमिक शहर बनाएं",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = Color(0xFFFF8F00)
                                        )
                                    }
                                } else {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(end = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Star,
                                            contentDescription = null,
                                            tint = Color(0xFFFFB300),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "आपका प्राथमिक शहर",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFFFF8F00)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
