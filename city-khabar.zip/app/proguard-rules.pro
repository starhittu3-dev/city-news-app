# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# Preserve Kotlin Reflection and Coroutines
-keepattributes *Annotation*,InnerClasses,EnclosingMethod,Signature
-dontwarn java.lang.invoke.**
-dontwarn javax.annotation.**

# Room Database
-keep class androidx.room.** { *; }
-dontwarn androidx.room.paging.**
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao class * { *; }
-keepclassmembers class * {
    @androidx.room.Insert *;
    @androidx.room.Query *;
    @androidx.room.Delete *;
    @androidx.room.Update *;
}

# Keep Data Models and Entities
-keep class com.example.model.** { *; }
-keep class com.example.data.local.** { *; }
-keep class com.example.data.network.** { *; }

# Moshi JSON Converter
-keepclassmembers class * {
    @com.squareup.moshi.* <methods>;
}
-keep @com.squareup.moshi.JsonClass class * { *; }
-dontwarn com.squareup.moshi.**

# OkHttp & Retrofit
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
-keepattributes Signature
-keepattributes Exceptions

# Compose Runtime
-keep class androidx.compose.runtime.** { *; }
-dontwarn androidx.compose.**

# Coil Image Loader
-keep class coil.** { *; }
-dontwarn coil.**

